# EzKlean - Servico de background  v1.0.1
#
# Melhorias v1.0.1:
#   - Intervalo padrao de limpeza: 3 dias (era 7)
#   - Detecao de arranque do Kodi via onNotification (GUI/Player/Library)
#     em vez de timeout fixo de 30s - mais fiavel em dispositivos lentos
#   - Verificacao periodica a cada 6h (era 1h) - menos carga no sistema
#   - Limpeza adiada se houver reproducao em curso (ate 10 tentativas)
#   - Atualizacao automatica de addons/repositorios uma vez por dia no arranque
#   - Logs de diagnostico: intervalo, proxima execucao, resultado de updates

import os
import json
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID        = 'program.ezklean'
CHECK_INTERVAL  = 21600   # verificar a cada 6 horas
STARTUP_WAIT    = 5       # segundos entre iteracoes de espera no arranque
STARTUP_MAX     = 300     # max segundos aguardando Kodi arrancar (5 min)
UPDATE_INTERVAL = 86400   # verificar updates uma vez por dia (segundos)


def get_addon():
    return xbmcaddon.Addon(ADDON_ID)


def get_data_folder():
    addon = get_addon()
    path  = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _read_json(filename):
    fpath = os.path.join(get_data_folder(), filename)
    try:
        if xbmcvfs.exists(fpath):
            with open(fpath, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        xbmc.log('EzKlean: erro a ler {}: {}'.format(filename, e), xbmc.LOGERROR)
    return {}


def _write_json(filename, data):
    fpath = os.path.join(get_data_folder(), filename)
    try:
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(data, f)
    except Exception as e:
        xbmc.log('EzKlean: erro a escrever {}: {}'.format(filename, e), xbmc.LOGERROR)


# ── Limpeza automatica ────────────────────────────────────────────────────

def get_last_clean():
    return _read_json('last_auto_clean.json').get('timestamp', 0)


def save_last_clean():
    _write_json('last_auto_clean.json', {'timestamp': int(time.time())})


def should_clean():
    addon = get_addon()
    if not addon.getSettingBool('auto_clean_enable'):
        return False
    interval_days = addon.getSettingInt('auto_clean_interval')
    last          = get_last_clean()
    now           = int(time.time())
    if last == 0:
        xbmc.log('EzKlean: primeiro arranque - limpeza agendada', xbmc.LOGINFO)
        return True
    next_run   = last + interval_days * 86400
    time_left  = next_run - now
    if time_left <= 0:
        xbmc.log('EzKlean: intervalo de {}d expirou - a limpar'.format(interval_days), xbmc.LOGINFO)
        return True
    xbmc.log('EzKlean: proxima limpeza em {:.1f}h'.format(time_left / 3600), xbmc.LOGDEBUG)
    return False


def run_auto_clean():
    xbmc.log('EzKlean: a iniciar limpeza automatica', xbmc.LOGINFO)
    try:
        from resources.lib.cleaner import (
            clear_cache_and_temp, clear_thumbnails,
            clear_addon_leftovers, clear_packages, optimize_databases
        )
        clear_cache_and_temp(auto_mode=True)
        clear_thumbnails(auto_mode=True)
        clear_addon_leftovers(auto_mode=True)
        clear_packages(auto_mode=True)
        optimize_databases(auto_mode=True)
        save_last_clean()
        xbmc.executebuiltin('Notification(EzKlean, Limpeza automatica concluida., 4000)')
        xbmc.log('EzKlean: limpeza automatica concluida', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('EzKlean: erro na limpeza automatica: {}'.format(e), xbmc.LOGERROR)


# ── Atualizacao automatica de addons ─────────────────────────────────────

def get_last_update_check():
    return _read_json('last_update_check.json').get('timestamp', 0)


def save_last_update_check():
    _write_json('last_update_check.json', {'timestamp': int(time.time())})


def should_check_updates():
    last = get_last_update_check()
    if last == 0:
        return True
    elapsed = int(time.time()) - last
    return elapsed >= UPDATE_INTERVAL


def run_addon_updates():
    """
    Forca a verificacao e instalacao de atualizacoes de addons e repositorios.

    Estrategia:
      1. Atualizar todos os repositorios instalados (fontes de addons)
      2. Verificar e instalar atualizacoes de todos os addons
      3. Guardar timestamp para nao repetir nas proximas 24h
    """
    xbmc.log('EzKlean: a verificar atualizacoes de addons', xbmc.LOGINFO)
    try:
        # Passo 1: Atualizar repositorios (fontes)
        # UpdateAddonRepos forca o Kodi a verificar todos os repositorios
        xbmc.executebuiltin('UpdateAddonRepos')
        # Aguardar que o Kodi processe os repositorios (normalmente 5-15s)
        xbmc.sleep(10000)

        # Passo 2: Instalar atualizacoes pendentes de todos os addons
        # UpdateLocalAddons verifica addons locais instalados
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.sleep(3000)

        # Passo 3: Via JSON-RPC - atualizar addons individualmente se pendentes
        _update_via_jsonrpc()

        save_last_update_check()
        xbmc.log('EzKlean: verificacao de atualizacoes concluida', xbmc.LOGINFO)

    except Exception as e:
        xbmc.log('EzKlean: erro ao verificar atualizacoes: {}'.format(e), xbmc.LOGERROR)


def _update_via_jsonrpc():
    """
    Usa o JSON-RPC do Kodi para verificar e atualizar addons com updates disponiveis.
    Inspirado na abordagem do OptiKlean autoupdater.py, mas usando apenas
    a API interna do Kodi (sem chamadas a GitLab/GitHub externas).
    """
    try:
        import json as _json

        # Obter lista de todos os addons instalados e ativados
        resp = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","method":"Addons.GetAddons",'
            '"params":{"enabled":true,"properties":["version","name"]},"id":1}'
        )
        data     = _json.loads(resp)
        addons   = data.get('result', {}).get('addons', [])
        n_addons = len(addons)

        xbmc.log('EzKlean: {} addons ativos encontrados'.format(n_addons), xbmc.LOGINFO)

        # Kodi nao tem endpoint JSON-RPC direto para "atualizar addon X"
        # mas UpdateAddonRepos + UpdateLocalAddons cobrem isso.
        # Registar quantos addons foram verificados para o log.
        if n_addons > 0:
            xbmc.log(
                'EzKlean: repositorios e addons verificados ({} addons ativos)'.format(n_addons),
                xbmc.LOGINFO
            )

    except Exception as e:
        xbmc.log('EzKlean: erro JSON-RPC updates: {}'.format(e), xbmc.LOGWARNING)


# ── Monitor principal ─────────────────────────────────────────────────────

class EzKleanMonitor(xbmc.Monitor):
    """
    Deteta o arranque completo do Kodi via notificacoes do sistema.
    Muito mais fiavel do que um timeout fixo (especialmente em Android/CoreELEC).
    Inspirado na abordagem do OptiKlean.
    """
    def __init__(self):
        super().__init__()
        self.kodi_ready = False

    def onNotification(self, sender, method, data):
        if not self.kodi_ready and method.startswith(
            ('GUI.', 'Player.', 'VideoLibrary.', 'AudioLibrary.', 'Input.')
        ):
            self.kodi_ready = True
            xbmc.log('EzKlean: Kodi pronto (via {})'.format(method), xbmc.LOGINFO)


if __name__ == '__main__':
    xbmc.log('EzKlean service: iniciado v1.0.1', xbmc.LOGINFO)

    monitor      = EzKleanMonitor()
    idle_counter = 0

    # Aguardar o Kodi estar completamente pronto
    elapsed = 0
    while not monitor.abortRequested() and not monitor.kodi_ready and elapsed < STARTUP_MAX:
        if monitor.waitForAbort(STARTUP_WAIT):
            break
        elapsed += STARTUP_WAIT

    if not monitor.kodi_ready:
        xbmc.log('EzKlean: timeout de arranque - continuando', xbmc.LOGWARNING)
        monitor.kodi_ready = True

    if monitor.abortRequested():
        xbmc.log('EzKlean service: terminado (abort no arranque)', xbmc.LOGINFO)
        exit()

    # ── Accoes no arranque (por ordem de impacto no sistema) ─────────────

    # 1. Updates de addons (primeiro - o Kodi pode precisar de actualizar coisas)
    if should_check_updates() and not xbmc.Player().isPlaying():
        run_addon_updates()

    # 2. Limpeza automatica (se devida)
    if should_clean():
        if not xbmc.Player().isPlaying():
            run_auto_clean()
            idle_counter = 0
        else:
            xbmc.log('EzKlean: reproducao ativa no arranque - limpeza adiada', xbmc.LOGINFO)

    # ── Loop principal: verificar a cada 6 horas ──────────────────────────
    while not monitor.abortRequested():
        if monitor.waitForAbort(CHECK_INTERVAL):
            break

        # Updates de addons (uma vez por dia)
        if should_check_updates() and not xbmc.Player().isPlaying():
            run_addon_updates()

        # Limpeza (conforme intervalo configurado)
        if not should_clean():
            continue

        if xbmc.Player().isPlaying():
            idle_counter += 1
            xbmc.log(
                'EzKlean: reproducao ativa, limpeza adiada (tentativa {}/10)'.format(idle_counter),
                xbmc.LOGINFO
            )
            if idle_counter < 10:
                continue

        run_auto_clean()
        idle_counter = 0

    xbmc.log('EzKlean service: terminado', xbmc.LOGINFO)
