# EzKlean - Cleaning functions
# Based on OptikLean engine (MIT) - simplified for EzKlean

import os
import sqlite3
import time
import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.utils import (
    CRITICAL_CACHE_ADDONS, DELETE_SUCCESS, DELETE_LOCKED,
    ensure_trailing_slash, get_file_size, get_folder_size,
    delete_file, delete_folder_recursive,
    find_latest_db, get_kodi_version
)

ADDON_ID = "program.ezklean"


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def _s(string_id):
    return _addon().getLocalizedString(string_id)


def _logo():
    addon = _addon()
    path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    return os.path.join(path, 'resources', 'media', 'icon.png')


def _notify(msg, duration=3000):
    xbmcgui.Dialog().notification("EzKlean", msg, _logo(), duration)


# ─────────────────────────────────────────────
# 1. CACHE & TEMP
# ─────────────────────────────────────────────

def _is_safe_temp_file(filename):
    protected = {'kodi.log', 'kodi.old.log', 'commoncache.db', 'commoncache.socket'}
    return filename not in protected


def _clear_folder_files(folder, progress=None, safe_extensions=None):
    """Delete all non-protected files (and subfolders) in a folder.
    Returns (total_deleted_bytes, count)."""
    folder = ensure_trailing_slash(folder)
    total_bytes = 0
    count = 0
    if not xbmcvfs.exists(folder):
        return 0, 0
    try:
        dirs, files = xbmcvfs.listdir(folder)
        for f in files:
            if progress and progress.iscanceled():
                break
            fp = xbmcvfs.makeLegalFilename(folder + f)
            if safe_extensions and not _is_safe_temp_file(f):
                continue
            sz = get_file_size(fp)
            status, _ = delete_file(fp)
            if status == DELETE_SUCCESS:
                total_bytes += sz
                count += 1
        for d in dirs:
            if progress and progress.iscanceled():
                break
            dp = os.path.join(folder.rstrip('/'), d)
            success, _ = delete_folder_recursive(dp)
            if success:
                count += 1
    except Exception as e:
        xbmc.log(f"EzKlean: _clear_folder_files error: {e}", xbmc.LOGERROR)
    return total_bytes, count


def clear_cache_and_temp(auto_mode=False, progress=None):
    """Clear Kodi temp folder + addon data cache/temp folders."""
    if not auto_mode:
        choices = [
            _s(32104),  # Kodi temp folder
            _s(32105),  # cache files from addon data
            _s(32106),  # temp folders from addon data
            _s(32107),  # addons temp folder
        ]
        selected = xbmcgui.Dialog().multiselect(_s(32103), choices)
        if selected is None:
            return 0
    else:
        selected = [0, 1, 2, 3]

    close_progress = False
    if progress is None:
        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32124))
        close_progress = True

    total_bytes = 0

    try:
        temp_path = xbmcvfs.translatePath("special://temp/")
        addon_data_path = ensure_trailing_slash(xbmcvfs.translatePath("special://profile/addon_data/"))
        addons_temp_path = xbmcvfs.translatePath("special://home/addons/temp/")

        # Option 0: Kodi temp folder
        if 0 in selected and not progress.iscanceled():
            progress.update(10, _s(32104))
            temp_path_s = ensure_trailing_slash(temp_path)
            if xbmcvfs.exists(temp_path_s):
                try:
                    dirs, files = xbmcvfs.listdir(temp_path_s)
                    for f in files:
                        if _is_safe_temp_file(f):
                            fp = xbmcvfs.makeLegalFilename(temp_path_s + f)
                            sz = get_file_size(fp)
                            status, _ = delete_file(fp)
                            if status == DELETE_SUCCESS:
                                total_bytes += sz
                    for d in dirs:
                        dp = os.path.join(temp_path.rstrip('/'), d)
                        bef = get_folder_size(dp)
                        success, _ = delete_folder_recursive(dp)
                        if success:
                            total_bytes += bef
                except Exception as e:
                    xbmc.log(f"EzKlean: temp folder error: {e}", xbmc.LOGERROR)

        # Option 1: cache files from addon data
        if 1 in selected and not progress.iscanceled():
            progress.update(30, _s(32105))
            if xbmcvfs.exists(addon_data_path):
                try:
                    addon_dirs, _ = xbmcvfs.listdir(addon_data_path)
                    for aid in addon_dirs:
                        if aid in CRITICAL_CACHE_ADDONS:
                            continue
                        cache_p = ensure_trailing_slash(
                            xbmcvfs.makeLegalFilename(f"{addon_data_path}{aid}/cache/")
                        )
                        if xbmcvfs.exists(cache_p):
                            b, _ = _clear_folder_files(cache_p, progress)
                            total_bytes += b
                except Exception as e:
                    xbmc.log(f"EzKlean: addon cache error: {e}", xbmc.LOGERROR)

        # Option 2: temp folders from addon data
        if 2 in selected and not progress.iscanceled():
            progress.update(55, _s(32106))
            if xbmcvfs.exists(addon_data_path):
                try:
                    addon_dirs, _ = xbmcvfs.listdir(addon_data_path)
                    for aid in addon_dirs:
                        if aid in CRITICAL_CACHE_ADDONS:
                            continue
                        for tf in ['temp', 'tmp']:
                            tp = ensure_trailing_slash(
                                xbmcvfs.makeLegalFilename(f"{addon_data_path}{aid}/{tf}/")
                            )
                            if xbmcvfs.exists(tp):
                                b, _ = _clear_folder_files(tp, progress)
                                total_bytes += b
                except Exception as e:
                    xbmc.log(f"EzKlean: addon temp error: {e}", xbmc.LOGERROR)

        # Option 3: addons temp folder
        if 3 in selected and not progress.iscanceled():
            progress.update(80, _s(32107))
            if xbmcvfs.exists(ensure_trailing_slash(addons_temp_path)):
                b, _ = _clear_folder_files(ensure_trailing_slash(addons_temp_path), progress)
                total_bytes += b

        progress.update(100)

    finally:
        if close_progress:
            progress.close()

    total_mb = total_bytes / 1048576
    if not auto_mode:
        _notify(_s(32101).format(total_mb=total_mb))
    return total_bytes


# ─────────────────────────────────────────────
# 2. THUMBNAILS
# ─────────────────────────────────────────────

def clear_thumbnails(auto_mode=False, progress=None):
    """Clear unused and/or old thumbnails."""
    if not auto_mode:
        choices = [_s(32109), _s(32110)]
        selected = xbmcgui.Dialog().multiselect(_s(32108), choices)
        if selected is None or len(selected) == 0:
            return 0
    else:
        selected = [0, 1]

    close_progress = False
    if progress is None:
        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32124))
        close_progress = True

    total_bytes = 0
    total_files = 0

    db_path = ensure_trailing_slash(xbmcvfs.translatePath("special://database/"))
    thumb_path = ensure_trailing_slash(xbmcvfs.translatePath("special://userdata/Thumbnails/"))
    if not xbmcvfs.exists(thumb_path):
        thumb_path = ensure_trailing_slash(xbmcvfs.translatePath("special://thumbnails/"))

    texture_db = find_latest_db(db_path, "Textures*.db")

    try:
        # Option 0: unused thumbnails
        if 0 in selected and texture_db and xbmcvfs.exists(thumb_path):
            progress.update(10, _s(32109))
            try:
                conn = sqlite3.connect(texture_db)
                cur = conn.cursor()
                cur.execute("SELECT cachedurl FROM texture")
                valid = set(r[0] for r in cur.fetchall())
                conn.close()

                def _scan_unused(base):
                    nb, nc = 0, 0
                    if not xbmcvfs.exists(base):
                        return 0, 0
                    try:
                        dirs, files = xbmcvfs.listdir(base)
                        for f in files:
                            fp = xbmcvfs.makeLegalFilename(base + f)
                            rel = os.path.relpath(fp, thumb_path).replace('\\', '/')
                            if rel not in valid:
                                sz = get_file_size(fp)
                                status, _ = delete_file(fp)
                                if status == DELETE_SUCCESS:
                                    nb += sz
                                    nc += 1
                        for d in dirs:
                            dp = ensure_trailing_slash(xbmcvfs.makeLegalFilename(base + d))
                            sb, sc = _scan_unused(dp)
                            nb += sb
                            nc += sc
                    except Exception:
                        pass
                    return nb, sc

                b, c = _scan_unused(thumb_path)
                total_bytes += b
                total_files += c
            except Exception as e:
                xbmc.log(f"EzKlean: unused thumbnails error: {e}", xbmc.LOGERROR)

        # Option 1: thumbnails older than 30 days
        if 1 in selected and texture_db and not progress.iscanceled():
            progress.update(60, _s(32110))
            try:
                threshold = int(time.time()) - (30 * 86400)
                from datetime import datetime
                threshold_dt = datetime.fromtimestamp(threshold).strftime("%Y-%m-%d %H:%M:%S")

                conn = sqlite3.connect(texture_db)
                cur = conn.cursor()
                # Check tables exist
                cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = {r[0] for r in cur.fetchall()}
                if 'sizes' in tables and 'texture' in tables:
                    cur.execute("""
                        SELECT t.id, t.cachedurl
                        FROM sizes s
                        INNER JOIN texture t ON s.idtexture = t.id
                        WHERE s.lastusetime < ?
                    """, (threshold_dt,))
                    old_rows = cur.fetchall()
                    ids_to_delete = []
                    for tid, cachedurl in old_rows:
                        if progress.iscanceled():
                            break
                        fp = xbmcvfs.makeLegalFilename(thumb_path + cachedurl)
                        if xbmcvfs.exists(fp):
                            sz = get_file_size(fp)
                            status, _ = delete_file(fp)
                            if status == DELETE_SUCCESS:
                                total_bytes += sz
                                total_files += 1
                        ids_to_delete.append(tid)
                    for tid in ids_to_delete:
                        try:
                            cur.execute("DELETE FROM sizes WHERE idtexture=?", (tid,))
                            cur.execute("DELETE FROM texture WHERE id=?", (tid,))
                        except Exception:
                            pass
                    try:
                        conn.commit()
                        cur.execute("VACUUM")
                    except Exception:
                        pass
                conn.close()
            except Exception as e:
                xbmc.log(f"EzKlean: old thumbnails error: {e}", xbmc.LOGERROR)

        progress.update(100)

    finally:
        if close_progress:
            progress.close()

    total_mb = total_bytes / 1048576
    if not auto_mode:
        _notify(_s(32134).format(count=total_files, size=total_mb))
    return total_bytes


# ─────────────────────────────────────────────
# 3. ADDON LEFTOVERS
# ─────────────────────────────────────────────

def clear_addon_leftovers(auto_mode=False, progress=None):
    """Find and remove disabled/orphaned addon folders."""
    close_progress = False
    if progress is None:
        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32125))
        close_progress = True

    total_bytes = 0
    total_count = 0

    try:
        progress.update(10)
        import json as _json

        def _get_addon_ids(enabled):
            try:
                resp = xbmc.executeJSONRPC(
                    f'{{"jsonrpc":"2.0","method":"Addons.GetAddons","params":{{"enabled":{"true" if enabled else "false"}}},"id":1}}'
                )
                data = _json.loads(resp)
                return {a['addonid'] for a in data.get('result', {}).get('addons', [])}
            except Exception:
                return set()

        enabled = _get_addon_ids(True)
        disabled = _get_addon_ids(False)
        all_installed = enabled | disabled

        addon_dir = xbmcvfs.translatePath("special://home/addons/")
        addon_data_dir = xbmcvfs.translatePath("special://home/userdata/addon_data/")

        def _list_dirs(path):
            try:
                d, _ = xbmcvfs.listdir(ensure_trailing_slash(path))
                return set(d)
            except Exception:
                return set()

        existing_addons = _list_dirs(addon_dir)
        existing_data = _list_dirs(addon_data_dir)

        display_list = []
        folder_map = {}

        skip = {'packages', 'temp', '.git'}

        for folder in sorted(existing_addons):
            if folder in skip:
                continue
            if folder in disabled:
                label = f"{_s(32126)}: {folder} (addons)"
                display_list.append(label)
                folder_map[label] = os.path.join(addon_dir, folder)
            elif folder not in all_installed:
                label = f"{_s(32127)}: {folder} (addons)"
                display_list.append(label)
                folder_map[label] = os.path.join(addon_dir, folder)

        for folder in sorted(existing_data):
            if folder in skip:
                continue
            if folder in disabled:
                label = f"{_s(32126)}: {folder} (addon_data)"
                display_list.append(label)
                folder_map[label] = os.path.join(addon_data_dir, folder)
            elif folder not in all_installed:
                label = f"{_s(32127)}: {folder} (addon_data)"
                display_list.append(label)
                folder_map[label] = os.path.join(addon_data_dir, folder)

        progress.close()
        close_progress = False

        if not display_list:
            if not auto_mode:
                xbmcgui.Dialog().ok("EzKlean", _s(32111))
            return 0

        if auto_mode:
            selected_names = display_list
        else:
            selected_idx = xbmcgui.Dialog().multiselect(_s(32112), display_list)
            if not selected_idx:
                return 0
            selected_names = [display_list[i] for i in selected_idx]

        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32124))
        close_progress = True

        for name in selected_names:
            if progress.iscanceled():
                break
            fp = folder_map[name]
            sz = get_folder_size(fp)
            success, _ = delete_folder_recursive(fp)
            if success:
                total_bytes += sz
                total_count += 1

        progress.update(100)

    finally:
        if close_progress:
            progress.close()

    total_mb = total_bytes / 1048576
    if not auto_mode:
        _notify(_s(32135).format(count=total_count, size=total_mb))
    return total_bytes


# ─────────────────────────────────────────────
# 4. PACKAGES
# ─────────────────────────────────────────────

def clear_packages(auto_mode=False, progress=None):
    """Delete all .zip files from the Kodi packages folder."""
    packages_path = xbmcvfs.translatePath("special://home/addons/packages")
    packages_path_s = ensure_trailing_slash(packages_path)

    if not xbmcvfs.exists(packages_path_s):
        if not auto_mode:
            _notify(_s(32113))
        return 0

    close_progress = False
    if progress is None:
        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32124))
        close_progress = True

    total_bytes = 0
    count = 0

    try:
        _, files = xbmcvfs.listdir(packages_path_s)
        zip_files = [f for f in files if f.lower().endswith('.zip')]

        if not zip_files:
            if not auto_mode:
                _notify(_s(32113))
            return 0

        for i, f in enumerate(zip_files):
            if progress.iscanceled():
                break
            progress.update(int(i / len(zip_files) * 100), f)
            fp = xbmcvfs.makeLegalFilename(packages_path_s + f)
            sz = get_file_size(fp)
            status, _ = delete_file(fp)
            if status == DELETE_SUCCESS:
                total_bytes += sz
                count += 1

        progress.update(100)

    finally:
        if close_progress:
            progress.close()

    total_mb = total_bytes / 1048576
    if not auto_mode:
        if count > 0:
            _notify(_s(32114).format(count=count, size=total_mb))
        else:
            _notify(_s(32115))
    return total_bytes


# ─────────────────────────────────────────────
# 5. OPTIMIZE DATABASES
# ─────────────────────────────────────────────

def optimize_databases(auto_mode=False, progress=None):
    """VACUUM all Kodi and addon SQLite databases."""
    if not auto_mode:
        confirmed = xbmcgui.Dialog().yesno(_s(32116), _s(32117))
        if not confirmed:
            return 0

    close_progress = False
    if progress is None:
        progress = xbmcgui.DialogProgress()
        progress.create("EzKlean", _s(32124))
        close_progress = True

    optimized = 0

    try:
        db_dir = ensure_trailing_slash(xbmcvfs.translatePath("special://database/"))
        addon_data_dir = ensure_trailing_slash(xbmcvfs.translatePath("special://userdata/addon_data/"))

        all_dbs = []

        # Standard Kodi databases
        if xbmcvfs.exists(db_dir):
            try:
                _, files = xbmcvfs.listdir(db_dir)
                for f in files:
                    if f.lower().endswith(('.db', '.sqlite')):
                        all_dbs.append(xbmcvfs.makeLegalFilename(db_dir + f))
            except Exception:
                pass

        # Addon databases
        if xbmcvfs.exists(addon_data_dir):
            try:
                addon_dirs, _ = xbmcvfs.listdir(addon_data_dir)
                for aid in addon_dirs:
                    ap = ensure_trailing_slash(xbmcvfs.makeLegalFilename(addon_data_dir + aid))
                    if xbmcvfs.exists(ap):
                        try:
                            _, afiles = xbmcvfs.listdir(ap)
                            for af in afiles:
                                if af.lower().endswith(('.db', '.sqlite')):
                                    all_dbs.append(xbmcvfs.makeLegalFilename(ap + af))
                        except Exception:
                            pass
            except Exception:
                pass

        if not all_dbs:
            if not auto_mode:
                _notify(_s(32119))
            return 0

        for i, db_path in enumerate(all_dbs):
            if progress.iscanceled():
                break
            progress.update(int(i / len(all_dbs) * 100), os.path.basename(db_path))
            try:
                conn = sqlite3.connect(db_path, timeout=2)
                conn.execute("PRAGMA quick_check;")
                conn.execute("VACUUM;")
                conn.close()
                optimized += 1
            except Exception:
                pass

        progress.update(100)

    finally:
        if close_progress:
            progress.close()

    if not auto_mode:
        _notify(_s(32118).format(count=optimized))
    return optimized


# ─────────────────────────────────────────────
# 6. CLEAN EVERYTHING
# ─────────────────────────────────────────────

def clean_everything(auto_mode=False):
    """Run all cleaning operations in sequence."""
    progress = xbmcgui.DialogProgress()
    progress.create("EzKlean", _s(32124))
    total_bytes = 0
    try:
        if not progress.iscanceled():
            progress.update(5, _s(32001))
            total_bytes += clear_cache_and_temp(auto_mode=True, progress=progress)
        if not progress.iscanceled():
            progress.update(35, _s(32002))
            total_bytes += clear_thumbnails(auto_mode=True, progress=progress)
        if not progress.iscanceled():
            progress.update(60, _s(32003))
            total_bytes += clear_addon_leftovers(auto_mode=True, progress=progress)
        if not progress.iscanceled():
            progress.update(80, _s(32004))
            total_bytes += clear_packages(auto_mode=True, progress=progress)
        if not progress.iscanceled():
            progress.update(90, _s(32005))
            optimize_databases(auto_mode=True, progress=progress)
        progress.update(100)
    finally:
        progress.close()

    total_mb = total_bytes / 1048576
    _notify(_s(32101).format(total_mb=total_mb), duration=5000)
    return total_bytes


# ─────────────────────────────────────────────
# 7. FRESH START
# ─────────────────────────────────────────────

def fresh_start():
    """Wipe all Kodi userdata. Double confirmation required."""
    if not xbmcgui.Dialog().yesno(_s(32120), _s(32121)):
        return
    if not xbmcgui.Dialog().yesno("EzKlean", _s(32122)):
        return

    progress = xbmcgui.DialogProgress()
    progress.create("EzKlean", _s(32124))
    try:
        userdata = xbmcvfs.translatePath("special://userdata/")
        dirs, files = xbmcvfs.listdir(ensure_trailing_slash(userdata))
        total = len(dirs) + len(files)
        for i, f in enumerate(files):
            fp = xbmcvfs.makeLegalFilename(ensure_trailing_slash(userdata) + f)
            delete_file(fp)
            progress.update(int(i / total * 100))
        for i, d in enumerate(dirs, start=len(files)):
            dp = os.path.join(userdata, d)
            delete_folder_recursive(dp)
            progress.update(int(i / total * 100))
        progress.update(100)
    finally:
        progress.close()

    xbmcgui.Dialog().ok("EzKlean", _s(32123))
    xbmc.executebuiltin('RestartApp')
