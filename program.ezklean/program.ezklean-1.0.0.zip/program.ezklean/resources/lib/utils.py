# EzKlean - Utility functions
import os
import sqlite3
import fnmatch
import re
import time
import errno
import shutil

import xbmc
import xbmcvfs

ADDON_ID = "program.ezklean"

DELETE_SUCCESS = "success"
DELETE_LOCKED = "locked"
DELETE_ERROR = "error"

# Critical addons whose caches should never be cleared
CRITICAL_CACHE_ADDONS = [
    "script.module.inputstreamhelper",
    "inputstream.adaptive",
    "inputstream.rtmp",
    "script.module.resolveurl",
    "plugin.video.youtube",
    "plugin.video.netflix",
    "plugin.video.amazon",
    "plugin.video.disneyplus",
    "script.common.plugin.cache",
    "pvr.iptvsimple",
]


def ensure_trailing_slash(path):
    return path.rstrip('/') + '/'


def get_file_size(file_path):
    try:
        stat = xbmcvfs.Stat(file_path)
        return stat.st_size() if stat else 0
    except Exception:
        try:
            return os.path.getsize(file_path)
        except Exception:
            return 0


def get_folder_size(folder_path):
    total = 0
    try:
        folder_path = ensure_trailing_slash(folder_path)
        dirs, files = xbmcvfs.listdir(folder_path)
        for f in files:
            fp = xbmcvfs.makeLegalFilename(folder_path + f)
            total += get_file_size(fp)
        for d in dirs:
            dp = xbmcvfs.makeLegalFilename(folder_path + d)
            total += get_folder_size(dp)
    except Exception:
        try:
            for root, dirs, files in os.walk(folder_path.rstrip('/')):
                for f in files:
                    try:
                        total += os.path.getsize(os.path.join(root, f))
                    except Exception:
                        pass
        except Exception:
            pass
    return total


def format_size(size_bytes):
    if size_bytes >= 1073741824:
        return f"{size_bytes / 1073741824:.2f} GB"
    if size_bytes >= 1048576:
        return f"{size_bytes / 1048576:.2f} MB"
    if size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KB"
    return f"{size_bytes} B"


def delete_file(file_path, retry_count=2, retry_delay=0.3):
    if not xbmcvfs.exists(file_path):
        return DELETE_SUCCESS, ""
    for attempt in range(retry_count + 1):
        try:
            if xbmcvfs.delete(file_path):
                return DELETE_SUCCESS, ""
            # fallback
            try:
                os.remove(file_path)
                return DELETE_SUCCESS, ""
            except Exception as e:
                return DELETE_ERROR, str(e)
        except OSError as e:
            if e.errno in (errno.EACCES, errno.EPERM, errno.EBUSY, errno.EAGAIN):
                if attempt < retry_count:
                    time.sleep(retry_delay)
                    continue
                return DELETE_LOCKED, str(e)
            return DELETE_ERROR, str(e)
        except Exception as e:
            return DELETE_ERROR, str(e)
    return DELETE_LOCKED, "File appears locked"


def delete_folder_recursive(folder_path):
    """Delete a folder and all its contents. Returns (success, locked_files)."""
    folder_path = os.path.normpath(folder_path)
    if not os.path.exists(folder_path) and not xbmcvfs.exists(folder_path + '/'):
        return True, []
    locked = []
    try:
        shutil.rmtree(folder_path)
        return True, []
    except Exception:
        pass
    # fallback manual
    try:
        dirs, files = xbmcvfs.listdir(ensure_trailing_slash(folder_path))
        for f in files:
            fp = os.path.join(folder_path, f)
            status, _ = delete_file(fp)
            if status == DELETE_LOCKED:
                locked.append(fp)
        for d in dirs:
            dp = os.path.join(folder_path, d)
            _, sub_locked = delete_folder_recursive(dp)
            locked.extend(sub_locked)
        if not locked:
            try:
                xbmcvfs.rmdir(ensure_trailing_slash(folder_path))
            except Exception:
                try:
                    os.rmdir(folder_path)
                except Exception:
                    pass
    except Exception:
        pass
    return len(locked) == 0, locked


def find_latest_db(db_dir, pattern):
    """Find the latest versioned database matching pattern."""
    db_dir = ensure_trailing_slash(db_dir)
    if not xbmcvfs.exists(db_dir):
        return None
    try:
        _, files = xbmcvfs.listdir(db_dir)
        matches = [f for f in files if fnmatch.fnmatch(f, pattern)]
        if not matches:
            return None

        def extract_ver(fn):
            m = re.search(r'(\d+)', fn)
            return int(m.group(1)) if m else 0

        matches.sort(key=extract_ver, reverse=True)
        return xbmcvfs.translatePath(db_dir + matches[0])
    except Exception:
        return None


def get_kodi_version():
    try:
        ver = xbmc.getInfoLabel('System.BuildVersion')
        return int(ver.split('.')[0]) if ver else 0
    except Exception:
        return 0
