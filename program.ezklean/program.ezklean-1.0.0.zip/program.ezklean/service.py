# EzKlean - Background service for automatic cleaning
# Runs on Kodi startup and checks if cleaning is due

import os
import json
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON_ID = "program.ezklean"


def get_addon():
    return xbmcaddon.Addon(ADDON_ID)


def get_data_folder():
    addon = get_addon()
    path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def get_last_run():
    data_folder = get_data_folder()
    last_run_file = os.path.join(data_folder, 'last_auto_clean.json')
    try:
        if xbmcvfs.exists(last_run_file):
            with open(last_run_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get('timestamp', 0)
    except Exception as e:
        xbmc.log(f"EzKlean service: Error reading last run: {e}", xbmc.LOGERROR)
    return 0


def save_last_run():
    data_folder = get_data_folder()
    last_run_file = os.path.join(data_folder, 'last_auto_clean.json')
    try:
        with open(last_run_file, 'w', encoding='utf-8') as f:
            json.dump({'timestamp': int(time.time())}, f)
    except Exception as e:
        xbmc.log(f"EzKlean service: Error saving last run: {e}", xbmc.LOGERROR)


def should_run():
    addon = get_addon()
    if not addon.getSettingBool('auto_clean_enable'):
        return False
    interval_days = addon.getSettingInt('auto_clean_interval')
    last = get_last_run()
    if last == 0:
        return True  # First run
    next_run = last + (interval_days * 86400)
    return int(time.time()) >= next_run


def run_auto_clean():
    xbmc.log("EzKlean service: Starting automatic cleaning", xbmc.LOGINFO)
    try:
        from resources.lib.cleaner import (
            clear_cache_and_temp, clear_thumbnails,
            clear_addon_leftovers, clear_packages, optimize_databases
        )
        done = []

        total = clear_cache_and_temp(auto_mode=True)
        if total > 0:
            done.append("Cache/Temp")

        clear_thumbnails(auto_mode=True)
        done.append("Thumbnails")

        clear_addon_leftovers(auto_mode=True)

        clear_packages(auto_mode=True)

        optimize_databases(auto_mode=True)

        save_last_run()

        addon = get_addon()
        if done:
            msg = addon.getLocalizedString(32128).format(items=', '.join(done))
            xbmc.executebuiltin(f'Notification(EzKlean, {msg}, 4000)')

        xbmc.log("EzKlean service: Automatic cleaning complete", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"EzKlean service: Auto clean error: {e}", xbmc.LOGERROR)


class EzKleanMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.cleaning_done = False


if __name__ == '__main__':
    xbmc.log("EzKlean service: Started", xbmc.LOGINFO)

    monitor = EzKleanMonitor()

    # Wait for Kodi to settle before first check
    wait = 0
    while not monitor.abortRequested() and wait < 30:
        if monitor.waitForAbort(5):
            break
        wait += 5

    # Run cleaning if due
    if not monitor.abortRequested() and should_run():
        # Additional delay while Kodi finishes startup
        if not xbmc.Player().isPlaying():
            run_auto_clean()
        else:
            # Wait until playback finishes
            xbmc.log("EzKlean service: Playback active, deferring cleaning", xbmc.LOGINFO)

    # Main loop: re-check every hour
    while not monitor.abortRequested():
        if monitor.waitForAbort(3600):
            break
        if should_run() and not xbmc.Player().isPlaying():
            run_auto_clean()

    xbmc.log("EzKlean service: Stopped", xbmc.LOGINFO)
