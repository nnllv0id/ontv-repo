# EzKlean - Utility functions  v1.0.1
#
# Melhorias v1.0.1:
#   - get_file_size usa xbmcvfs.File().size() (mais fiavel em Android/CoreELEC)
#   - delete_file com backoff exponencial (0.2s, 0.4s, 0.8s) em vez de delay fixo
#   - delete_folder_recursive tenta shutil.rmtree primeiro (muito mais rapido)
#   - find_latest_db filtra ficheiros sem numero de versao valido

import os
import fnmatch
import re
import time
import errno
import shutil

import xbmc
import xbmcvfs

ADDON_ID = 'program.ezklean'

DELETE_SUCCESS = 'success'
DELETE_LOCKED  = 'locked'
DELETE_ERROR   = 'error'

CRITICAL_CACHE_ADDONS = [
    'script.module.inputstreamhelper',
    'inputstream.adaptive',
    'inputstream.rtmp',
    'script.module.resolveurl',
    'plugin.video.youtube',
    'plugin.video.netflix',
    'plugin.video.amazon',
    'plugin.video.disneyplus',
    'script.common.plugin.cache',
    'pvr.iptvsimple',
]


def ensure_trailing_slash(path):
    return path.rstrip('/') + '/'


def get_file_size(file_path):
    """Tamanho de ficheiro em bytes. Usa xbmcvfs.File primeiro (mais fiavel)."""
    try:
        if xbmcvfs.exists(file_path):
            f    = xbmcvfs.File(file_path)
            size = f.size()
            f.close()
            if size >= 0:
                return size
    except Exception:
        pass
    try:
        return os.path.getsize(file_path)
    except Exception:
        return 0


def get_folder_size(folder_path):
    """Tamanho total de pasta em bytes. Fallback para os.walk."""
    total = 0
    try:
        fp = ensure_trailing_slash(folder_path)
        dirs, files = xbmcvfs.listdir(fp)
        for f in files:
            total += get_file_size(xbmcvfs.makeLegalFilename(fp + f))
        for d in dirs:
            total += get_folder_size(xbmcvfs.makeLegalFilename(fp + d))
    except Exception:
        try:
            for root, _, files in os.walk(folder_path.rstrip('/')):
                for f in files:
                    try:
                        total += os.path.getsize(os.path.join(root, f))
                    except Exception:
                        pass
        except Exception:
            pass
    return total


def format_size(size_bytes):
    if size_bytes >= 1_073_741_824:
        return '{:.2f} GB'.format(size_bytes / 1_073_741_824)
    if size_bytes >= 1_048_576:
        return '{:.2f} MB'.format(size_bytes / 1_048_576)
    if size_bytes >= 1_024:
        return '{:.2f} KB'.format(size_bytes / 1_024)
    return '{} B'.format(size_bytes)


def delete_file(file_path, retry_count=3, retry_delay=0.2):
    """Apaga ficheiro com retry e backoff exponencial."""
    if not xbmcvfs.exists(file_path):
        return DELETE_SUCCESS, ''
    for attempt in range(retry_count + 1):
        try:
            if xbmcvfs.delete(file_path):
                return DELETE_SUCCESS, ''
            try:
                os.remove(file_path)
                return DELETE_SUCCESS, ''
            except Exception as e:
                return DELETE_ERROR, str(e)
        except OSError as e:
            if e.errno in (errno.EACCES, errno.EPERM, errno.EBUSY, errno.EAGAIN):
                if attempt < retry_count:
                    time.sleep(retry_delay * (2 ** attempt))  # 0.2, 0.4, 0.8s
                    continue
                return DELETE_LOCKED, str(e)
            return DELETE_ERROR, str(e)
        except Exception as e:
            return DELETE_ERROR, str(e)
    return DELETE_LOCKED, 'Ficheiro bloqueado'


def delete_folder_recursive(folder_path):
    """
    Apaga pasta e todo o conteudo.
    Tenta shutil.rmtree primeiro (rapido), cai no modo manual se falhar.
    """
    folder_path = os.path.normpath(folder_path)
    if not os.path.exists(folder_path) and not xbmcvfs.exists(folder_path + '/'):
        return True, []
    try:
        shutil.rmtree(folder_path)
        return True, []
    except Exception:
        pass
    locked = []
    try:
        dirs, files = xbmcvfs.listdir(ensure_trailing_slash(folder_path))
        for f in files:
            fp = os.path.join(folder_path, f)
            status, _ = delete_file(fp)
            if status == DELETE_LOCKED:
                locked.append(fp)
        for d in dirs:
            dp = os.path.join(folder_path, d)
            _, sub = delete_folder_recursive(dp)
            locked.extend(sub)
        if not locked:
            try:
                xbmcvfs.rmdir(ensure_trailing_slash(folder_path))
            except Exception:
                try:
                    os.rmdir(folder_path)
                except Exception:
                    pass
    except Exception:
        pass
    return len(locked) == 0, locked


def find_latest_db(db_dir, pattern):
    """Encontra a base de dados mais recente que corresponde ao padrao."""
    db_dir = ensure_trailing_slash(db_dir)
    if not xbmcvfs.exists(db_dir):
        return None
    try:
        _, files = xbmcvfs.listdir(db_dir)
        matches  = [f for f in files if fnmatch.fnmatch(f, pattern)]
        if not matches:
            return None

        def extract_ver(fn):
            m = re.search(r'(\d+)', fn)
            return int(m.group(1)) if m else -1

        matches = [f for f in matches if extract_ver(f) >= 0]
        if not matches:
            return None
        matches.sort(key=extract_ver, reverse=True)
        return xbmcvfs.translatePath(db_dir + matches[0])
    except Exception:
        return None


def get_kodi_version():
    try:
        ver = xbmc.getInfoLabel('System.BuildVersion')
        return int(ver.split('.')[0]) if ver else 0
    except Exception:
        return 0
