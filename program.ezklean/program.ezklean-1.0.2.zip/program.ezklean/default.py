# EzKlean - Main addon entry point
# Kodi 21+ compatible maintenance addon

import sys
import os

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_ID = "program.ezklean"

addon = xbmcaddon.Addon(ADDON_ID)
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
media_path = os.path.join(addon_path, 'resources', 'media')

try:
    addon_handle = int(sys.argv[1])
except (IndexError, ValueError):
    addon_handle = -1

base_url = sys.argv[0]


def _s(string_id):
    return addon.getLocalizedString(string_id)


def _icon(name):
    return os.path.join(media_path, name)


def _fanart():
    return _icon('fanart.png')


def _logo():
    return _icon('icon.png')


def show_menu():
    xbmcplugin.setPluginFanart(addon_handle, _fanart())

    # Check if Fresh Start should be shown
    show_fresh = addon.getSettingBool('show_fresh_start')

    menu = [
        (_s(32000), 'clean_everything',    'icon.png'),
        (_s(32001), 'clear_cache',         'icon.png'),
        (_s(32002), 'clear_thumbnails',    'icon.png'),
        (_s(32003), 'clear_leftovers',     'icon.png'),
        (_s(32004), 'clear_packages',      'icon.png'),
        (_s(32005), 'optimize_databases',  'icon.png'),
        (_s(32006), 'open_settings',       'icon.png'),
    ]

    if show_fresh:
        menu.append((_s(32007), 'fresh_start', 'icon.png'))

    for label, action, icon in menu:
        li = xbmcgui.ListItem(label)
        li.setArt({
            'icon':   _icon(icon),
            'thumb':  _icon(icon),
            'fanart': _fanart(),
        })
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=f"{base_url}?action={action}",
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(addon_handle)


def handle_action(action):
    from resources.lib import cleaner

    if action == 'clean_everything':
        cleaner.clean_everything()
    elif action == 'clear_cache':
        cleaner.clear_cache_and_temp()
    elif action == 'clear_thumbnails':
        cleaner.clear_thumbnails()
    elif action == 'clear_leftovers':
        cleaner.clear_addon_leftovers()
    elif action == 'clear_packages':
        cleaner.clear_packages()
    elif action == 'optimize_databases':
        cleaner.optimize_databases()
    elif action == 'fresh_start':
        cleaner.fresh_start()
    elif action == 'open_settings':
        addon.openSettings()
    else:
        show_menu()


if __name__ == '__main__':
    params = {}
    if len(sys.argv) > 2 and sys.argv[2].startswith('?'):
        params = dict(
            p.split('=') for p in sys.argv[2][1:].split('&') if '=' in p
        )

    action = params.get('action')
    if action:
        handle_action(action)
    else:
        show_menu()
