# -*- coding: utf-8 -*-
"""
SportHub v3 — default.py
"""
import os, sys, socket
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import parse_qsl, unquote_plus, quote_plus, urlparse
except ImportError:
    from urllib import unquote_plus, quote_plus
    from urlparse import parse_qsl, urlparse

from resources.lib import utils
from resources.lib import hub

socket.setdefaulttimeout(60)

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')


def route(params):
    mode = params.get('mode', 'main')

    # ── Menu principal ────────────────────────────────────────────────────────
    if mode == 'main':
        hub.show_main()

    # ── Categoria de desporto (agrega todos os sites) ─────────────────────────
    elif mode == 'sport_category':
        sport_id = params.get('sport', 'football')
        hub.show_sport_category(sport_id)

    # ── Lista de streams para um evento ───────────────────────────────────────
    elif mode == 'show_streams':
        streams_json = unquote_plus(params.get('streams', '[]'))
        title        = params.get('title', '')
        hub.show_streams(streams_json, title)

    # ── Resolve página → players reais ────────────────────────────────────────
    elif mode == 'resolve_page':
        page_url  = unquote_plus(params.get('page_url', ''))
        base_url  = unquote_plus(params.get('base', ''))
        src_label = unquote_plus(params.get('src_label', 'Streams'))
        hub.resolve_page_streams(page_url, base_url, src_label)

    # ── Reproduzir stream ─────────────────────────────────────────────────────
    elif mode == 'play_stream':
        url      = params.get('url', '')
        name     = unquote_plus(params.get('name', 'Stream'))
        is_api   = params.get('is_api', '0') == '1'
        base_url = unquote_plus(params.get('base_url', ''))
        _play(url, name, is_api, base_url)

    # ── DaddyLive 24/7 ────────────────────────────────────────────────────────
    elif mode == 'daddy_channels':
        hub.show_daddy_channels()

    elif mode == 'daddy_channel_players':
        cid  = params.get('cid', '')
        name = unquote_plus(params.get('name', 'Canal'))
        hub.show_daddy_channel_players(cid, name)

    else:
        utils.notify('Modo desconhecido: ' + mode)


def _play(url, name, is_api=False, base_url=''):
    vp = utils.VideoPlayer(name)
    vp.progress.update(20)

    from resources.lib.resolver import resolve_stream

    stream = None

    # ── Streamed API: /api/stream/{source}/{id} ────────────────────────────────
    if is_api or '/api/stream/' in url:
        try:
            p = urlparse(url)
            b = '{}://{}'.format(p.scheme, p.netloc)
            streams_data = utils.getJson(url, referer=b + '/',
                                          headers={'Origin': b})
            if streams_data and isinstance(streams_data, list):
                vp.progress.update(50)
                for sd in streams_data:
                    embed_url = sd.get('embedUrl', '')
                    if not embed_url: continue
                    stream, _ = resolve_stream(embed_url, referer=b + '/')
                    if stream: break
        except Exception as e:
            xbmc.log('[SportHub] API resolve err: ' + str(e), xbmc.LOGWARNING)

    # ── Resolver genérico ─────────────────────────────────────────────────────
    if not stream:
        vp.progress.update(40)
        ref = base_url + '/' if base_url else ''
        stream, _ = resolve_stream(url, referer=ref)

    vp.progress.update(90)

    if stream:
        vp.play_from_resolver(stream)
    else:
        try: vp.progress.close()
        except Exception: pass
        utils.notify('Stream não resolvido. Tenta outro player.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def main():
    qs = sys.argv[2] if len(sys.argv) > 2 else ''
    if qs.startswith('?'):
        qs = qs[1:]
    params = dict(parse_qsl(qs))
    route(params)


if __name__ == '__main__':
    main()
