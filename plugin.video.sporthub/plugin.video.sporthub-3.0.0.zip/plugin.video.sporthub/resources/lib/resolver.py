# -*- coding: utf-8 -*-
import re, json, base64, ssl, gzip
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, urlparse
    from urllib.error import HTTPError
except ImportError:
    from urllib2 import urlopen, Request, HTTPError
    from urllib import urlencode
    from urlparse import urlparse

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36')

try:
    _ssl = ssl.create_default_context()
    _ssl.check_hostname = False
    _ssl.verify_mode = ssl.CERT_NONE
except Exception:
    _ssl = None


def _log(msg):
    xbmc.log('[SportHub/Resolver] ' + str(msg), xbmc.LOGDEBUG)


def _get(url, referer=None, headers=None, timeout=20):
    hdrs = {'User-Agent': UA, 'Accept-Encoding': 'gzip, deflate',
            'Accept': '*/*'}
    if referer: hdrs['Referer'] = referer
    if headers: hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        resp = urlopen(req, timeout=timeout, context=_ssl) if _ssl else urlopen(req, timeout=timeout)
        raw = resp.read()
        if 'gzip' in resp.headers.get('Content-Encoding', ''):
            raw = gzip.decompress(raw)
        return raw.decode('utf-8', errors='replace')
    except Exception as e:
        _log('GET err: {} | {}'.format(url[:80], e))
        return ''


def _origin(url):
    p = urlparse(url)
    return '{}://{}'.format(p.scheme or 'https', p.netloc)


def _pipe(url, hdrs):
    return '{}|{}'.format(url, urlencode(hdrs))


def resolve_stream(player_url, referer=''):
    _log('Resolving: ' + player_url[:80])
    origin = _origin(player_url)
    ref = referer or origin + '/'
    data = _get(player_url, referer=ref)
    if not data:
        return None, None

    # JS packer
    if 'eval(function(p,a,c,k,e,' in data:
        try:
            from resources.lib.jsunpack import unpack
            data = unpack(data)
        except Exception:
            pass

    # newkso/Clappr
    if 'CHANNEL_KEY' in data and 'BUNDLE' in data:
        r = _resolve_newkso(data, player_url, ref)
        if r[0]: return r

    # hlsUrl variants
    for pat in [r'hlsUrl\s*[=:]\s*["\']([^"\']+)',
                r'"hlsUrl"\s*:\s*"([^"]+)"',
                r'hls_url\s*[=:]\s*["\']([^"\']+)']:
        m = re.search(pat, data)
        if m:
            u = m.group(1)
            h = {'Referer': player_url, 'User-Agent': UA, 'Origin': origin}
            return _pipe(u, h), h

    # player.src / file / source
    for pat in [r'''player\.src\(\{[^}]*src\s*:\s*['"]([^'"]+)''',
                r'''["']?(?:file|src|source)["']?\s*:\s*["'](https?://[^"']+\.m3u8[^"']*)["']''']:
        m = re.search(pat, data, re.DOTALL)
        if m:
            u = m.group(1)
            h = {'Referer': player_url, 'User-Agent': UA}
            return _pipe(u, h), h

    # iframes
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', data, re.I)
    iframes += re.findall(r'''(?:iframe\.src|loadPlayer\()\s*[=\(]\s*['"]([^'"]{20,})''', data)
    for src in iframes:
        if any(x in src.lower() for x in ['javascript:', 'about:blank', 'ads']): continue
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else (origin + '/' + src.lstrip('/'))
        if src == player_url: continue
        r = resolve_stream(src, referer=player_url)
        if r[0]: return r

    # m3u8 directo
    m = re.search(r'(https?://[^\s\'"<>\]]+\.m3u8[^\s\'"<>\]]*)', data)
    if m:
        u = m.group(1)
        h = {'Referer': player_url, 'User-Agent': UA, 'Origin': origin}
        return _pipe(u, h), h

    _log('Not resolved: ' + player_url[:80])
    return None, None


def _resolve_newkso(data, embed_url, referer):
    try:
        m = re.search(r'''const\s+CHANNEL_KEY\s*=\s*['"]([^'"]+)''', data)
        if not m: return None, None
        channel_key = m.group(1)
        m = re.search(r'''const\s+BUNDLE\s*=\s*['"]([A-Za-z0-9+/=]+)''', data)
        if not m: return None, None
        origin = _origin(embed_url)
        body = _get('{}/server_lookup.php?channel_id={}'.format(origin, channel_key),
                    referer=embed_url)
        server_key = ''
        try:
            server_key = json.loads(body).get('server_key', '')
        except Exception:
            mm = re.search(r'"server_key"\s*:\s*"([^"]+)"', body)
            if mm: server_key = mm.group(1)
        if not server_key: return None, None
        sk = server_key.strip('/')
        if 'top1' in sk or 'cdn' in sk:
            url = 'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key)
        else:
            hp = sk.replace('/', '.')
            url = 'https://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(hp, sk, channel_key)
        h = {'Referer': embed_url, 'Origin': origin, 'User-Agent': UA}
        return _pipe(url, h), h
    except Exception as e:
        _log('newkso err: ' + str(e))
        return None, None
