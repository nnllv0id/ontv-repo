# -*- coding: utf-8 -*-
import re, os, sys, ssl, gzip, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
    from urllib.error import HTTPError, URLError
    from io import BytesIO
except ImportError:
    from urllib2 import urlopen, Request, HTTPError, URLError
    from urllib import urlencode, quote_plus, unquote_plus
    from urlparse import parse_qsl

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')

try:
    _ssl = ssl.create_default_context()
    _ssl.check_hostname = False
    _ssl.verify_mode = ssl.CERT_NONE
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    _ssl = None


def getHtml(url, referer='', headers=None, timeout=20):
    hdrs = {'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'en-US,en;q=0.9'}
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        resp = urlopen(req, timeout=timeout, context=_ssl) if _ssl else urlopen(req, timeout=timeout)
        raw = resp.read()
        if 'gzip' in resp.headers.get('Content-Encoding', ''):
            raw = gzip.decompress(raw)
        return raw.decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[SportHub] getHtml error: {} | {}'.format(url, str(e)), xbmc.LOGWARNING)
        return ''


def getJson(url, referer='', headers=None, timeout=20):
    hdrs = {'Accept': 'application/json, */*', 'User-Agent': UA}
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        resp = urlopen(req, timeout=timeout, context=_ssl) if _ssl else urlopen(req, timeout=timeout)
        raw = resp.read()
        if 'gzip' in resp.headers.get('Content-Encoding', ''):
            raw = gzip.decompress(raw)
        return json.loads(raw.decode('utf-8', errors='replace'))
    except Exception as e:
        xbmc.log('[SportHub] getJson error: {} | {}'.format(url, str(e)), xbmc.LOGWARNING)
        return None


def cleantext(text):
    try:
        from html import unescape
    except ImportError:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    text = unescape(str(text))
    text = re.sub(r'<[^>]+>', '', text)
    return re.sub(r'\s+', ' ', text).strip()


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def eod(handle=None, cache=False):
    xbmcplugin.endOfDirectory(handle if handle is not None else HANDLE, cacheToDisc=cache)


class VideoPlayer(object):
    def __init__(self, name, download=None):
        self.name = name
        self.download = download
        self.progress = xbmcgui.DialogProgress()
        self.progress.create(ADDON_NAME, 'A carregar...\n' + str(name))
        self.progress.update(10)

    def _close(self):
        try: self.progress.close()
        except Exception: pass

    def play_from_resolver(self, url):
        self._close()
        if not url:
            notify('Stream não disponível.')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        li = xbmcgui.ListItem(self.name, path=url)
        li.setArt({'thumb': ICON, 'fanart': FANART})
        li.setInfo('video', {'title': self.name, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        base_url = url.split('|')[0].split('?')[0].lower()
        if '.m3u8' in base_url:
            try:
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                li.setProperty('mimetype', 'application/x-mpegURL')
            except Exception:
                pass
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
