# -*- coding: utf-8 -*-
"""
SportHub — default.py
"""
import os, sys, socket
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import parse_qsl, unquote_plus, urlparse
except ImportError:
    from urllib import unquote_plus
    from urlparse import parse_qsl, urlparse

from resources.lib import utils
from resources.lib import hub

socket.setdefaulttimeout(60)

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')


def route(params):
    mode = params.get('mode', 'main')

    if mode == 'main':
        hub.show_main()

    elif mode == 'sport_category':
        hub.show_sport_category(params.get('sport', 'football'))

    elif mode == 'show_streams':
        # parse_qsl já fez unquote — passar directamente
        hub.show_streams(
            params.get('streams', '[]'),
            params.get('title', '')
        )

    elif mode == 'resolve_page':
        hub.resolve_page_streams(
            params.get('page_url', ''),
            params.get('base', ''),
            params.get('src_label', 'Streams')
        )

    elif mode == 'play_stream':
        url      = params.get('url', '')
        name     = params.get('name', 'Stream')
        is_api   = params.get('is_api', '0') == '1'
        base_url = params.get('base_url', '')
        _play(url, name, is_api, base_url)

    elif mode == 'daddy_channels':
        hub.show_daddy_channels()

    elif mode == 'daddy_channel_players':
        hub.show_daddy_channel_players(
            params.get('cid', ''),
            params.get('name', 'Canal')
        )

    else:
        utils.notify('Modo desconhecido: ' + mode)


def _play(url, name, is_api=False, base_url=''):
    vp = utils.VideoPlayer(name)
    vp.progress.update(20)

    from resources.lib.resolver import resolve_stream

    stream = None

    # Streamed API: /api/stream/{source}/{id}
    if is_api or '/api/stream/' in url:
        try:
            p = urlparse(url)
            b = '{}://{}'.format(p.scheme, p.netloc)
            vp.progress.update(35)
            streams_data = utils.getJson(url, referer=b + '/',
                                          headers={'Origin': b})
            if streams_data and isinstance(streams_data, list):
                vp.progress.update(55)
                for sd in streams_data:
                    embed_url = sd.get('embedUrl', '')
                    if not embed_url:
                        continue
                    vp.progress.update(70)
                    stream, _ = resolve_stream(embed_url, referer=b + '/')
                    if stream:
                        break
        except Exception as e:
            xbmc.log('[SportHub] API resolve err: ' + str(e), xbmc.LOGWARNING)

    # Resolver genérico
    if not stream:
        vp.progress.update(40)
        ref = base_url
        if ref and not ref.endswith('/'):
            ref += '/'
        stream, _ = resolve_stream(url, referer=ref)

    vp.progress.update(95)

    if stream:
        vp.play_from_resolver(stream)
    else:
        try:
            vp.progress.close()
        except Exception:
            pass
        utils.notify('Stream não resolvido. Tenta outro player.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def main():
    # Activar DoH
    try:
        from resources.lib.network import enable_doh
        if ADDON.getSetting('use_doh') != 'false':
            custom_doh = ADDON.getSetting('doh_url') or ''
            enable_doh(custom_doh if custom_doh.startswith('http') else None)
    except Exception as e:
        xbmc.log('[SportHub] DoH init: ' + str(e), xbmc.LOGWARNING)

    qs = sys.argv[2] if len(sys.argv) > 2 else ''
    if qs.startswith('?'):
        qs = qs[1:]
    params = dict(parse_qsl(qs))
    route(params)


if __name__ == '__main__':
    main()
