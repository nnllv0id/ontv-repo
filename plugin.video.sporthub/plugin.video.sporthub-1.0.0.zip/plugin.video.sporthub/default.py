# -*- coding: utf-8 -*-
"""SportHub — default.py"""
import os, sys
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import parse_qsl, urlparse
except ImportError:
    from urlparse import parse_qsl, urlparse

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])


def route(params):
    from resources.lib import utils, hub

    mode = params.get('mode', 'main')

    if mode == 'main':
        hub.show_main()

    elif mode == 'sport_category':
        hub.show_sport_category(params.get('sport', 'football'))

    elif mode == 'show_streams':
        hub.show_streams(params.get('streams', '[]'), params.get('title', ''))

    elif mode == 'resolve_page':
        hub.resolve_page_streams(
            params.get('page_url', ''),
            params.get('base', ''),
            params.get('src_label', 'Streams')
        )

    elif mode == 'play_stream':
        url      = params.get('url', '')
        name     = params.get('name', 'Stream')
        is_api   = params.get('is_api', '0') == '1'
        base_url = params.get('base_url', '')
        _play(url, name, is_api, base_url)

    elif mode == 'daddy_channels':
        hub.show_daddy_channels()

    elif mode == 'daddy_channel_players':
        hub.show_daddy_channel_players(
            params.get('cid', ''),
            params.get('name', 'Canal')
        )

    else:
        from resources.lib.utils import notify
        notify('Modo desconhecido: ' + mode)


def _play(url, name, is_api=False, base_url=''):
    from resources.lib import utils
    from resources.lib.resolver import resolve_stream

    progress = xbmcgui.DialogProgress()
    progress.create('SportHub', 'A resolver stream...\n' + name[:50])
    progress.update(10)

    stream = None

    try:
        # ── Streamed API ─────────────────────────────────────────────────
        if is_api or '/api/stream/' in url:
            progress.update(20)

            p = urlparse(url)
            b = '{}://{}'.format(p.scheme, p.netloc)

            # Substituir domínio expirado
            if any(x in b for x in ['streamed.su', 'streamed.pk', 'streamed.st']):
                from resources.lib.sites.streamed import base as s_base
                b = s_base()
                path = p.path
                url  = b + path

            progress.update(35)
            streams_data = utils.getJson(url, referer=b + '/',
                                          headers={'Origin': b}, timeout=12)
            progress.update(55)

            if streams_data and isinstance(streams_data, list):
                for sd in streams_data:
                    embed_url = sd.get('embedUrl', '')
                    if not embed_url:
                        continue
                    progress.update(70)
                    stream, _ = resolve_stream(embed_url, referer=b + '/')
                    if stream:
                        break

        # ── Player page (DaddyLive, outros) ──────────────────────────────
        if not stream:
            progress.update(50)
            ref = base_url + '/' if base_url and not base_url.endswith('/') else base_url
            stream, _ = resolve_stream(url, referer=ref)

    except Exception as e:
        xbmc.log('[SportHub] play err: ' + str(e), xbmc.LOGWARNING)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    if stream:
        utils.play_stream(name, stream)
    else:
        utils.notify('Não foi possível resolver o stream.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def main():
    # DoH
    try:
        if ADDON.getSetting('use_doh') != 'false':
            from resources.lib.network import enable_doh
            custom = ADDON.getSetting('doh_url') or ''
            enable_doh(custom if custom.startswith('http') else None)
    except Exception:
        pass

    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else ''
    params = dict(parse_qsl(qs))
    route(params)


if __name__ == '__main__':
    main()
