# -*- coding: utf-8 -*-
"""
SportHub — default.py
Hub de sites de desporto ao vivo.
Arquitectura inspirada no Cumination.
"""
import os
import sys
import socket

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

from resources.lib import utils
from resources.lib.url_dispatcher import URL_Dispatcher
from resources.lib.sportsite import SportSite
from resources.lib.sites import *  # noqa — importa todos os sites

socket.setdefaulttimeout(60)

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

xbmcplugin.setContent(HANDLE, 'videos')

url_dispatcher = URL_Dispatcher('main')


# ─────────────────────────────────────────────────────────────────────────────
#  ECRÃ PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

@url_dispatcher.register()
def INDEX():
    """Ecrã de entrada — lista todos os sites disponíveis."""
    for site in sorted(SportSite.get_sites(),
                        key=lambda s: s.title.replace('[', '').replace(']', '').lower()):
        url_dispatcher.add_dir(
            site.title,
            site.url,
            site.default_mode,
            site.image,
            desc=site.about or site.title,
        )

    url_dispatcher.add_dir(
        '[COLOR grey]⚙ Limpar Cache[/COLOR]',
        '', 'clear_cache',
        ICON,
        Folder=False,
    )
    utils.eod(HANDLE, False)


@url_dispatcher.register()
def clear_cache(url=''):
    xbmcgui.Dialog().notification(ADDON_NAME, 'Cache limpa.', ICON, 3000)


# ─────────────────────────────────────────────────────────────────────────────
#  ROTEADOR
# ─────────────────────────────────────────────────────────────────────────────

def process_queries():
    queries = utils.parse_query(sys.argv[2])
    mode    = queries.get('mode', None)

    # Pesquisa via teclado
    keyword = queries.get('keyword', '')
    if keyword == '__SEARCH__':
        kb = xbmcgui.Dialog().input('Pesquisar', type=xbmcgui.INPUT_ALPHANUM)
        if kb:
            queries['keyword'] = kb
        else:
            return

    URL_Dispatcher.dispatch(mode, queries)


if __name__ == '__main__':
    process_queries()
