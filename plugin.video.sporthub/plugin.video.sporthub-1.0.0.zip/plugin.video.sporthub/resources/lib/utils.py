# -*- coding: utf-8 -*-
import re, os, sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
except ImportError:
    from urllib import urlencode, quote_plus, unquote_plus
    from urlparse import parse_qsl

from resources.lib.network import fetch, fetch_json

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')


def getHtml(url, referer='', headers=None, timeout=20):
    return fetch(url, referer=referer, headers=headers, timeout=timeout) or ''


def getJson(url, referer='', headers=None, timeout=20):
    return fetch_json(url, referer=referer, headers=headers, timeout=timeout)


def cleantext(text):
    try:
        from html import unescape
    except ImportError:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    text = unescape(str(text))
    text = re.sub(r'<[^>]+>', '', text)
    return re.sub(r'\s+', ' ', text).strip()


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def eod(handle=None, cache=False):
    xbmcplugin.endOfDirectory(handle if handle is not None else HANDLE,
                               cacheToDisc=cache)


class VideoPlayer(object):
    def __init__(self, name, download=None):
        self.name     = name
        self.download = download
        self.progress = xbmcgui.DialogProgress()
        self.progress.create(ADDON_NAME, 'A carregar...\n' + str(name))
        self.progress.update(10)

    def _close(self):
        try: self.progress.close()
        except Exception: pass

    def play_from_resolver(self, url):
        self._close()
        if not url:
            notify('Stream não disponível.')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        li = xbmcgui.ListItem(self.name, path=url)
        li.setArt({'thumb': ICON, 'fanart': FANART})
        li.setInfo('video', {'title': self.name, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        base_url = url.split('|')[0].split('?')[0].lower()
        if '.m3u8' in base_url:
            try:
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                li.setProperty('mimetype', 'application/x-mpegURL')
            except Exception:
                pass
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
