# -*- coding: utf-8 -*-
"""
SportHub — Utils
HTTP helpers, player de vídeo, funções auxiliares.
"""
import re
import os
import sys
import ssl
import gzip
import json
import base64

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.parse   import urlencode, quote_plus, unquote_plus, parse_qsl, urlparse
    from urllib.error   import HTTPError, URLError
    import http.cookiejar as cookielib
    from io import BytesIO
except ImportError:
    from urllib2       import urlopen, Request, HTTPError, URLError
    from urllib        import urlencode, quote_plus, unquote_plus
    from urlparse      import parse_qsl, urlparse
    import cookielib
    from StringIO import StringIO as BytesIO

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')

progress = xbmcgui.DialogProgress()
dialog   = xbmcgui.Dialog()

# SSL sem verificação
try:
    _ssl_ctx = ssl.create_default_context()
    _ssl_ctx.check_hostname = False
    _ssl_ctx.verify_mode    = ssl.CERT_NONE
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    _ssl_ctx = None


# ─────────────────────────────────────────────────────────────────────────────
#  HTTP
# ─────────────────────────────────────────────────────────────────────────────

def getHtml(url, referer='', headers=None, timeout=20):
    """GET simples, devolve texto."""
    hdrs = {
        'User-Agent':      UA,
        'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.8',
    }
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)

    try:
        req  = Request(url, headers=hdrs)
        if _ssl_ctx:
            resp = urlopen(req, timeout=timeout, context=_ssl_ctx)
        else:
            resp = urlopen(req, timeout=timeout)

        raw = resp.read()
        enc = resp.headers.get('Content-Encoding', '')
        if 'gzip' in enc:
            raw = gzip.decompress(raw)
        return raw.decode('utf-8', errors='replace')
    except Exception as e:
        xbmc.log('[SportHub] getHtml falhou: {} | {}'.format(url, e), xbmc.LOGWARNING)
        return ''


def getJson(url, referer='', headers=None):
    """GET que devolve dict/list JSON."""
    hdrs = {'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    data = getHtml(url, referer=referer, headers=hdrs)
    if not data:
        return {}
    try:
        return json.loads(data)
    except Exception as e:
        xbmc.log('[SportHub] getJson parse erro: {}'.format(e), xbmc.LOGWARNING)
        return {}


# ─────────────────────────────────────────────────────────────────────────────
#  Texto
# ─────────────────────────────────────────────────────────────────────────────

def cleantext(text):
    """Remove entidades HTML e whitespace excessivo."""
    try:
        from html import unescape
    except ImportError:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    text = unescape(text)
    text = re.sub(r'<[^>]+>', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def parse_query(query_string):
    """Converte query string em dict."""
    if query_string.startswith('?'):
        query_string = query_string[1:]
    params = dict(parse_qsl(query_string))
    return params


# ─────────────────────────────────────────────────────────────────────────────
#  Notificações
# ─────────────────────────────────────────────────────────────────────────────

def notify(msg, icon=None, time=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon or ICON, time)


def kodilog(msg, level=xbmc.LOGDEBUG):
    xbmc.log('[SportHub] ' + str(msg), level)


def eod(handle=None, cache=True):
    h = handle if handle is not None else HANDLE
    xbmcplugin.endOfDirectory(h, cacheToDisc=cache)


# ─────────────────────────────────────────────────────────────────────────────
#  Video Player
# ─────────────────────────────────────────────────────────────────────────────

class VideoPlayer(object):
    def __init__(self, name, download=None):
        self.name     = name
        self.download = download
        self.progress = xbmcgui.DialogProgress()
        self.progress.create(ADDON_NAME, 'A carregar...\n' + name)
        self.progress.update(10)

    def _close(self):
        try:
            self.progress.close()
        except Exception:
            pass

    def _make_li(self, url, headers=None):
        li = xbmcgui.ListItem(self.name, path=url)
        li.setArt({'thumb': ICON, 'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': self.name, 'mediatype': 'video'})

        url_lower = url.lower().split('?')[0].split('|')[0]
        if '.m3u8' in url_lower:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('mimetype', 'application/x-mpegURL')
        elif url_lower.endswith('.mpd'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setProperty('mimetype', 'application/dash+xml')
        return li

    def play_from_direct_link(self, url, headers=None):
        self.progress.update(90)
        self._close()
        if not url:
            notify('Não foi possível obter o stream.')
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        # Construir URL com headers pipe
        if headers:
            url = '{}|{}'.format(url, urlencode(headers))
        li = self._make_li(url, headers)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)

    def play_from_resolver(self, stream_url):
        """Usa o stream já com pipe de headers se presente."""
        self.play_from_direct_link(stream_url)


# ─────────────────────────────────────────────────────────────────────────────
#  Resolver genérico de embeds (reutilizado pelos sites)
# ─────────────────────────────────────────────────────────────────────────────

def resolve_embed(embed_url, referer=''):
    """
    Tenta extrair m3u8 / stream de um URL de embed.
    Devolve URL com pipe de headers ou None.
    """
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(embed_url, referer=referer)
    return stream
