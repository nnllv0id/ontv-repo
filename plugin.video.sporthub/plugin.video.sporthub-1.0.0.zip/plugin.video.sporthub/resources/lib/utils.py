# -*- coding: utf-8 -*-
import re, os, sys, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError, URLError
except ImportError:
    from urllib import urlencode, quote_plus, unquote_plus, urlopen
    from urlparse import parse_qsl
    from urllib2 import Request, HTTPError, URLError

import ssl

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')

# SSL context global
try:
    _SSL = ssl.create_default_context()
    _SSL.check_hostname = False
    _SSL.verify_mode = ssl.CERT_NONE
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    _SSL = None


def _do_request(url, referer='', headers=None, timeout=15):
    hdrs = {
        'User-Agent': UA,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        if _SSL:
            resp = urlopen(req, timeout=timeout, context=_SSL)
        else:
            resp = urlopen(req, timeout=timeout)
        raw = resp.read()
        enc = resp.headers.get_content_charset('utf-8') if hasattr(resp.headers, 'get_content_charset') else 'utf-8'
        return raw.decode(enc, errors='replace')
    except Exception as e:
        xbmc.log('[SportHub] HTTP err {}: {}'.format(url[:60], e), xbmc.LOGWARNING)
        return ''


def getHtml(url, referer='', headers=None, timeout=15):
    return _do_request(url, referer=referer, headers=headers, timeout=timeout)


def getJson(url, referer='', headers=None, timeout=15):
    hdrs = {'Accept': 'application/json'}
    if headers:
        hdrs.update(headers)
    raw = _do_request(url, referer=referer, headers=hdrs, timeout=timeout)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def cleantext(text):
    try:
        from html import unescape
    except ImportError:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    text = unescape(str(text))
    text = re.sub(r'<[^>]+>', '', text)
    return re.sub(r'\s+', ' ', text).strip()


def notify(msg, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, ms)


def eod(handle=None, cache=False):
    xbmcplugin.endOfDirectory(
        handle if handle is not None else HANDLE,
        cacheToDisc=cache)


def play_stream(name, url, is_live=True):
    """
    Reproduz um stream. url pode ser:
      - URL directo .m3u8
      - URL|headers  (formato pipe)
    """
    if not url:
        notify('Stream não disponível.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    parts  = url.split('|', 1)
    stream = parts[0]
    extra  = parts[1] if len(parts) > 1 else ''

    li = xbmcgui.ListItem(name, path=url)
    li.setArt({'thumb': ICON, 'fanart': FANART})
    li.setInfo('video', {'title': name, 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')

    is_hls = '.m3u8' in stream.lower()

    if is_hls:
        try:
            li.setContentLookup(False)
            li.setMimeType('application/x-mpegURL')
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            if extra:
                li.setProperty('inputstream.adaptive.stream_headers', extra)
                li.setHttpHeader('User-Agent', UA)
        except Exception as e:
            xbmc.log('[SportHub] ISA err: ' + str(e), xbmc.LOGWARNING)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)
