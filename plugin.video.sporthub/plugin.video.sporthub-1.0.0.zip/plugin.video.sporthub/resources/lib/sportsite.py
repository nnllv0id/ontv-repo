# -*- coding: utf-8 -*-
"""
SportHub — Classe base SportSite
Equivalente ao AdultSite do Cumination.
Cada site de desporto herda desta classe.
"""
from resources.lib.url_dispatcher import URL_Dispatcher
from weakref import WeakSet
import re
import os
import sys

try:
    from urllib.parse import urlencode, quote_plus
except ImportError:
    from urllib import urlencode, quote_plus

import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
IMG_DIR    = os.path.join(ADDON_PATH, 'resources', 'images')
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]

IMG_SEARCH = os.path.join(IMG_DIR, 'hub-search.png')
IMG_CAT    = os.path.join(IMG_DIR, 'hub-cat.png')
IMG_NEXT   = os.path.join(IMG_DIR, 'hub-next.png')
IMG_LIVE   = os.path.join(IMG_DIR, 'hub-live.png')


def sport_image(filename):
    """Resolve imagem — URL externa ou path local."""
    if not filename:
        return ICON
    if filename.startswith('http'):
        return filename
    return os.path.join(IMG_DIR, filename)


class SportSite(URL_Dispatcher):
    instances = WeakSet()

    def __init__(self, name, title, url, image=None, about=''):
        self.default_mode = ''
        self.name         = name
        self.title        = title
        self.url          = url
        self.image        = sport_image(image) if image else ICON
        self.about        = about
        self._add_to_instances()

    def _add_to_instances(self):
        super(SportSite, self).__init__(self.name)
        self.__class__.instances.add(self)

    # ── Compatibilidade com URL_Dispatcher ────────────────────────────────────

    @property
    def img_search(self):
        return IMG_SEARCH

    @property
    def img_cat(self):
        return IMG_CAT

    @property
    def img_next(self):
        return IMG_NEXT

    @property
    def img_live(self):
        return IMG_LIVE

    # ── Registo de funções ─────────────────────────────────────────────────────

    def register(self, default_mode=False):
        def dec(f):
            if default_mode:
                if self.default_mode:
                    raise Exception('default_mode já definido em {}'.format(self.name))
                self.default_mode = '{}.{}'.format(self.module_name, f.__name__)
            parent_reg = super(SportSite, self).register()
            return parent_reg(f)
        return dec

    # ── Iteradores de instâncias ───────────────────────────────────────────────

    @classmethod
    def get_sites(cls):
        for ins in cls.instances:
            if ins.default_mode:
                yield ins

    @classmethod
    def get_site_by_name(cls, name):
        for ins in cls.instances:
            if ins.name == name and ins.default_mode:
                return ins
        return None

    # ── Helpers de listagem ────────────────────────────────────────────────────

    def add_stream(self, name, url, mode, image=None, desc='', duration='', is_live=False, quality=''):
        """Adiciona um item reproduzível (stream ao vivo ou VOD)."""
        image = image or self.image
        label = name
        if is_live:
            label = '[COLOR red]● LIVE[/COLOR]  ' + name
        self.add_download_link(label, url, mode, image, desc=desc, duration=duration, quality=quality)

    def add_channel(self, name, url, mode, image=None, desc='', is_live=False):
        """Directório de canal / evento."""
        image = image or self.image
        label = ('[COLOR red]●[/COLOR] ' + name) if is_live else name
        self.add_dir(label, url, mode, image, desc=desc)
