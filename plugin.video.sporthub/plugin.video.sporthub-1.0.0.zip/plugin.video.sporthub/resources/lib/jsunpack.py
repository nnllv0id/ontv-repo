# -*- coding: utf-8 -*-
import re

def detect(source):
    return source.replace(' ', '').startswith('eval(function(p,a,c,k,e,')

def unpack(source):
    payload, symtab, radix, count = _filterargs(source)
    if count != len(symtab):
        raise Exception('Malformed p.a.c.k.e.r. symtab.')
    unbase = Unbaser(radix)

    def lookup(match):
        word = match.group(0)
        idx = int(word) if radix == 1 else unbase(word)
        return symtab[idx] if idx < len(symtab) else word

    source = re.sub(r'\b\w+\b', lookup, payload)
    return _replacestrings(source)

def _filterargs(source):
    args = re.search(
        r"\}\('(.*)',\s*(\d+|\[\]),\s*(\d+),\s*'(.*)'\s*\.split\('\|'\)",
        source, re.DOTALL
    )
    if args:
        a = args.groups()
        radix = 62 if a[1] == '[]' else int(a[1])
        return a[0], a[3].split('|'), radix, int(a[2])
    raise Exception('Could not parse p.a.c.k.e.r.')

def _replacestrings(source):
    match = re.search(r'var *(_\w+)=\["(.*?)"\];', source, re.DOTALL)
    if match:
        varname, strings = match.groups()
        startpoint = len(match.group(0))
        lookup = strings.split('","')
        variable = '%s[%%d]' % varname
        for index, value in enumerate(lookup):
            source = source.replace(variable % index, '"%s"' % value)
        return source[startpoint:]
    return source

class Unbaser(object):
    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'
    }
    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda s: int(s, base)
        else:
            alpha = self.ALPHABET.get(base, self.ALPHABET[62][:base])
            self.dictionary = {c: i for i, c in enumerate(alpha)}
            self.unbase = self._dictunbaser
    def __call__(self, s):
        return self.unbase(s)
    def _dictunbaser(self, s):
        ret = 0
        for i, c in enumerate(reversed(s)):
            ret += (self.base ** i) * self.dictionary.get(c, 0)
        return ret
