# -*- coding: utf-8 -*-
import re

def detect(s): return s.replace(' ','').startswith('eval(function(p,a,c,k,e,')

def unpack(source):
    payload, symtab, radix, count = _filterargs(source)
    if count != len(symtab): raise Exception('Bad symtab')
    unbase = Unbaser(radix)
    def lookup(m):
        w = m.group(0)
        idx = int(w) if radix == 1 else unbase(w)
        return symtab[idx] if idx < len(symtab) else w
    source = re.sub(r'\b\w+\b', lookup, payload)
    return _replacestrings(source)

def _filterargs(source):
    a = re.search(r"\}\('(.*)',\s*(\d+|\[\]),\s*(\d+),\s*'(.*)'\s*\.split\('\|'\)", source, re.DOTALL)
    if a:
        g = a.groups()
        radix = 62 if g[1]=='[]' else int(g[1])
        return g[0], g[3].split('|'), radix, int(g[2])
    raise Exception('Cannot parse packer')

def _replacestrings(source):
    m = re.search(r'var *(_\w+)=\["(.*?)"\];', source, re.DOTALL)
    if m:
        varname, strings = m.groups()
        startpoint = len(m.group(0))
        lookup = strings.split('","')
        for i, v in enumerate(lookup):
            source = source.replace('%s[%d]' % (varname, i), '"%s"' % v)
        return source[startpoint:]
    return source

class Unbaser:
    ALPHA = {62:'0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'}
    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda s: int(s, base)
        else:
            alpha = self.ALPHA.get(base, self.ALPHA[62][:base])
            self.d = {c:i for i,c in enumerate(alpha)}
            self.unbase = self._dict
    def __call__(self, s): return self.unbase(s)
    def _dict(self, s):
        r = 0
        for i, c in enumerate(reversed(s)):
            r += (self.base**i) * self.d.get(c, 0)
        return r
