# -*- coding: utf-8 -*-
"""
Resolver de streams para SportHub.
Foca-se em live streams: HLS/m3u8 via newkso/Clappr e padrões comuns.
"""
import re, json
import xbmc

try:
    from urllib.parse import urlencode, urlparse, urljoin
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urllib import urlencode, urlopen
    from urlparse import urlparse, urljoin
    from urllib2 import Request, HTTPError

import ssl

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')

try:
    _SSL = ssl.create_default_context()
    _SSL.check_hostname = False
    _SSL.verify_mode = ssl.CERT_NONE
except Exception:
    _SSL = None


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log('[SportHub/Resolver] ' + str(msg), level)


def _get(url, referer='', extra_headers=None, timeout=15):
    hdrs = {
        'User-Agent': UA,
        'Accept': 'text/html,*/*',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    if referer:
        hdrs['Referer'] = referer
        hdrs['Origin'] = _origin(referer)
    if extra_headers:
        hdrs.update(extra_headers)
    try:
        req = Request(url, headers=hdrs)
        if _SSL:
            resp = urlopen(req, timeout=timeout, context=_SSL)
        else:
            resp = urlopen(req, timeout=timeout)
        raw = resp.read()
        return raw.decode('utf-8', errors='replace')
    except Exception as e:
        _log('GET {} err: {}'.format(url[:60], e), xbmc.LOGWARNING)
        return ''


def _origin(url):
    try:
        p = urlparse(url)
        return '{}://{}'.format(p.scheme or 'https', p.netloc)
    except Exception:
        return ''


def _pipe(url, hdrs):
    """Formato url|Referer=...&User-Agent=..."""
    h = {k: v for k, v in hdrs.items() if k in ('Referer', 'User-Agent', 'Origin')}
    if h:
        return '{}|{}'.format(url, urlencode(h))
    return url


def resolve_stream(player_url, referer=''):
    """
    Tenta resolver player_url para um m3u8 directo.
    Retorna (url_com_headers, headers_dict) ou (None, None).
    """
    if not player_url:
        return None, None

    # Já é um m3u8?
    if '.m3u8' in player_url.lower():
        h = {'Referer': referer or player_url, 'User-Agent': UA}
        return _pipe(player_url, h), h

    _log('Resolving: ' + player_url[:80])
    origin = _origin(player_url)
    ref    = referer or origin + '/'

    html = _get(player_url, referer=ref)
    if not html:
        return None, None

    # JS packer (eval p,a,c,k,e,r)
    if 'eval(function(p,a,c,k,e,' in html:
        try:
            from resources.lib.jsunpack import unpack
            html = unpack(html) + '\n' + html
        except Exception:
            pass

    # ── PASSO 1: newkso / Clappr (DaddyLive e similares) ──────────────────
    r = _resolve_newkso(html, player_url, ref)
    if r[0]:
        return r

    # ── PASSO 2: hlsUrl ──────────────────────────────────────────────────
    for pat in [r'hlsUrl\s*[=:]\s*["\']([^"\']+)',
                r'"hlsUrl"\s*:\s*"([^"]+)"',
                r'hls_url\s*[=:]\s*["\']([^"\']+)',
                r'var\s+url\s*=\s*["\']([^"\']+\.m3u8[^"\']*)',
                r'source:\s*["\']([^"\']+\.m3u8[^"\']*)',
                r'file\s*:\s*["\']([^"\']+\.m3u8[^"\']*)',
                r"'file'\s*:\s*'([^']+\.m3u8[^']*)'",
                r'src\s*:\s*["\']([^"\']+\.m3u8[^"\']*)',
                r'"src"\s*:\s*"([^"]+\.m3u8[^"]*)"']:
        m = re.search(pat, html, re.I)
        if m:
            u = m.group(1)
            if not u.startswith('http'):
                u = urljoin(player_url, u)
            h = {'Referer': player_url, 'User-Agent': UA, 'Origin': origin}
            _log('Found via pattern: ' + u[:60])
            return _pipe(u, h), h

    # ── PASSO 3: m3u8 directo em qualquer sítio da página ────────────────
    m = re.search(r'(https?://[^\s\'"<>\]]+\.m3u8[^\s\'"<>\]]*)', html)
    if m:
        u = m.group(1)
        h = {'Referer': player_url, 'User-Agent': UA, 'Origin': origin}
        return _pipe(u, h), h

    # ── PASSO 4: iframes (um nível) ──────────────────────────────────────
    iframes = re.findall(r'''<iframe[^>]+src\s*=\s*['"]([^'"]{15,})['"]''', html, re.I)
    iframes += re.findall(r'''iframe\.src\s*=\s*['"]([^'"]{15,})['"]''', html)
    for src in iframes[:4]:  # máximo 4 iframes
        if any(x in src.lower() for x in ['javascript:', 'about:blank', 'google', 'facebook']):
            continue
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else urljoin(player_url, src)
        if src == player_url:
            continue
        _log('Trying iframe: ' + src[:60])
        r = resolve_stream(src, referer=player_url)
        if r[0]:
            return r

    _log('Not resolved: ' + player_url[:60], xbmc.LOGWARNING)
    return None, None


def _resolve_newkso(html, embed_url, referer):
    """
    DaddyLive usa Clappr com CHANNEL_KEY + server_lookup.php → mono.m3u8
    """
    try:
        mk = re.search(r'''(?:const|var|let)\s+CHANNEL_KEY\s*=\s*['"]([^'"]+)''', html)
        if not mk:
            # tentar formato alternativo: channelKey = "..."
            mk = re.search(r'''channelKey\s*[=:]\s*['"]([^'"]+)''', html)
        if not mk:
            return None, None

        channel_key = mk.group(1)
        origin = _origin(embed_url)

        # server_lookup.php para obter o CDN correcto
        lookup_url = '{}/server_lookup.php?channel_id={}'.format(origin, channel_key)
        body = _get(lookup_url, referer=embed_url,
                    extra_headers={'Accept': 'application/json'})

        server_key = ''
        if body:
            try:
                server_key = json.loads(body).get('server_key', '')
            except Exception:
                mm = re.search(r'"server_key"\s*:\s*"([^"]+)"', body)
                if mm:
                    server_key = mm.group(1)

        if server_key:
            sk = server_key.strip('/')
            if 'top1' in sk or sk == 'top1':
                url = 'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key)
            else:
                hp = sk.replace('/', '.')
                url = 'https://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(hp, sk, channel_key)
        else:
            # fallback: tentar top1 directamente
            url = 'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key)

        h = {'Referer': embed_url, 'Origin': origin, 'User-Agent': UA}
        _log('newkso resolved: ' + url[:80])
        return _pipe(url, h), h

    except Exception as e:
        _log('newkso err: ' + str(e), xbmc.LOGWARNING)
        return None, None
