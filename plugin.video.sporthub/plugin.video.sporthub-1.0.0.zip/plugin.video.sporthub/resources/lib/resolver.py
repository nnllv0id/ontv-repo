# -*- coding: utf-8 -*-
"""
SportHub — Resolver de Streams
Resolve embeds → .m3u8 / .ts para todos os sites do hub.
"""
import re
import json
import base64
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, urlparse, quote, quote_plus, unquote
    from urllib.error import HTTPError, URLError
    import http.cookiejar as cookielib
    import ssl
except ImportError:
    from urllib2 import urlopen, Request, HTTPError, URLError
    from urllib import urlencode, quote, quote_plus, unquote
    from urlparse import urlparse
    import cookielib
    import ssl

UA_WIN = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
          'AppleWebKit/537.36 (KHTML, like Gecko) '
          'Chrome/122.0.0.0 Safari/537.36')

try:
    _ssl_ctx = ssl.create_default_context()
    _ssl_ctx.check_hostname = False
    _ssl_ctx.verify_mode    = ssl.CERT_NONE
except Exception:
    _ssl_ctx = None


def log(msg):
    xbmc.log('[SportHub Resolver] ' + str(msg), xbmc.LOGDEBUG)


def _http_get(url, headers=None, referer=None, timeout=20):
    hdrs = {'User-Agent': UA_WIN}
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)
    try:
        req = Request(url, headers=hdrs)
        if _ssl_ctx:
            resp = urlopen(req, timeout=timeout, context=_ssl_ctx)
        else:
            resp = urlopen(req, timeout=timeout)
        import gzip
        raw = resp.read()
        enc = resp.headers.get('Content-Encoding', '')
        if 'gzip' in enc:
            raw = gzip.decompress(raw)
        return raw.decode('utf-8', errors='replace')
    except Exception as e:
        log('HTTP GET falhou: {} | {}'.format(url, e))
        return ''


def _pipe_url(url, headers):
    return '{}|{}'.format(url, urlencode(headers))


def _find_m3u8(data):
    m = re.search(r'(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)', data)
    return m.group(1) if m else None


# ─────────────────────────────────────────────────────────────────────────────
#  Entrada principal
# ─────────────────────────────────────────────────────────────────────────────

def resolve_stream(player_url, channel_id=None, referer=''):
    """
    Resolve um URL de player/embed para stream final.
    Devolve (stream_url_com_headers, headers_dict) ou (None, None).
    """
    log('Resolving: ' + player_url)
    origin_base = '{}://{}'.format(urlparse(player_url).scheme or 'https',
                                    urlparse(player_url).netloc)
    ref = referer or origin_base + '/'

    data = _http_get(player_url, referer=ref)
    if not data:
        return None, None

    # ── JS packer ────────────────────────────────────────────────────────────
    if 'eval(function(p,a,c,k,e,' in data:
        try:
            from resources.lib.jsunpack import unpack
            data = unpack(data)
        except Exception as e:
            log('jsunpack: ' + str(e))

    # ── newkso / Clappr com CHANNEL_KEY + BUNDLE ──────────────────────────────
    if 'CHANNEL_KEY' in data and 'BUNDLE' in data:
        res = _resolve_clappr_newkso(data, player_url, ref)
        if res[0]:
            return res

    # ── hlsUrl ────────────────────────────────────────────────────────────────
    if 'hlsUrl' in data or 'hlsjsConfig' in data:
        res = _resolve_hlsurl(data, player_url)
        if res:
            hdrs = {'Referer': player_url, 'User-Agent': UA_WIN}
            return _pipe_url(res, hdrs), hdrs

    # ── player.src ────────────────────────────────────────────────────────────
    m = re.search(r'''player\.src\(\{src:\s*['"](.+?)['"]''', data)
    if m:
        url = m.group(1)
        hdrs = {'Referer': player_url, 'User-Agent': UA_WIN}
        return _pipe_url(url, hdrs), hdrs

    # ── source: ───────────────────────────────────────────────────────────────
    m = re.search(r'''["']?source["']?\s*:\s*["'](https?://[^"']+)["']''', data)
    if m:
        url = m.group(1)
        hdrs = {'Referer': player_url, 'User-Agent': UA_WIN}
        return _pipe_url(url, hdrs), hdrs

    # ── iframes ───────────────────────────────────────────────────────────────
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', data, re.IGNORECASE)
    iframes += re.findall(r'''(?:iframe\.src|src)\s*=\s*['"](https?://[^'"]+)''', data)
    for iframe_src in iframes:
        if 'javascript' in iframe_src.lower():
            continue
        if not iframe_src.startswith('http'):
            iframe_src = origin_base + '/' + iframe_src.lstrip('/')
        res = resolve_stream(iframe_src, referer=player_url)
        if res[0]:
            return res

    # ── m3u8 direto ───────────────────────────────────────────────────────────
    m3u8 = _find_m3u8(data)
    if m3u8:
        hdrs = {'Referer': player_url, 'User-Agent': UA_WIN, 'Origin': origin_base}
        return _pipe_url(m3u8, hdrs), hdrs

    log('Não resolvido: ' + player_url)
    return None, None


# ─────────────────────────────────────────────────────────────────────────────
#  Sub-resolvers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve_clappr_newkso(data, embed_url, referer):
    try:
        m = re.search(r'''const\s+CHANNEL_KEY\s*=\s*['"]([\w-]+)['"]''', data)
        if not m:
            return None, None
        channel_key = m.group(1)

        m = re.search(r'''const\s+BUNDLE\s*=\s*['"]([A-Za-z0-9+/=]+)['"]''', data)
        if not m:
            return None, None
        parts = json.loads(base64.b64decode(m.group(1)).decode('utf-8'))
        for k in list(parts.keys()):
            try:
                parts[k] = base64.b64decode(parts[k]).decode('utf-8')
            except Exception:
                pass

        pu = urlparse(embed_url)
        origin = '{}://{}'.format(pu.scheme or 'https', pu.netloc)

        # Server lookup
        lookup = '{}/server_lookup.php?channel_id={}'.format(origin, quote_plus(channel_key))
        body = _http_get(lookup, referer=embed_url)
        server_key = ''
        try:
            server_key = str(json.loads(body).get('server_key', '')).strip()
        except Exception:
            m2 = re.search(r'"server_key"\s*:\s*"([^"]+)"', body)
            if m2:
                server_key = m2.group(1).strip()

        if not server_key:
            return None, None

        sk = server_key.strip('/')
        if sk == 'top1/cdn':
            candidates = [
                'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key),
            ]
        else:
            hp = sk.replace('/', '.')
            candidates = [
                'https://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(hp, sk, channel_key),
                'https://new.newkso.ru/{}/{}/mono.m3u8'.format(sk, channel_key),
            ]

        candidates = [re.sub(r'(?<!:)/{2,}', '/', u) for u in candidates]

        flink = candidates[0]
        for u in candidates:
            chunk = _http_get(u, referer=embed_url)
            if chunk:
                flink = u
                break

        hdrs = {'Referer': embed_url, 'Origin': origin, 'User-Agent': UA_WIN}
        log('newkso resolvido: ' + flink)
        return _pipe_url(flink, hdrs), hdrs

    except Exception as e:
        log('_resolve_clappr_newkso: ' + str(e))
        return None, None


def _resolve_hlsurl(data, embed_url):
    m = re.search(r'hlsUrl\s*=\s*["\'](.+?)["\']', data)
    if m:
        return m.group(1)
    # data-page JSON
    if 'data-page=' in data:
        m = re.search(r'data-page=["\']([^"\']+)', data)
        if m:
            try:
                dp = m.group(1).replace('\\/', '/')
                url = json.loads(dp)['props']['streamData']['streamurl']
                return url
            except Exception:
                pass
    return None
