# -*- coding: utf-8 -*-
"""SportHub — Hub Central"""
import os, sys, json, re
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, unquote_plus
except ImportError:
    from urllib import urlencode, unquote_plus

from resources.lib import utils

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

SPORT_CATEGORIES = [
    ('football',          '⚽ Football / Soccer'),
    ('basketball',        '🏀 Basketball / NBA'),
    ('american-football', '🏈 American Football / NFL'),
    ('hockey',            '🏒 Ice Hockey / NHL'),
    ('baseball',          '⚾ Baseball / MLB'),
    ('motor-sports',      '🏎️ Motor Sports'),
    ('fight',             '🥊 Fight (UFC / Boxing)'),
    ('tennis',            '🎾 Tennis'),
    ('rugby',             '🏉 Rugby'),
    ('golf',              '🏌️ Golf'),
    ('cricket',           '🏏 Cricket'),
    ('darts',             '🎯 Darts'),
    ('afl',               '🏉 AFL'),
    ('other',             '🏅 Other Sports'),
]


def _url(mode, **kw):
    p = {'mode': mode}
    p.update(kw)
    return BASE_URL + '?' + urlencode({k: str(v) for k, v in p.items() if v is not None})


def _li(name, icon=None, playable=False, desc=''):
    li = xbmcgui.ListItem(name)
    li.setArt({'thumb': icon or ICON, 'icon': icon or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': name, 'plot': desc or name, 'mediatype': 'video'})
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _add_dir(name, mode, icon=None, folder=True, desc='', **kw):
    url = _url(mode, **kw)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, desc=desc), folder)


def _add_play(name, play_url, icon=None, desc='', is_api=False, base_url=''):
    url = _url('play_stream', url=play_url, name=name,
                is_api='1' if is_api else '0', base_url=base_url)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, playable=True, desc=desc), False)


# ─── Menu Principal ──────────────────────────────────────────────────────────

def show_main():
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, 'SportHub')
    for sport_id, label in SPORT_CATEGORIES:
        _add_dir(label, 'sport_category', icon=ICON, desc=label, sport=sport_id)
    _add_dir('[COLOR dodgerblue]📺 DaddyLive — Canais 24/7[/COLOR]',
             'daddy_channels', icon=ICON)
    utils.eod(HANDLE)


# ─── Categoria de Desporto ───────────────────────────────────────────────────

def show_sport_category(sport_id):
    xbmcplugin.setContent(HANDLE, 'videos')
    label = dict(SPORT_CATEGORIES).get(sport_id, sport_id)
    xbmcplugin.setPluginCategory(HANDLE, label)

    # Streamed API primeiro (mais rápido e fiável)
    events = []
    def _try(fn, src_name):
        try:
            r = fn()
            if r:
                events.extend(r)
        except Exception as e:
            xbmc.log('[SportHub] {} err: {}'.format(src_name, e), xbmc.LOGWARNING)

    from resources.lib.sites import streamed, daddylive
    _try(lambda: streamed.get_matches(sport_id),   'Streamed')
    _try(lambda: daddylive.get_matches(sport_id),  'DaddyLive')

    # Outros sites em segundo plano (só se os principais falharam)
    if len(events) < 3:
        from resources.lib.sites import watchsports, streameast_family, viprow
        _try(lambda: watchsports.get_matches(sport_id),       'WatchSports')
        _try(lambda: streameast_family.get_matches(sport_id), 'StreamEast')
        _try(lambda: viprow.get_matches(sport_id),            'VIPRow')

    if not events:
        utils.notify('Sem eventos disponíveis agora.')
        utils.eod(HANDLE)
        return

    # Ordenar: ★ primeiro, depois por hora
    star   = [e for e in events if e.get('streams') and e['streams'][0].get('star')]
    others = [e for e in events if not (e.get('streams') and e['streams'][0].get('star'))]

    for ev in (star + others):
        title    = ev.get('title', '?')
        time_str = ev.get('time', '')
        icon     = ev.get('icon') or ICON
        streams  = ev.get('streams', [])
        src      = ev.get('source_name', '')
        if not streams:
            continue

        has_star = any(s.get('star') for s in streams)
        pre  = '[COLOR gold]★[/COLOR] ' if has_star else ''
        t    = '[COLOR cyan]{}[/COLOR]  '.format(time_str) if time_str else ''
        s    = '  [COLOR grey]({})[/COLOR]'.format(src) if src else ''
        lbl  = '{}{}{}{}'.format(pre, t, title, s)

        _add_dir(lbl, 'show_streams',
                 icon=icon, desc='{} — {}'.format(time_str, title),
                 streams=json.dumps(streams), title=title)

    utils.eod(HANDLE)


# ─── Lista de streams ────────────────────────────────────────────────────────

def show_streams(streams_json_enc, title=''):
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, title or 'Streams')

    try:
        streams = json.loads(streams_json_enc)
    except Exception:
        try:
            streams = json.loads(unquote_plus(streams_json_enc))
        except Exception:
            streams = []

    if not streams:
        utils.notify('Sem streams.')
        utils.eod(HANDLE)
        return

    for s in streams:
        url      = s.get('url', '')
        label    = s.get('label', 'Stream')
        icon     = s.get('icon') or ICON
        star     = s.get('star', False)
        hd       = s.get('hd', False)
        lang     = s.get('language', '')
        is_page  = s.get('is_page', False)
        is_api   = s.get('is_api', False)
        base_url = s.get('base', '')

        if not url:
            continue

        pre  = '[COLOR gold]★[/COLOR] ' if star else ''
        hd_t = ' [COLOR lime][HD][/COLOR]' if hd else ''
        lg_t = ' [COLOR cyan]({})[/COLOR]'.format(lang) if lang else ''
        lbl  = '{}{}{}{}'.format(pre, label, hd_t, lg_t)

        if is_page:
            # Resolver na hora ao clicar
            _add_dir(lbl, 'resolve_page',
                     icon=icon, folder=True,
                     page_url=url, base=base_url, src_label=label)
        else:
            _add_play(lbl, url, icon=icon, desc=title,
                      is_api=bool(is_api), base_url=base_url)

    utils.eod(HANDLE)


# ─── Resolver página ─────────────────────────────────────────────────────────

def resolve_page_streams(page_url, base_url, src_label):
    """Para is_page=True: vai buscar streams reais e lista-os."""
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, src_label or 'Streams')

    # Para DaddyLive: resolver directamente
    # Para outros: scrape
    from resources.lib.resolver import resolve_stream
    ref = base_url + '/' if base_url and not base_url.endswith('/') else base_url
    stream, _ = resolve_stream(page_url, referer=ref)

    if stream:
        _add_play(src_label or 'Stream', stream, icon=ICON, base_url=base_url)
    else:
        # Fallback: tentar directamente
        _add_play('[TENTAR DIRECTO] ' + (src_label or 'Stream'),
                  page_url, icon=ICON, base_url=base_url)

    utils.eod(HANDLE)


# ─── DaddyLive 24/7 ──────────────────────────────────────────────────────────

def show_daddy_channels():
    from resources.lib.sites.daddylive import get_channels_247, _base
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, '📺 DaddyLive — Canais 24/7')

    b      = _base()
    canais = get_channels_247()

    if not canais:
        utils.notify('Não foi possível carregar os canais. Verifica a ligação.')
        utils.eod(HANDLE)
        return

    for nome, cid in canais:
        _add_dir(nome, 'daddy_channel_players',
                 icon=ICON, cid=cid, name=nome)

    utils.eod(HANDLE)


def show_daddy_channel_players(cid, name):
    from resources.lib.sites.daddylive import get_players
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, name)

    for p in get_players(cid):
        _add_play(p['label'], p['url'], icon=ICON, base_url='')

    utils.eod(HANDLE)
