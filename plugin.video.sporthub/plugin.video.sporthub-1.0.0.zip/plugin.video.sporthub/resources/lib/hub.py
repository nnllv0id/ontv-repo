# -*- coding: utf-8 -*-
"""
SportHub — Hub Central
Agrega todos os sites por categoria de desporto.
"""
import os, sys, json, re
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
except ImportError:
    from urllib import urlencode, quote_plus, unquote_plus
    from urlparse import parse_qsl

from resources.lib import utils

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

SPORT_CATEGORIES = [
    ('football',         '⚽ Football / Soccer'),
    ('basketball',       '🏀 Basketball / NBA'),
    ('american-football','🏈 American Football / NFL'),
    ('hockey',           '🏒 Ice Hockey / NHL'),
    ('baseball',         '⚾ Baseball / MLB'),
    ('motor-sports',     '🏎️ Motor Sports (F1 / MotoGP)'),
    ('fight',            '🥊 Fight (UFC / MMA / Boxing)'),
    ('tennis',           '🎾 Tennis'),
    ('rugby',            '🏉 Rugby'),
    ('golf',             '🏌️ Golf'),
    ('cricket',          '🏏 Cricket'),
    ('darts',            '🎯 Darts'),
    ('afl',              '🏉 AFL'),
    ('other',            '🏅 Other Sports'),
]


# ─── URL helpers ─────────────────────────────────────────────────────────────
# REGRA: urlencode trata do encoding — NÃO usar quote_plus nos valores antes

def _url(mode, **kw):
    p = {'mode': mode}
    p.update(kw)
    return BASE_URL + '?' + urlencode({k: str(v) for k, v in p.items() if v is not None})


def _li(name, icon=None, playable=False, desc=''):
    li = xbmcgui.ListItem(name)
    li.setArt({'thumb': icon or ICON, 'icon': icon or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': name, 'plot': desc or name, 'mediatype': 'video'})
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _add_dir(name, mode, icon=None, folder=True, desc='', **kw):
    url = _url(mode, **kw)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, desc=desc), folder)


def _add_play(name, play_url, mode, icon=None, desc='', **kw):
    # play_url vai directo para urlencode — sem quote_plus extra
    url = _url(mode, url=play_url, name=name, **kw)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, playable=True, desc=desc), False)


# ─── Menu Principal ───────────────────────────────────────────────────────────

def show_main():
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, 'SportHub')

    for sport_id, label in SPORT_CATEGORIES:
        icon = os.path.join(ADDON_PATH, 'resources', 'images',
                            'sport_{}.png'.format(sport_id.replace('-', '_')))
        if not os.path.exists(icon):
            icon = ICON
        _add_dir(label, 'sport_category', icon=icon,
                 desc='Ver todos os eventos de {}'.format(label),
                 sport=sport_id)

    _add_dir('[COLOR dodgerblue]📺 DaddyLive — Canais 24/7[/COLOR]',
             'daddy_channels', icon=ICON,
             desc='Mais de 1000 canais 24/7 em directo')

    utils.eod(HANDLE)


# ─── Categoria de Desporto ────────────────────────────────────────────────────

def show_sport_category(sport_id):
    xbmcplugin.setContent(HANDLE, 'videos')
    label = dict(SPORT_CATEGORIES).get(sport_id, sport_id)
    xbmcplugin.setPluginCategory(HANDLE, label)

    xbmcgui.Dialog().notification('SportHub', 'A carregar {}...'.format(label), ICON, 2000)

    events = _aggregate_events(sport_id)

    if not events:
        utils.notify('Sem eventos disponíveis agora.')
        utils.eod(HANDLE)
        return

    # ★ primeiro, depois por hora
    star_events  = [e for e in events if e.get('streams') and e['streams'][0].get('star')]
    other_events = [e for e in events if not (e.get('streams') and e['streams'][0].get('star'))]

    for ev in (star_events + other_events):
        title    = ev.get('title', '?')
        time_str = ev.get('time', '')
        icon     = ev.get('icon') or ICON
        streams  = ev.get('streams', [])
        src_name = ev.get('source_name', '')

        if not streams:
            continue

        has_star = any(s.get('star') for s in streams)
        prefix   = '[COLOR gold]★[/COLOR] ' if has_star else ''
        time_tag = '[COLOR cyan]{}[/COLOR]  '.format(time_str) if time_str else ''
        src_tag  = '  [COLOR grey]({})[/COLOR]'.format(src_name) if src_name else ''
        full_lbl = '{}{}{}{}'.format(prefix, time_tag, title, src_tag)

        # Serializar streams como JSON — urlencode fará o encoding correcto
        streams_json = json.dumps(streams)

        _add_dir(full_lbl, 'show_streams',
                 icon=icon,
                 desc='{} — {}'.format(time_str, title),
                 streams=streams_json,
                 title=title)

    utils.eod(HANDLE)


# ─── Lista de streams de um evento ───────────────────────────────────────────

def show_streams(streams_json_enc, title=''):
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, title or 'Streams')

    # parse_qsl já fez unquote uma vez — o JSON deve estar limpo
    try:
        streams = json.loads(streams_json_enc)
    except Exception:
        # Tentar unquote extra caso venha ainda encoded
        try:
            streams = json.loads(unquote_plus(streams_json_enc))
        except Exception:
            streams = []

    if not streams:
        utils.notify('Sem streams disponíveis.')
        utils.eod(HANDLE)
        return

    for s in streams:
        url      = s.get('url', '')
        label    = s.get('label', s.get('source', 'Stream'))
        lang     = s.get('language', '')
        hd       = s.get('hd', False)
        star     = s.get('star', False)
        icon     = s.get('icon') or ICON
        is_page  = s.get('is_page', False)
        is_api   = s.get('is_api', False)
        base_url = s.get('base', '')

        if not url:
            continue

        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        hd_tag = ' [COLOR lime][HD][/COLOR]' if hd else ''
        lg_tag = ' [COLOR cyan]({})[/COLOR]'.format(lang) if lang else ''
        full   = '{}{}{}{}'.format(prefix, label, hd_tag, lg_tag)

        if is_page:
            # Ir buscar streams reais da página → modo intermédio
            _add_dir(full, 'resolve_page',
                     icon=icon, folder=True,
                     page_url=url,
                     src_label=label,
                     base=base_url)
        else:
            # Reproduzir directamente (ou via API Streamed)
            _add_play(full, url, 'play_stream',
                      icon=icon, desc=title,
                      is_api='1' if is_api else '0',
                      base_url=base_url)

    utils.eod(HANDLE)


# ─── Resolve página → streams reais ──────────────────────────────────────────

def resolve_page_streams(page_url, base_url, src_label):
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, src_label or 'Streams')

    streams = _get_page_streams(page_url, base_url)

    if not streams:
        # Fallback: tentar resolver directamente
        streams = [{
            'url':   page_url,
            'label': src_label or 'Stream',
            'hd':    True,
            'star':  False,
        }]

    for s in streams:
        url   = s.get('url', '')
        label = s.get('label', s.get('source', 'Stream'))
        icon  = s.get('icon') or ICON
        star  = s.get('star', False)
        if not url:
            continue
        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        _add_play(prefix + label, url, 'play_stream',
                  icon=icon, is_api='0', base_url=base_url)

    utils.eod(HANDLE)


def _get_page_streams(page_url, base_url):
    """Dispatch para o módulo correcto baseado no URL."""
    u = page_url.lower()

    if any(x in u for x in ['streamed.su', 'streamed.pk', 'streamed.st']):
        from resources.lib.sites.streamed import resolve_api_stream, base as s_base
        b = s_base()
        stream = resolve_api_stream(page_url, b)
        return [{'url': stream, 'label': '★ Streamed', 'hd': True, 'star': True}] if stream else []

    if 'watchsports.to' in u:
        from resources.lib.sites.watchsports import get_streams_from_page
        return get_streams_from_page(page_url)

    if 'streameast.games' in u or 'totalsportek.events' in u:
        from resources.lib.sites.streameast_family import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if 'viprow.co' in u or 'cricwatch' in u or 'mlbstreams' in u:
        from resources.lib.sites.viprow import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if '720pstreams' in u:
        from resources.lib.sites.streams720p import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if any(x in u for x in ['dlstreams', 'daddylive', 'daddylives', 'dlhd']):
        # Player directo — resolver inline
        return [{'url': page_url, 'label': '★ DaddyLive', 'hd': True, 'star': True}]

    if 'crackstreams' in u or 'buffstream' in u:
        from resources.lib.sites.crackstreams import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if 'nbamonster' in u:
        from resources.lib.sites.specialty import get_nbamonster_streams
        return get_nbamonster_streams(page_url)

    if 'onhockey' in u:
        from resources.lib.sites.specialty import get_nbamonster_streams
        return get_nbamonster_streams(page_url)

    # Genérico — resolver directamente
    from resources.lib.resolver import resolve_stream
    ref = base_url + '/' if base_url and not base_url.endswith('/') else base_url
    stream, _ = resolve_stream(page_url, referer=ref)
    return [{'url': stream, 'label': 'Stream', 'hd': True, 'star': False}] if stream else []


# ─── Aggregator ───────────────────────────────────────────────────────────────

def _aggregate_events(sport_id):
    events = []

    def _try(fn, name):
        try:
            result = fn()
            events.extend(result)
            xbmc.log('[SportHub] {} → {} eventos'.format(name, len(result)), xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log('[SportHub] {} erro: {}'.format(name, e), xbmc.LOGWARNING)

    from resources.lib.sites import streamed, watchsports, streameast_family, viprow, daddylive, crackstreams, streams720p, specialty

    _try(lambda: streamed.get_matches(sport_id),           '★ Streamed')
    _try(lambda: watchsports.get_matches(sport_id),        '★ WatchSports')
    _try(lambda: streameast_family.get_matches(sport_id),  '★ StreamEast')
    _try(lambda: viprow.get_matches(sport_id),             '★ VIPRow')
    _try(lambda: daddylive.get_matches(sport_id),          '★ DaddyLive')
    _try(lambda: crackstreams.get_matches(sport_id),       'CrackStreams')
    _try(lambda: streams720p.get_matches(sport_id),        '720pStreams')
    _try(lambda: specialty.get_buffstream_matches(sport_id), 'BuffStream')

    if sport_id == 'basketball':
        _try(lambda: specialty.get_nbamonster_matches(), 'NBAMonster')

    if sport_id == 'hockey':
        _try(lambda: specialty.get_onhockey_matches(), 'OnHockey')

    return events


# ─── DaddyLive Canais 24/7 ────────────────────────────────────────────────────

def show_daddy_channels():
    from resources.lib.sites.daddylive import get_channels_247, _base
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, '📺 DaddyLive — Canais 24/7')

    b = _base()
    canais = get_channels_247()

    if not canais:
        utils.notify('Não foi possível carregar os canais DaddyLive.')
        utils.eod(HANDLE)
        return

    for nome, cid in canais:
        slug = re.sub(r'[^a-z0-9_]', '_', nome.lower())
        icon = '{}/assets/logos/{}.png'.format(b, slug)
        _add_dir(nome, 'daddy_channel_players',
                 icon=icon, cid=cid, name=nome)

    utils.eod(HANDLE)


def show_daddy_channel_players(cid, name):
    from resources.lib.sites.daddylive import get_players
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, name)

    for p in get_players(cid):
        star = p.get('star', False)
        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        _add_play(prefix + p['label'], p['url'], 'play_stream',
                  icon=ICON, is_api='0', base_url='')

    utils.eod(HANDLE)
