# -*- coding: utf-8 -*-
"""
SportHub v3 — Hub Central
Agrega todos os sites por categoria de desporto.
★ = streamed, watchsports, streameast, viprow, daddylive
  = crackstreams, 720pstreams, nbamonster, onhockey, buffstream
"""
import os, sys, json, re
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
except ImportError:
    from urllib import urlencode, quote_plus, unquote_plus
    from urlparse import parse_qsl

from resources.lib import utils

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

# ─── Categorias ───────────────────────────────────────────────────────────────
SPORT_CATEGORIES = [
    ('football',         '⚽ Football / Soccer'),
    ('basketball',       '🏀 Basketball / NBA'),
    ('american-football','🏈 American Football / NFL'),
    ('hockey',           '🏒 Ice Hockey / NHL'),
    ('baseball',         '⚾ Baseball / MLB'),
    ('motor-sports',     '🏎️ Motor Sports (F1 / MotoGP)'),
    ('fight',            '🥊 Fight (UFC / MMA / Boxing)'),
    ('tennis',           '🎾 Tennis'),
    ('rugby',            '🏉 Rugby'),
    ('golf',             '🏌️ Golf'),
    ('cricket',          '🏏 Cricket'),
    ('darts',            '🎯 Darts'),
    ('afl',              '🏉 AFL'),
    ('other',            '🏅 Other Sports'),
]


# ─── UI helpers ───────────────────────────────────────────────────────────────

def _url(mode, **kw):
    p = {'mode': mode}
    p.update(kw)
    return BASE_URL + '?' + urlencode({k: str(v) for k, v in p.items() if v is not None})


def _li(name, icon=None, playable=False, desc=''):
    li = xbmcgui.ListItem(name)
    li.setArt({'thumb': icon or ICON, 'icon': icon or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': name, 'plot': desc or name, 'mediatype': 'video'})
    if playable:
        li.setProperty('IsPlayable', 'true')
    return li


def _add_dir(name, mode, icon=None, folder=True, desc='', **kw):
    url = _url(mode, **kw)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, desc=desc), folder)


def _add_play(name, play_url, mode, icon=None, desc='', **kw):
    url = _url(mode, url=play_url, name=quote_plus(name), **kw)
    xbmcplugin.addDirectoryItem(HANDLE, url, _li(name, icon, playable=True, desc=desc), False)


# ─── Menu Principal ───────────────────────────────────────────────────────────

def show_main():
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, 'SportHub')

    for sport_id, label in SPORT_CATEGORIES:
        icon = os.path.join(ADDON_PATH, 'resources', 'images',
                            'sport_{}.png'.format(sport_id.replace('-', '_')))
        if not os.path.exists(icon):
            icon = ICON
        _add_dir(label, 'sport_category', icon=icon,
                 desc='Ver todos os eventos de {}'.format(label),
                 sport=sport_id)

    # DaddyLive 24/7 Canais — menu extra
    _add_dir('[COLOR dodgerblue]📺 DaddyLive — Canais 24/7[/COLOR]',
             'daddy_channels', icon=ICON,
             desc='Mais de 1000 canais 24/7 em directo')

    utils.eod(HANDLE)


# ─── Categoria de Desporto ────────────────────────────────────────────────────

def show_sport_category(sport_id):
    xbmcplugin.setContent(HANDLE, 'videos')
    label = dict(SPORT_CATEGORIES).get(sport_id, sport_id)
    xbmcplugin.setPluginCategory(HANDLE, label)

    xbmcgui.Dialog().notification('SportHub', 'A carregar {}...'.format(label), ICON, 2000)

    events = _aggregate_events(sport_id)

    if not events:
        utils.notify('Sem eventos disponíveis agora para {}.'.format(label))
        utils.eod(HANDLE)
        return

    # Ordenar: ★ primeiro, depois por hora
    star_events  = [e for e in events if e.get('streams', [{}])[0].get('star')]
    other_events = [e for e in events if not e.get('streams', [{}])[0].get('star')]
    sorted_events = star_events + other_events

    for ev in sorted_events:
        title    = ev.get('title', '?')
        time_str = ev.get('time', '')
        icon     = ev.get('icon') or ICON
        streams  = ev.get('streams', [])
        src_name = ev.get('source_name', '')

        if not streams:
            continue

        # Prefixo visual: ★ se algum stream for star
        has_star = any(s.get('star') for s in streams)
        prefix   = '[COLOR gold]★[/COLOR] ' if has_star else ''
        time_tag = '[COLOR cyan]{}[/COLOR]  '.format(time_str) if time_str else ''
        src_tag  = '  [COLOR grey]({})[/COLOR]'.format(src_name) if src_name else ''

        label_full = '{}{}{}{}'.format(prefix, time_tag, title, src_tag)

        streams_json = quote_plus(json.dumps(streams))
        _add_dir(label_full, 'show_streams',
                 icon=icon,
                 desc='{} — {}'.format(time_str, title),
                 streams=streams_json,
                 title=quote_plus(title))

    utils.eod(HANDLE)


# ─── Lista de streams de um evento ───────────────────────────────────────────

def show_streams(streams_json_enc, title=''):
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, unquote_plus(title) if title else 'Streams')

    try:
        streams = json.loads(streams_json_enc)
    except Exception:
        streams = []

    if not streams:
        utils.notify('Sem streams disponíveis.')
        utils.eod(HANDLE)
        return

    for s in streams:
        url      = s.get('url', '')
        label    = s.get('label', s.get('source', 'Stream'))
        lang     = s.get('language', '')
        hd       = s.get('hd', False)
        star     = s.get('star', False)
        icon     = s.get('icon') or ICON
        is_page  = s.get('is_page', False)
        is_api   = s.get('is_api', False)
        base_url = s.get('base', '')

        if not url:
            continue

        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        hd_tag = ' [COLOR lime][HD][/COLOR]' if hd else ''
        lg_tag = ' [COLOR cyan]({})[/COLOR]'.format(lang) if lang else ''
        full   = '{}{}{}{}'.format(prefix, label, hd_tag, lg_tag)

        kw = {'base': base_url} if base_url else {}

        if is_page:
            # Precisa de ir buscar streams da página → modo intermédio
            _add_dir(full, 'resolve_page',
                     icon=icon, folder=True,
                     page_url=quote_plus(url),
                     name=quote_plus(label),
                     base=quote_plus(base_url),
                     src_label=quote_plus(label))
        else:
            # Reproduzir directamente (ou via API)
            _add_play(full, url, 'play_stream', icon=icon, desc=title,
                      is_api='1' if is_api else '0',
                      base_url=quote_plus(base_url))

    utils.eod(HANDLE)


# ─── Resolve página → lista de streams reais ─────────────────────────────────

def resolve_page_streams(page_url, base_url, src_label):
    """
    Vai à página do evento e extrai os iframes/streams reais.
    Depois mostra-os como items reproduzíveis.
    """
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, src_label)

    # Determinar qual site está a ser resolvido com base no URL
    streams = _get_page_streams(page_url, base_url)

    if not streams:
        # Tentar resolver directamente
        streams = [{
            'source':  src_label,
            'url':     page_url,
            'label':   src_label,
            'hd':      True,
            'star':    False,
        }]

    for s in streams:
        url   = s.get('url', '')
        label = s.get('label', s.get('source', 'Stream'))
        icon  = s.get('icon') or ICON
        star  = s.get('star', False)
        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        _add_play(prefix + label, url, 'play_stream', icon=icon,
                  is_api='0', base_url=quote_plus(base_url))

    utils.eod(HANDLE)


def _get_page_streams(page_url, base_url):
    """Dispatch para o site correcto baseado no URL."""
    u = page_url.lower()

    if 'streamed.su' in u or 'streamed.pk' in u or 'streamed.st' in u:
        from resources.lib.sites.streamed import resolve_api_stream, base as s_base
        b = s_base()
        stream = resolve_api_stream(page_url, b)
        return [{'url': stream, 'label': '★ Streamed', 'hd': True, 'star': True}] if stream else []

    if 'watchsports.to' in u:
        from resources.lib.sites.watchsports import get_streams_from_page
        return get_streams_from_page(page_url)

    if 'streameast.games' in u or 'totalsportek.events' in u:
        from resources.lib.sites.streameast_family import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if 'viprow.co' in u or 'cricwatch' in u or 'mlbstreams' in u:
        from resources.lib.sites.viprow import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if '720pstreams' in u:
        from resources.lib.sites.streams720p import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if 'dlstreams' in u or 'daddylive' in u or 'daddylives' in u:
        # player directo — resolver
        return [{'url': page_url, 'label': '★ DaddyLive', 'hd': True, 'star': True}]

    if 'crackstreams' in u or 'buffstream' in u:
        from resources.lib.sites.crackstreams import get_streams_from_page
        return get_streams_from_page(page_url, base_url)

    if 'nbamonster' in u:
        from resources.lib.sites.specialty import get_nbamonster_streams
        return get_nbamonster_streams(page_url)

    if 'onhockey' in u:
        from resources.lib.sites.specialty import get_nbamonster_streams
        return get_nbamonster_streams(page_url)

    # Genérico
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(page_url, referer=base_url + '/' if base_url else '')
    return [{'url': stream, 'label': 'Stream', 'hd': True, 'star': False}] if stream else []


# ─── Aggregator ───────────────────────────────────────────────────────────────

def _aggregate_events(sport_id):
    """Agrega eventos de todos os sites para um desporto."""
    events = []

    # ★ 1. Streamed API (melhor fonte)
    try:
        from resources.lib.sites.streamed import get_matches as sm
        events += sm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] Streamed err: ' + str(e), xbmc.LOGWARNING)

    # ★ 2. WatchSports
    try:
        from resources.lib.sites.watchsports import get_matches as wm
        events += wm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] WatchSports err: ' + str(e), xbmc.LOGWARNING)

    # ★ 3. StreamEast/TotalSportek
    try:
        from resources.lib.sites.streameast_family import get_matches as sem
        events += sem(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] StreamEast err: ' + str(e), xbmc.LOGWARNING)

    # ★ 4. VIPRow
    try:
        from resources.lib.sites.viprow import get_matches as vm
        events += vm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] VIPRow err: ' + str(e), xbmc.LOGWARNING)

    # ★ 5. DaddyLive
    try:
        from resources.lib.sites.daddylive import get_matches as dm
        events += dm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] DaddyLive err: ' + str(e), xbmc.LOGWARNING)

    # 6. CrackStreams
    try:
        from resources.lib.sites.crackstreams import get_matches as cm
        events += cm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] CrackStreams err: ' + str(e), xbmc.LOGWARNING)

    # 7. 720pStreams
    try:
        from resources.lib.sites.streams720p import get_matches as p720m
        events += p720m(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] 720p err: ' + str(e), xbmc.LOGWARNING)

    # 8. BuffStream (extra cobertura)
    try:
        from resources.lib.sites.specialty import get_buffstream_matches as bm
        events += bm(sport_id)
    except Exception as e:
        xbmc.log('[SportHub] BuffStream err: ' + str(e), xbmc.LOGWARNING)

    # 9. NBAMonster (apenas basketball)
    if sport_id == 'basketball':
        try:
            from resources.lib.sites.specialty import get_nbamonster_matches as nm
            events += nm()
        except Exception as e:
            xbmc.log('[SportHub] NBAMonster err: ' + str(e), xbmc.LOGWARNING)

    # 10. OnHockey (apenas hockey)
    if sport_id == 'hockey':
        try:
            from resources.lib.sites.specialty import get_onhockey_matches as oh
            events += oh()
        except Exception as e:
            xbmc.log('[SportHub] OnHockey err: ' + str(e), xbmc.LOGWARNING)

    return events


# ─── DaddyLive Canais 24/7 ────────────────────────────────────────────────────

def show_daddy_channels():
    from resources.lib.sites.daddylive import get_channels_247, _base
    xbmcplugin.setContent(HANDLE, 'files')
    xbmcplugin.setPluginCategory(HANDLE, '📺 DaddyLive — Canais 24/7')

    b = _base()
    canais = get_channels_247()
    if not canais:
        utils.notify('Não foi possível carregar os canais.')
        utils.eod(HANDLE)
        return

    for nome, cid in canais:
        slug = nome.lower().replace(' ', '_').replace('/', '_').replace('(', '').replace(')', '')
        icon = b + '/assets/logos/{}.png'.format(slug)
        _add_dir(nome, 'daddy_channel_players',
                 icon=icon, cid=cid, name=quote_plus(nome))

    utils.eod(HANDLE)


def show_daddy_channel_players(cid, name):
    from resources.lib.sites.daddylive import get_players
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.setPluginCategory(HANDLE, name)

    for p in get_players(cid):
        star = p.get('star', False)
        prefix = '[COLOR gold]★[/COLOR] ' if star else ''
        _add_play(prefix + p['label'], p['url'], 'play_stream',
                  icon=ICON, is_api='0', base_url='')

    utils.eod(HANDLE)
