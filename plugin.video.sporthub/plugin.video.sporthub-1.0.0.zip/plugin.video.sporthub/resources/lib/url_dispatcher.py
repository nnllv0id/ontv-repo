# -*- coding: utf-8 -*-
"""
URL Dispatcher — adaptado do Cumination (tknorris)
Regista funções por modo e despacha chamadas do Kodi.
"""
try:
    from inspect import getfullargspec as getargspec
except ImportError:
    from inspect import getargspec

import os, sys, re
import xbmc, xbmcgui, xbmcplugin, xbmcaddon

try:
    from urllib.parse import urlencode, quote_plus, unquote_plus, parse_qsl
except ImportError:
    from urllib import urlencode, quote_plus, unquote_plus
    from urlparse import parse_qsl

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_NAME = ADDON.getAddonInfo('name')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')
IMG_DIR    = os.path.join(ADDON_PATH, 'resources', 'images')


def _img(fn):
    if not fn:
        return ICON
    if fn.startswith('http'):
        return fn
    return os.path.join(IMG_DIR, fn)


class URL_Dispatcher(object):
    func_registry   = {}
    args_registry   = {}
    kwargs_registry = {}

    def __init__(self, module_name):
        if not module_name:
            raise Exception('URL_Dispatcher: module_name obrigatório')
        if '.' in module_name:
            raise Exception('URL_Dispatcher: module_name não pode conter "."')
        self.module_name = module_name

    # ── Registo ───────────────────────────────────────────────────────────────

    def register(self):
        def decorator(f):
            mode = '{}.{}'.format(self.module_name, f.__name__)
            spec = getargspec(f)
            all_args  = spec.args or []
            defaults  = spec.defaults or []
            n_req     = len(all_args) - len(defaults)
            func_args   = all_args[:n_req]
            func_kwargs = all_args[n_req:]

            if mode in self.__class__.func_registry:
                raise Exception('Modo já registado: {}'.format(mode))

            self.__class__.func_registry[mode]   = f
            self.__class__.args_registry[mode]   = func_args
            self.__class__.kwargs_registry[mode] = func_kwargs
            return f
        return decorator

    def get_full_mode(self, mode):
        return mode if '.' in str(mode) else '{}.{}'.format(self.module_name, mode)

    # ── Despacho ──────────────────────────────────────────────────────────────

    @classmethod
    def dispatch(cls, mode, queries):
        if mode is None:
            mode = 'main.INDEX'
        mode = mode.strip()
        if mode not in cls.func_registry:
            xbmc.log('[SportHub] Modo desconhecido: ' + mode, xbmc.LOGERROR)
            xbmcgui.Dialog().notification(ADDON_NAME, 'Erro: modo desconhecido — ' + mode, ICON, 4000)
            return
        f       = cls.func_registry[mode]
        args    = cls.args_registry.get(mode, [])
        kwargs  = cls.kwargs_registry.get(mode, [])

        call_args   = [queries[a] for a in args   if a in queries]
        call_kwargs = {k: queries[k] for k in kwargs if k in queries}
        f(*call_args, **call_kwargs)

    # ── Adicionar directório ──────────────────────────────────────────────────

    def add_dir(self, name, url, mode, iconimage=None, page=None, channel=None,
                section=None, keyword='', Folder=True, about=None, desc='',
                contextm=None, **kwargs):
        mode_full = self.get_full_mode(mode)
        iconimage = iconimage or ICON

        u = (BASE_URL
             + '?mode='    + quote_plus(mode_full)
             + '&url='     + quote_plus(url or '')
             + '&name='    + quote_plus(name)
             + ('&page='   + quote_plus(str(page))    if page    else '')
             + ('&channel='+ quote_plus(str(channel)) if channel else '')
             + ('&section='+ quote_plus(str(section)) if section else '')
             + ('&keyword='+ quote_plus(keyword)       if keyword else ''))

        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': FANART})
        li.setInfo('video', {'title': name, 'plot': desc or name, 'mediatype': 'video'})

        if contextm:
            li.addContextMenuItems(contextm)

        xbmcplugin.addDirectoryItem(HANDLE, u, li, Folder)

    def search_dir(self, url, mode):
        """Adiciona entrada de pesquisa que pede teclado."""
        self.add_dir('[COLOR yellow]🔍 Pesquisar[/COLOR]', url, mode,
                     _img('hub-search.png'), keyword='__SEARCH__')

    # ── Adicionar link de download / reprodução ───────────────────────────────

    def add_download_link(self, name, url, mode, iconimage=None, desc='',
                          stream=None, fav='add', noDownload=False,
                          contextm=None, fanart=None, duration='', quality=''):
        mode_full  = self.get_full_mode(mode)
        iconimage  = iconimage or ICON
        fanart     = fanart or FANART

        u = (BASE_URL
             + '?mode='    + quote_plus(mode_full)
             + '&url='     + quote_plus(url)
             + '&name='    + quote_plus(name)
             + ('&download=1' if not noDownload else ''))

        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': fanart})
        li.setInfo('video', {
            'title':     name,
            'plot':      desc or name,
            'duration':  duration,
            'mediatype': 'video',
        })
        li.setProperty('IsPlayable', 'true')

        if contextm:
            li.addContextMenuItems(contextm)

        xbmcplugin.addDirectoryItem(HANDLE, u, li, False)
