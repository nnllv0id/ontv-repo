# -*- coding: utf-8 -*-
"""
SportHub — SportHD (baseado em sporthdme)
Eventos ao vivo via super.league.do ou variantes
"""
import re
import json
import datetime
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'sportshd',
    '[COLOR tomato]SportsHD[/COLOR]',
    'https://sportvid.net/',
    'sportshd.png',
    about='SportsHD — eventos ao vivo scraped em tempo real'
)

# Possíveis domínios base (atualizar se mudarem)
BASES = [
    'https://sportvid.net',
    'https://sportvideos.net',
    'https://sportshdme.net',
]
BASE = BASES[0]


def _get_base():
    """Tenta o primeiro domínio disponível."""
    for b in BASES:
        html = utils.getHtml(b + '/', timeout=8)
        if html:
            return b
    return BASES[0]


@site.register(default_mode=True)
def Main():
    base = _get_base()
    try:
        html = utils.getHtml(base + '/', referer=base + '/')
    except Exception:
        utils.notify('Erro ao carregar SportsHD.')
        utils.eod()
        return

    if not html:
        utils.eod()
        return

    # Tentar matches via window.matches ou JSON inline
    matches = _parse_matches(html, base)

    if not matches:
        utils.notify('Sem eventos encontrados. Domínio pode ter mudado.')
        utils.eod()
        return

    for ev in matches:
        nome   = ev.get('name', ev.get('event', '?'))
        hora   = ev.get('time', ev.get('date', ''))
        liga   = ev.get('league', ev.get('category', ''))
        thumb  = ev.get('thumb', ev.get('poster', site.image))
        streams = ev.get('streams', ev.get('channels', []))
        if not streams:
            continue
        label = '[COLOR gold]{}[/COLOR]  {} [COLOR gray]({})[/COLOR]'.format(hora, nome, liga)
        # Guardar streams como JSON no URL
        site.add_dir(label, json.dumps(streams), 'EventStreams', thumb or site.img_live,
                     desc='{} {}'.format(hora, nome))

    utils.eod()


def _parse_matches(html, base):
    """Extrai lista de matches do HTML."""
    # Padrão 1: window.matches = JSON.parse(...)
    m = re.search(r'window\.matches\s*=\s*JSON\.parse\([\'"](.*?)[\'"]\)', html, re.DOTALL)
    if m:
        try:
            raw = m.group(1).replace('\\"', '"').replace("\\'", "'")
            return json.loads(raw)
        except Exception:
            pass

    # Padrão 2: var matches = [...]
    m = re.search(r'var\s+matches\s*=\s*(\[.+?\]);', html, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass

    # Padrão 3: scrape de cards de eventos
    cards = re.findall(
        r'<div[^>]+class=["\'][^"\']*(?:event|match|game)[^"\']*["\'][^>]*>'
        r'.*?href=["\']([^"\']+)["\'].*?<[^>]+class=["\'][^"\']*(?:title|name)[^"\']*["\'][^>]*>([^<]+)',
        html, re.DOTALL | re.IGNORECASE
    )
    if cards:
        result = []
        for url_path, nome in cards:
            full = url_path if url_path.startswith('http') else base + url_path
            result.append({'name': utils.cleantext(nome), 'streams': [full], 'time': ''})
        return result

    return []


@site.register()
def EventStreams(url):
    """Lista streams de um evento."""
    try:
        streams = json.loads(url)
    except Exception:
        streams = [url]

    for i, s in enumerate(streams, start=1):
        if isinstance(s, dict):
            stream_url = s.get('url', s.get('stream', s.get('src', '')))
            quality    = s.get('quality', s.get('label', 'Stream {}'.format(i)))
        else:
            stream_url = str(s)
            quality    = 'Stream {}'.format(i)

        if not stream_url:
            continue

        label = '[COLOR gold]{}[/COLOR]'.format(quality)
        site.add_download_link(label, stream_url, 'Playvid', site.img_live, desc=quality)

    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(url)
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido.')
        import xbmcplugin, xbmcgui, sys
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
