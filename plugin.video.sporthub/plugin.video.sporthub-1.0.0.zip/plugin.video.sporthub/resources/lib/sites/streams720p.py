# -*- coding: utf-8 -*-
"""
720pStreams — 720pstreams.tv
Estrutura verificada:
  /{sport}-online → lista de jogos (links /live/{sport}/{slug})
  /live/{sport}/{slug} → iframe/stream
"""
import re
from resources.lib import utils

NAME = '720pStreams'
STAR = False
BASE = 'https://720pstreams.tv'
CDN  = 'https://cdn.720pstreams.tv'

SPORT_PATH = {
    'basketball':        '/nba-online',
    'american-football': '/nfl-online',
    'hockey':            '/nhl-online',
    'baseball':          '/mlb-online',
    'fight':             '/mma-online',
    'football':          '/soccer-online',
}


def get_matches(sport_hub_id):
    path = SPORT_PATH.get(sport_hub_id)
    if not path:
        return []

    url  = BASE + path
    html = utils.getHtml(url, referer=BASE + '/')
    if not html:
        return []

    # Padrão: href="/live/{sport}/{slug}" com nome de equipa
    matches = re.findall(
        r'href=["\'](' + re.escape(BASE) + r'/live/\w+/([^"\']+))["\']'
        r'[\s\S]{0,200}?'
        r'(?:alt=["\']([^"\']{3,50})["\'])?',
        html, re.I
    )

    # Simpler fallback
    if not matches:
        links = re.findall(
            r'href=["\'](' + re.escape(BASE) + r'/live/\w+/([^"\']+))["\'][^>]*>\s*([^<]{3,60})',
            html, re.I
        )
        events = []
        seen = set()
        for url_ev, slug, title in links:
            title = utils.cleantext(title)
            if not title or slug in seen or len(title) < 3: continue
            seen.add(slug)
            title_clean = slug.replace('-', ' ').replace('vs', ' vs ').title() if not title else title
            events.append({
                'title':   title_clean,
                'time':    '24/7' if '24-7' in slug or 'tv' in slug.lower() else '',
                'icon':    '',
                'streams': [{
                    'source':   NAME,
                    'url':      url_ev,
                    'label':    '720pStreams',
                    'hd':       True,
                    'language': 'EN',
                    'star':     False,
                    'is_page':  True,
                    'base':     BASE,
                    'icon':     '',
                }],
                'source_name': NAME,
            })
        return events

    events = []
    seen = set()
    for url_ev, slug, alt in matches:
        if slug in seen: continue
        seen.add(slug)
        title = utils.cleantext(alt) if alt else slug.replace('-', ' ').title()
        events.append({
            'title':   title,
            'time':    '',
            'icon':    '',
            'streams': [{
                'source':   NAME,
                'url':      url_ev,
                'label':    '720pStreams',
                'hd':       True,
                'language': 'EN',
                'star':     False,
                'is_page':  True,
                'base':     BASE,
                'icon':     '',
            }],
            'source_name': NAME,
        })
    return events


def get_streams_from_page(event_url, base_url=BASE):
    html = utils.getHtml(event_url, referer=base_url + '/')
    if not html:
        return []

    streams = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for i, src in enumerate(iframes, 1):
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else base_url + '/' + src.lstrip('/')
        if any(x in src for x in ['ads', 'google']): continue
        streams.append({
            'source':   '720pStreams — Stream {}'.format(i),
            'url':      src,
            'label':    '720pStreams — Stream {}'.format(i),
            'hd':       True,
            'language': 'EN',
            'star':     False,
        })

    return streams
