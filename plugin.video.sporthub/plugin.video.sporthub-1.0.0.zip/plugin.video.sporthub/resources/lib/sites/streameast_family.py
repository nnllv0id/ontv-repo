# -*- coding: utf-8 -*-
"""
★ StreamEast / TotalSportek — streameast.games + totalsportek.events
Mesma plataforma/backend — share the same CDN and event slugs.
Padrão de listagem verificado:
  /{sport}  → lista de eventos com slug
  /events/{slug} → página do evento com iframes
"""
import re
from resources.lib import utils

NAME  = '★ StreamEast'
STAR  = True

# Domínios do mesmo backend (partilham os mesmos slugs de eventos)
FAMILY_BASES = [
    'https://streameast.games',
    'https://totalsportek.events',
]

# Mapa sport_hub_id → path no site
SPORT_PATH = {
    'football':          '/football',
    'basketball':        '/nba',
    'american-football': '/nfl',
    'hockey':            '/nhl',
    'fight':             '/ufc',
    'motor-sports':      '/f1',
    'rugby':             '/rugby',
    'baseball':          '/nfl',  # não tem — usar NFL como fallback
}


def _active_base():
    for b in FAMILY_BASES:
        html = utils.getHtml(b + '/', timeout=8)
        if html and 'football' in html.lower():
            return b
    return FAMILY_BASES[0]


def get_matches(sport_hub_id):
    path = SPORT_PATH.get(sport_hub_id)
    if not path:
        return []

    base = _active_base()
    url  = base + path
    html = utils.getHtml(url, referer=base + '/')
    if not html:
        return []

    # Padrão verificado: href="/events/slug">
    # com imagens e títulos das equipas
    events_raw = re.findall(
        r'href=["\'](' + re.escape(base) + r'/events/([^"\']+))["\']'
        r'[\s\S]{0,500}?'
        r'(?:Live Now!|Starts in:[^<]{0,30})?'
        r'[\s\S]{0,200}?'
        r'(?:alt=["\']([^"\']{3,50})["\'][\s\S]{0,100}?alt=["\']([^"\']{3,50})["\'])',
        html, re.IGNORECASE
    )

    # Fallback: simples captura de slugs e títulos próximos
    if not events_raw:
        events_raw = re.findall(
            r'href=["\'](' + re.escape(base) + r'/events/([^"\']+))["\'][^>]*>',
            html, re.IGNORECASE
        )
        events = []
        seen = set()
        for url_ev, slug in events_raw:
            if slug in seen: continue
            seen.add(slug)
            title = slug.replace('-', ' ').replace('vs', ' vs ').title()
            # Hora: tentar extrair "Live Now!" ou "Starts in: Xh"
            # A página usa "Live Now!" inline — marcamos
            live_flag = 'Live Now!' in html[:html.find(slug) + 200] if slug in html else False
            time_str = '🔴 LIVE' if live_flag else ''
            events.append({
                'title':   title,
                'time':    time_str,
                'icon':    '',
                'streams': [{
                    'source':   NAME,
                    'url':      url_ev,
                    'label':    '★ StreamEast',
                    'hd':       True,
                    'language': 'EN',
                    'star':     True,
                    'is_page':  True,
                    'base':     base,
                    'icon':     '',
                }],
                'source_name': NAME,
            })
        return events

    events = []
    seen = set()
    for url_ev, slug, team1, team2 in events_raw:
        if slug in seen: continue
        seen.add(slug)
        title = '{} vs {}'.format(utils.cleantext(team1), utils.cleantext(team2)) if team1 and team2 else slug.replace('-', ' ').title()
        events.append({
            'title':   title,
            'time':    '',
            'icon':    '',
            'streams': [{
                'source':   NAME,
                'url':      url_ev,
                'label':    '★ StreamEast',
                'hd':       True,
                'language': 'EN',
                'star':     True,
                'is_page':  True,
                'base':     base,
                'icon':     '',
            }],
            'source_name': NAME,
        })
    return events


def get_streams_from_page(event_url, base):
    """
    Página do evento — extrair iframes de stream.
    """
    html = utils.getHtml(event_url, referer=base + '/')
    if not html:
        return []

    streams = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for i, src in enumerate(iframes, 1):
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else (base + '/' + src.lstrip('/'))
        if any(x in src for x in ['ads', 'google', 'facebook']): continue
        streams.append({
            'source':   '★ StreamEast — Stream {}'.format(i),
            'url':      src,
            'label':    '★ StreamEast — Stream {}'.format(i),
            'hd':       True,
            'language': 'EN',
            'star':     True,
        })

    # Também procurar links de stream externos na página
    if not streams:
        links = re.findall(r'href=["\']([^"\']+)["\'][^>]*>\s*(?:Stream|Watch|Link)\s*\d*', html, re.I)
        for i, u in enumerate(links, 1):
            if u.startswith('http') and base not in u:
                streams.append({
                    'source':   '★ StreamEast — Link {}'.format(i),
                    'url':      u,
                    'label':    '★ StreamEast — Link {}'.format(i),
                    'hd':       True,
                    'language': 'EN',
                    'star':     True,
                })

    return streams
