# -*- coding: utf-8 -*-
"""
★ VIPRow — viprow.co
Muitas categorias de desporto. Estrutura verificada:
  /sports-football-online → lista de jogos (links /league/match-online-stream)
  Página do jogo → iframe/stream
"""
import re
from resources.lib import utils

NAME = '★ VIPRow'
STAR = True
BASE = 'https://www.viprow.co'

SPORT_URL = {
    'football':          BASE + '/sports-football-online',
    'basketball':        BASE + '/sports-basketball-online',
    'american-football': BASE + '/sports-american-football-online',
    'hockey':            BASE + '/sports-ice-hockey-online',
    'fight':             BASE + '/sports-ufc-online',
    'tennis':            BASE + '/sports-tennis-online',
    'motor-sports':      BASE + '/sports-formula-1-online',
    'golf':              BASE + '/sports-golf-online',
    'rugby':             BASE + '/sports-rugby-online',
    'cricket':           'https://cricwatch.io',
    'baseball':          'https://mlbstreams.me',
    'afl':               BASE + '/sports-aussie-rules-online',
    'darts':             BASE + '/sports-darts-online',
    'other':             BASE + '/sports-others-online',
}


def get_matches(sport_hub_id):
    url = SPORT_URL.get(sport_hub_id)
    if not url:
        return []

    base_url = '/'.join(url.split('/')[:3])
    html = utils.getHtml(url, referer=base_url + '/')
    if not html:
        return []

    # Padrão verificado: href="/league/match-name-online-stream" ou time stamps
    # Formato: [HORA MATCH_NAME](link) onde hora é "HH:MM" e link é dentro de viprow.co
    matches = re.findall(
        r'(\d{1,2}:\d{2})\s+'  # hora
        r'<a href=["\'](' + re.escape(base_url) + r'/[^"\']+)["\']>([^<]{5,80})</a>',
        html
    )

    # Fallback: todos os links de eventos
    if not matches:
        all_links = re.findall(
            r'(\d{1,2}:\d{2})?\s*'
            r'<a href=["\'](' + re.escape(base_url) + r'/([^/]+/[^"\']+-online-stream))["\']>([^<]{5,80})</a>',
            html
        )
        events = []
        seen = set()
        for hora, url_ev, slug, title in all_links:
            title = utils.cleantext(title)
            if not title or url_ev in seen or len(title) < 5: continue
            if any(x in url_ev for x in ['sports-', 'privacy', 'dmca', 'news']): continue
            seen.add(url_ev)
            events.append({
                'title':   title,
                'time':    hora or '',
                'icon':    '',
                'streams': [{
                    'source':   NAME,
                    'url':      url_ev,
                    'label':    '★ VIPRow',
                    'hd':       True,
                    'language': 'EN',
                    'star':     True,
                    'is_page':  True,
                    'base':     base_url,
                    'icon':     '',
                }],
                'source_name': NAME,
            })
        return events

    events = []
    seen = set()
    for hora, url_ev, title in matches:
        title = utils.cleantext(title)
        if not title or url_ev in seen: continue
        seen.add(url_ev)
        events.append({
            'title':   title,
            'time':    hora,
            'icon':    '',
            'streams': [{
                'source':   NAME,
                'url':      url_ev,
                'label':    '★ VIPRow',
                'hd':       True,
                'language': 'EN',
                'star':     True,
                'is_page':  True,
                'base':     base_url,
                'icon':     '',
            }],
            'source_name': NAME,
        })
    return events


def get_streams_from_page(event_url, base_url=BASE):
    """
    VIPRow carrega o stream via iframe ou JS redirect.
    """
    html = utils.getHtml(event_url, referer=base_url + '/')
    if not html:
        return []

    streams = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for i, src in enumerate(iframes, 1):
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else (base_url + '/' + src.lstrip('/'))
        if any(x in src for x in ['ads', 'google', 'facebook', 'amazon']): continue
        streams.append({
            'source':   '★ VIPRow — Stream {}'.format(i),
            'url':      src,
            'label':    '★ VIPRow — Stream {}'.format(i),
            'hd':       True,
            'language': 'EN',
            'star':     True,
        })

    if not streams:
        m3u8s = re.findall(r'(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)', html)
        for i, u in enumerate(m3u8s, 1):
            streams.append({
                'source':   '★ VIPRow — M3U8 {}'.format(i),
                'url':      u,
                'label':    '★ VIPRow — M3U8 {}'.format(i),
                'hd':       True,
                'language': 'EN',
                'star':     True,
            })

    return streams
