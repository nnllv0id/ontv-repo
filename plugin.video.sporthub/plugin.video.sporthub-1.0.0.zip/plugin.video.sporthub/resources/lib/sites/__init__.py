# -*- coding: utf-8 -*-
"""
Auto-import de todos os módulos de sites.
Equivalente ao 'from resources.lib.sites import *' do Cumination.
"""
from resources.lib.sites import (
    daddylive,
    streameast,
    crackstreams,
    sportshd,
    livetv,
    sportsbay,
)
