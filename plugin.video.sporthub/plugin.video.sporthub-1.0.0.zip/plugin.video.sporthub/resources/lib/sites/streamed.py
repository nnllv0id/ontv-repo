# -*- coding: utf-8 -*-
"""
★ Streamed — streamed.su / streamed.pk / streamed.st
API REST completa e pública.
Endpoints:
  GET /api/sports                → [{id, name}]
  GET /api/matches/{sport}       → [match...]
  GET /api/matches/live          → partidas live
  GET /api/stream/{source}/{id}  → [{embedUrl, language, hd, ...}]
  Imagem: /api/images/badge/{id}
"""
import xbmc
from resources.lib import utils

NAME   = '★ Streamed'
STAR   = True
BASES  = ['https://streamed.su', 'https://streamed.pk', 'https://streamed.st']
SOURCES_ORDER = ['alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel','intel']

# Mapa sport_id SportHub → sport_id Streamed
SPORT_MAP = {
    'football':          'football',
    'basketball':        'basketball',
    'american-football': 'american-football',
    'hockey':            'hockey',
    'baseball':          'baseball',
    'motor-sports':      'motor-sports',
    'fight':             'fight',
    'tennis':            'tennis',
    'rugby':             'rugby',
    'golf':              'golf',
    'cricket':           'cricket',
    'darts':             'darts',
    'afl':               'afl',
    'other':             'other',
}

_cached_base = None


def base():
    global _cached_base
    if _cached_base:
        return _cached_base
    for b in BASES:
        d = utils.getJson(b + '/api/sports', referer=b + '/', timeout=8)
        if d and isinstance(d, list) and len(d) > 0:
            _cached_base = b
            return b
    _cached_base = BASES[0]
    return _cached_base


def get_matches(sport_hub_id):
    sport_id = SPORT_MAP.get(sport_hub_id, sport_hub_id)
    b = base()
    data = utils.getJson('{}/api/matches/{}'.format(b, sport_id),
                         referer=b + '/',
                         headers={'Origin': b})
    if not data or not isinstance(data, list):
        return []
    events = []
    for match in data:
        title   = match.get('title', '?')
        date_ms = match.get('date', 0)
        sources = match.get('sources', [])
        poster  = match.get('poster', '')
        teams   = match.get('teams', {})

        if not sources:
            continue

        icon = ICON_BASE(b, poster, teams)
        time_str = _ts(date_ms)

        streams = []
        for src in sources:
            s_name = src.get('source', '')
            s_id   = src.get('id', '')
            if not s_name or not s_id:
                continue
            streams.append({
                'source':   '★ Streamed/{}'.format(s_name.upper()),
                'url':      '{}/api/stream/{}/{}'.format(b, s_name, s_id),
                'label':    '★ Streamed — {}'.format(s_name.upper()),
                'hd':       True,
                'language': 'EN/Multi',
                'star':     True,
                'is_api':   True,
                'base':     b,
                'icon':     icon,
            })

        events.append({
            'title':   title,
            'time':    time_str,
            'icon':    icon,
            'streams': streams,
            'source_name': NAME,
        })
    return events


def resolve_api_stream(api_url, base_url):
    """
    Chama GET /api/stream/{source}/{id} → [{embedUrl,...}]
    Depois resolve cada embedUrl para m3u8.
    """
    from resources.lib.resolver import resolve_stream
    streams_data = utils.getJson(api_url, referer=base_url + '/',
                                  headers={'Origin': base_url})
    if not streams_data:
        return None
    for sd in (streams_data if isinstance(streams_data, list) else []):
        embed_url = sd.get('embedUrl', '')
        if not embed_url:
            continue
        stream, _ = resolve_stream(embed_url, referer=base_url + '/')
        if stream:
            return stream
    return None


def ICON_BASE(b, poster, teams):
    if poster:
        return '{}/api/images/badge/{}'.format(b, poster)
    home = (teams or {}).get('home', {}) or {}
    if home.get('badge'):
        return '{}/api/images/badge/{}'.format(b, home['badge'])
    return ''


def _ts(ms):
    if not ms: return ''
    try:
        import datetime
        dt = datetime.datetime.utcfromtimestamp(ms / 1000)
        return dt.strftime('%H:%M')
    except Exception:
        return ''
