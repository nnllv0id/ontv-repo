# -*- coding: utf-8 -*-
"""
★ Streamed — streamed.me / streamed.gg / streamed.at
API REST pública.
NOTA: streamed.su expirou em 10/03/2026. Novos domínios activos.
Endpoints:
  GET /api/sports                → [{id, name}]
  GET /api/matches/{sport}       → [match...]
  GET /api/stream/{source}/{id}  → [{embedUrl, language, hd, ...}]
  Imagem: /api/images/badge/{id}  — o campo poster já inclui o path completo
"""
import xbmc
from resources.lib import utils

NAME   = '★ Streamed'
STAR   = True
# streamed.su EXPIROU 10/03/2026 — novos mirrors por ordem de preferência
BASES  = [
    'https://streamed.me',
    'https://streamed.gg',
    'https://streamed.at',
    'https://streamed.pk',   # último recurso
    'https://streamed.st',
]
SOURCES_ORDER = ['alpha','bravo','charlie','delta','echo','foxtrot','golf','hotel','intel']

SPORT_MAP = {
    'football':          'football',
    'basketball':        'basketball',
    'american-football': 'american-football',
    'hockey':            'hockey',
    'baseball':          'baseball',
    'motor-sports':      'motor-sports',
    'fight':             'fight',
    'tennis':            'tennis',
    'rugby':             'rugby',
    'golf':              'golf',
    'cricket':           'cricket',
    'darts':             'darts',
    'afl':               'afl',
    'other':             'other',
}

_cached_base = None


def base():
    global _cached_base
    if _cached_base:
        return _cached_base
    for b in BASES:
        try:
            d = utils.getJson(b + '/api/sports', referer=b + '/', timeout=8)
            if d and isinstance(d, list) and len(d) > 0:
                _cached_base = b
                xbmc.log('[SportHub/Streamed] base activa: ' + b, xbmc.LOGINFO)
                return b
        except Exception:
            pass
    # fallback silencioso
    _cached_base = BASES[0]
    return _cached_base


def get_matches(sport_hub_id):
    sport_id = SPORT_MAP.get(sport_hub_id, sport_hub_id)
    b = base()
    data = utils.getJson('{}/api/matches/{}'.format(b, sport_id),
                         referer=b + '/',
                         headers={'Origin': b})
    if not data or not isinstance(data, list):
        return []
    events = []
    for match in data:
        title   = match.get('title', '?')
        date_ms = match.get('date', 0)
        sources = match.get('sources', [])
        poster  = match.get('poster', '')
        teams   = match.get('teams', {})

        if not sources:
            continue

        icon = _icon_url(b, poster, teams)
        time_str = _ts(date_ms)

        streams = []
        for src in sources:
            s_name = src.get('source', '')
            s_id   = src.get('id', '')
            if not s_name or not s_id:
                continue
            streams.append({
                'source':   '★ Streamed/{}'.format(s_name.upper()),
                'url':      '{}/api/stream/{}/{}'.format(b, s_name, s_id),
                'label':    '★ Streamed — {}'.format(s_name.upper()),
                'hd':       True,
                'language': 'EN/Multi',
                'star':     True,
                'is_api':   True,
                'base':     b,
                'icon':     icon,
            })

        events.append({
            'title':       title,
            'time':        time_str,
            'icon':        icon,
            'streams':     streams,
            'source_name': NAME,
        })
    return events


def resolve_api_stream(api_url, base_url):
    """GET /api/stream/{source}/{id} → [{embedUrl,...}] → resolve para m3u8."""
    from resources.lib.resolver import resolve_stream
    streams_data = utils.getJson(api_url, referer=base_url + '/',
                                  headers={'Origin': base_url})
    if not streams_data:
        return None
    for sd in (streams_data if isinstance(streams_data, list) else []):
        embed_url = sd.get('embedUrl', '')
        if not embed_url:
            continue
        stream, _ = resolve_stream(embed_url, referer=base_url + '/')
        if stream:
            return stream
    return None


def _icon_url(b, poster, teams):
    """
    CORRECÇÃO: a API Streamed passou a devolver poster como path completo
    ex: "/api/images/proxy/GwZg7..." em vez de só "badge_id"
    Temos de detectar se já é um path e não duplicar o prefixo.
    """
    if poster:
        if poster.startswith('http'):
            return poster
        if poster.startswith('/'):
            # já é path completo — juntar apenas o base
            return b + poster
        # legacy: só o ID do badge
        return '{}/api/images/badge/{}'.format(b, poster)
    home = (teams or {}).get('home', {}) or {}
    badge = home.get('badge', '')
    if badge:
        if badge.startswith('http'):
            return badge
        if badge.startswith('/'):
            return b + badge
        return '{}/api/images/badge/{}'.format(b, badge)
    return ''


def _ts(ms):
    if not ms:
        return ''
    try:
        import datetime
        dt = datetime.datetime.utcfromtimestamp(ms / 1000)
        return dt.strftime('%H:%M')
    except Exception:
        return ''
