# -*- coding: utf-8 -*-
"""
SportHub — CrackStreams
Site: https://crackstreams.io  / variantes
Eventos: UFC, Boxing, NBA, NFL, MLB, NHL, MMA, Soccer, Wrestling
"""
import re
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'crackstreams',
    '[COLOR orange]CrackStreams[/COLOR]',
    'https://crackstreams.io/',
    'crackstreams.png',
    about='CrackStreams — UFC, Boxing, NBA, NFL, MMA e mais'
)

BASE = 'https://crackstreams.io'

SPORTS = [
    ('🥊 UFC / MMA',  BASE + '/ufc-streams'),
    ('🥊 Boxing',      BASE + '/boxing-streams'),
    ('🏀 NBA',         BASE + '/nba-streams'),
    ('🏈 NFL',         BASE + '/nfl-streams'),
    ('⚾ MLB',         BASE + '/mlb-streams'),
    ('🏒 NHL',         BASE + '/nhl-streams'),
    ('⚽ Soccer',      BASE + '/soccer-streams'),
    ('🤼 Wrestling',   BASE + '/wwe-streams'),
    ('🏉 Rugby',       BASE + '/rugby-streams'),
    ('🎾 Tennis',      BASE + '/tennis-streams'),
    ('🏎️ F1',          BASE + '/f1-streams'),
]


@site.register(default_mode=True)
def Main():
    for nome, url in SPORTS:
        site.add_dir(nome, url, 'List', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.eod()
        return
    if not html:
        utils.eod()
        return

    matches = re.findall(
        r'<a\s+href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*event[^"\']*["\'][^>]*>([^<]+)',
        html, re.IGNORECASE
    )
    if not matches:
        # Fallback genérico
        matches = re.findall(
            r'href=["\']([^"\']+streams[^"\']*)["\'][^>]*>\s*([A-Z][^<]{4,50})',
            html, re.IGNORECASE
        )

    seen = set()
    for path, nome in matches:
        nome = utils.cleantext(nome)
        if not nome or nome in seen:
            continue
        full = path if path.startswith('http') else BASE + path
        seen.add(nome)
        site.add_dir(nome, full, 'Streams', site.img_live)

    if not seen:
        utils.notify('Sem eventos. O domínio pode ter mudado.')
    utils.eod()


@site.register()
def Streams(url):
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.eod()
        return

    # Procurar links de stream na página
    streams = re.findall(
        r'href=["\']([^"\']+)["\'][^>]*>\s*(?:Stream|Watch|Link|Source)\s*(\d*)',
        html, re.IGNORECASE
    )
    if not streams:
        # iframe fallback
        iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        for i, iframe in enumerate(iframes, start=1):
            if not iframe.startswith('http'):
                iframe = BASE + iframe
            site.add_download_link('Stream {}'.format(i), iframe, 'Playvid', site.img_live)
    else:
        for stream_url, num in streams:
            if not stream_url.startswith('http'):
                stream_url = BASE + stream_url
            site.add_download_link('Stream {}'.format(num or '1'), stream_url, 'Playvid', site.img_live)

    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(url, referer=BASE + '/')
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido.')
        import xbmcplugin, xbmcgui, sys
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
