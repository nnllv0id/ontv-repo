# -*- coding: utf-8 -*-
"""
CrackStreams / BuffStream — crackstreams.io → ms.buffstream.io
Mirrors: crackstreams.ms, crackstreams.blog
"""
import re
from resources.lib import utils

NAME  = 'CrackStreams'
STAR  = False
BASES = ['https://crackstreams.io', 'https://crackstreams.ms']
BUFF  = 'https://ms.buffstream.io'

SPORT_URLS = {
    'basketball':        '/nba-regular-16',
    'american-football': '/nfl-streams50',
    'hockey':            '/nhl-streams44',
    'baseball':          '/mlb-streams37',
    'fight':             '/mma-streams40',
}


def _base():
    for b in BASES:
        html = utils.getHtml(b + '/index-v73', timeout=7)
        if html and len(html) > 500:
            return b
    return BASES[0]


def get_matches(sport_hub_id):
    path = SPORT_URLS.get(sport_hub_id)
    if not path:
        return []

    b    = _base()
    url  = b + path
    html = utils.getHtml(url, referer=b + '/')
    if not html:
        return []

    raw = re.findall(
        r'####\s+(.+?)\n([\d]{4}-[\d]{2}-[\d]{2}[^\]]*)\]\((https?://[^\)]+)\)',
        html, re.IGNORECASE
    )

    events = []
    seen = set()
    for nome, data_hora, stream_url in raw:
        nome = utils.cleantext(nome)
        nome = re.sub(r'\s+vs\s+(?:Watch|Stream|Replay|Live|Online|Broadcast|HD|Free|Schedule).*$', '', nome, flags=re.I).strip()
        nome = re.sub(r'\s+CH\d+$', '', nome).strip()
        if not nome or nome in seen:
            continue
        seen.add(nome)
        events.append({
            'title':   nome,
            'time':    data_hora.strip()[:16],
            'icon':    '',
            'streams': [{
                'source':   NAME,
                'url':      stream_url,
                'label':    'CrackStreams',
                'hd':       True,
                'language': 'EN',
                'star':     False,
                'is_page':  True,
                'base':     b,
                'icon':     '',
            }],
            'source_name': NAME,
        })
    return events


def get_streams_from_page(event_url, base_url=None):
    """Página buffstream → iframes."""
    b = base_url or BUFF
    html = utils.getHtml(event_url, referer=(base_url or 'https://crackstreams.io') + '/')
    if not html:
        return []

    streams = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for i, src in enumerate(iframes, 1):
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else BUFF + '/' + src.lstrip('/')
        streams.append({
            'source':   'CrackStreams — Stream {}'.format(i),
            'url':      src,
            'label':    'CrackStreams — Stream {}'.format(i),
            'hd':       True,
            'language': 'EN',
            'star':     False,
        })
    return streams
