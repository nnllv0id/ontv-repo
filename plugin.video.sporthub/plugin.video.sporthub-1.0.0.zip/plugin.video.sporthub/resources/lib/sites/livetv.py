# -*- coding: utf-8 -*-
"""
SportHub — LiveTV.sx
Site: https://livetv.sx  (também .me / .cc)
Arquivo completo de desporto ao vivo + replays
"""
import re
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'livetv',
    '[COLOR cyan]LiveTV[/COLOR]',
    'https://livetv.sx/enx/',
    'livetv.png',
    about='LiveTV.sx — desporto ao vivo e replays de todo o mundo'
)

BASES = ['https://livetv.sx', 'https://livetv.me', 'https://livetv.cc']
BASE  = BASES[0]
LANG  = '/enx'

SPORTS = [
    ('⚽ Football',   '/allupcoming/'),
    ('🏀 Basketball', '/cat/2/'),
    ('🎾 Tennis',     '/cat/3/'),
    ('🏒 Ice Hockey', '/cat/4/'),
    ('🏈 American Football', '/cat/14/'),
    ('⚾ Baseball',   '/cat/15/'),
    ('🏉 Rugby',      '/cat/21/'),
    ('🏎️ Formula 1',  '/cat/28/'),
    ('🥊 Boxing / MMA', '/cat/5/'),
    ('🏌️ Golf',       '/cat/17/'),
    ('🎿 Winter Sports', '/cat/30/'),
]


@site.register(default_mode=True)
def Main():
    for nome, path in SPORTS:
        site.add_dir(nome, BASE + LANG + path, 'List', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    try:
        html = utils.getHtml(url, referer=BASE + LANG + '/')
    except Exception:
        utils.eod()
        return
    if not html:
        utils.eod()
        return

    # Padrão de eventos: <td class="livecell"><a href="...">Nome</a>
    matches = re.findall(
        r'<td[^>]+class=["\'][^"\']*(?:livecell|event|match)[^"\']*["\'][^>]*>'
        r'\s*<a\s+href=["\']([^"\']+)["\'][^>]*>([^<]+)',
        html, re.IGNORECASE | re.DOTALL
    )
    if not matches:
        # Fallback genérico
        matches = re.findall(
            r'<a\s+href=["\'](/enx/event/[^"\']+)["\'][^>]*>([^<]{5,60})',
            html, re.IGNORECASE
        )

    seen = set()
    for path, nome in matches:
        nome = utils.cleantext(nome)
        if not nome or nome in seen or len(nome) < 3:
            continue
        full = path if path.startswith('http') else BASE + path
        seen.add(nome)
        site.add_dir(nome, full, 'Streams', site.img_live)

    if not seen:
        utils.notify('Sem eventos encontrados em LiveTV.')
    utils.eod()


@site.register()
def Streams(url):
    try:
        html = utils.getHtml(url, referer=BASE + LANG + '/')
    except Exception:
        utils.eod()
        return
    if not html:
        utils.eod()
        return

    # Iframe players
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
    added = 0
    for i, iframe in enumerate(iframes, start=1):
        if not iframe.startswith('http'):
            iframe = BASE + iframe
        site.add_download_link('Stream {}'.format(i), iframe, 'Playvid',
                               site.img_live, desc='Stream {}'.format(i))
        added += 1

    if not added:
        # Links diretos
        links = re.findall(r'href=["\']([^"\']+\.m3u8[^"\']*)["\']', html, re.IGNORECASE)
        for i, lnk in enumerate(links, start=1):
            site.add_download_link('Stream {}'.format(i), lnk, 'Playvid', site.img_live)
            added += 1

    if not added:
        utils.notify('Streams não encontrados.')
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(url, referer=BASE + '/')
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido.')
        import xbmcplugin, xbmcgui, sys
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
