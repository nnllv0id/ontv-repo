# -*- coding: utf-8 -*-
"""
★ DaddyLive — dlhd.sx / dlhd.link (mirrors activos Março 2026)
Schedule: /schedule/schedule-generated.json  ← URL mudou!
Canais 24/7: /24-7-channels.php
Players: /stream/stream-{id}.php, /cast/, /watch/, /plus/, /casting/, /player/

logo_url no schedule pode ser:
  - path relativo: "logos/espn.png"  → base + "/" + logo_url
  - URL absoluta:  "https://..."     → usar directamente
"""
import re
from resources.lib import utils

NAME    = '★ DaddyLive'
STAR    = True

# Mirrors activos em Março 2026 — dlstreams.top ficou com 404 no schedule
MIRRORS = [
    'https://dlhd.sx',
    'https://dlhd.link',
    'https://daddyhd.com',
    'https://dlstreams.top',   # fallback (pode ter mudado endpoint)
    'https://daddylive.mp',
]

# Endpoints do schedule a tentar por ordem
SCHEDULE_PATHS = [
    '/schedule/schedule-generated.json',
    '/schedule/schedule.json',
]

FOLDERS = ['stream', 'cast', 'watch', 'plus', 'casting', 'player']

SPORT_CATS = {
    'football':          ['Football', 'Soccer', 'Premier', 'Champions', 'Liga', 'Serie', 'Bundesliga', 'MLS'],
    'basketball':        ['Basketball', 'NBA'],
    'american-football': ['NFL', 'American Football', 'NCAAF'],
    'hockey':            ['Hockey', 'NHL'],
    'baseball':          ['Baseball', 'MLB'],
    'fight':             ['Boxing', 'UFC', 'MMA', 'Wrestling', 'Combat', 'AEW', 'WWE'],
    'motor-sports':      ['Formula', 'F1', 'MotoGP', 'NASCAR', 'Motor', 'Motorsport'],
    'tennis':            ['Tennis'],
    'rugby':             ['Rugby'],
    'cricket':           ['Cricket'],
    'golf':              ['Golf'],
    'other':             [],
}

_cache_base     = None
_cache_schedule = None   # (base, path) que funcionou


def _base():
    global _cache_base
    if _cache_base:
        return _cache_base
    for b in MIRRORS:
        html = utils.getHtml(b + '/', timeout=8)
        if html and len(html) > 200:
            _cache_base = b
            return b
    _cache_base = MIRRORS[0]
    return _cache_base


def _get_schedule():
    """Tenta todos os mirrors × paths até encontrar um schedule válido."""
    global _cache_schedule
    for b in MIRRORS:
        for path in SCHEDULE_PATHS:
            try:
                data = utils.getJson(b + path, referer=b + '/', timeout=10)
                if data and isinstance(data, dict) and len(data) > 0:
                    _cache_schedule = (b, path)
                    return b, data
            except Exception:
                pass
    return _base(), {}


def get_matches(sport_hub_id):
    import datetime
    b, data = _get_schedule()
    if not data:
        return []

    today = datetime.datetime.now().strftime('%d/%m/%Y')
    day_data = data.get(today, {})
    if not day_data and data:
        # usar o primeiro dia disponível
        day_data = data[sorted(data.keys())[0]]

    keywords = SPORT_CATS.get(sport_hub_id, [])
    events   = []

    for categoria, evs in day_data.items():
        if not isinstance(evs, list):
            continue
        cat_lower = categoria.lower()
        match_cat = (not keywords) or any(kw.lower() in cat_lower for kw in keywords)
        if not match_cat and sport_hub_id != 'other':
            continue

        for ev in evs:
            nome   = ev.get('event', '?')
            hora   = ev.get('time', '')
            canais = ev.get('channels', [])
            if not canais:
                continue

            c0   = canais[0]
            icon = _logo(b, c0.get('logo_url', ''), c0.get('channel_name', ''))

            streams = []
            for ci, canal in enumerate(canais, 1):
                cid = str(canal.get('channel_id', ''))
                if not cid:
                    continue
                c_icon = _logo(b, canal.get('logo_url', ''), canal.get('channel_name', ''))
                for pnum, folder in enumerate(FOLDERS, 1):
                    streams.append({
                        'source':   '★ DaddyLive — C{}/P{}'.format(ci, pnum),
                        'url':      '{}/{}/stream-{}.php'.format(b, folder, cid),
                        'label':    '★ DaddyLive — Canal {} Player {}'.format(ci, pnum),
                        'hd':       True,
                        'language': 'Multi',
                        'star':     True,
                        'is_page':  True,
                        'base':     b,
                        'icon':     c_icon or icon,
                    })

            events.append({
                'title':       nome,
                'time':        hora,
                'icon':        icon,
                'streams':     streams,
                'source_name': NAME,
            })
    return events


def get_channels_247():
    b    = _base()
    html = utils.getHtml(b + '/24-7-channels.php', referer=b + '/')
    if not html:
        return []
    # Padrão novo: href="/watch.php?id=35" ou href="watch.php?id=35"
    matches = re.findall(
        r'href=["\'](?:[^"\']*?)/watch\.php\?id=(\d+)["\'][^>]*>\s*([^\n<]{2,60})',
        html, re.IGNORECASE
    )
    seen = set()
    result = []
    for cid, nome in matches:
        nome = utils.cleantext(nome)
        if nome and cid not in seen and len(nome) > 1:
            seen.add(cid)
            result.append((nome, cid))
    return sorted(result, key=lambda x: x[0].lower())


def get_players(channel_id):
    b = _base()
    return [
        {
            'label': '★ DaddyLive — Player {} ({})'.format(i, folder),
            'url':   '{}/{}/stream-{}.php'.format(b, folder, channel_id),
            'star':  True,
        }
        for i, folder in enumerate(FOLDERS, 1)
    ]


def _logo(base_url, logo_url, channel_name=''):
    """Constrói URL do logo tratando paths relativos e absolutos."""
    if not logo_url:
        # fallback: slug do nome
        slug = re.sub(r'[^a-z0-9]', '_', channel_name.lower()).strip('_')
        return '{}/logos/{}.png'.format(base_url, slug) if slug else ''
    if logo_url.startswith('http'):
        return logo_url
    # path relativo: "logos/espn.png"
    logo_url = logo_url.lstrip('/')
    return '{}/{}'.format(base_url, logo_url)
