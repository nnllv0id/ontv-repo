# -*- coding: utf-8 -*-
"""
★ DaddyLive — dlstreams.top (mirrors: daddylive.cv, daddylive.top, daddylives.nl)
API schedule: /schedule/schedule.json
Canais 24/7: /24-7-channels.php
6 players por canal: /stream/stream-{id}.php, /cast/stream-{id}.php, ...
"""
import re, json
from resources.lib import utils

NAME    = '★ DaddyLive'
STAR    = True
MIRRORS = [
    'https://dlstreams.top',
    'https://daddylive.cv',
    'https://daddylive.top',
    'https://daddylives.nl',
]
FOLDERS = ['stream', 'cast', 'watch', 'plus', 'casting', 'player']

SPORT_CATS = {
    'football':          ['Football', 'Soccer', 'Premier', 'Champions', 'Liga', 'Serie', 'Bundesliga', 'MLS'],
    'basketball':        ['Basketball', 'NBA'],
    'american-football': ['NFL', 'American Football', 'NCAAF'],
    'hockey':            ['Hockey', 'NHL'],
    'baseball':          ['Baseball', 'MLB'],
    'fight':             ['Boxing', 'UFC', 'MMA', 'Wrestling', 'Combat', 'AEW', 'WWE'],
    'motor-sports':      ['Formula', 'F1', 'MotoGP', 'NASCAR', 'Motor', 'Motorsport'],
    'tennis':            ['Tennis'],
    'rugby':             ['Rugby'],
    'cricket':           ['Cricket'],
    'golf':              ['Golf'],
    'other':             [],
}

_cache_base = None


def _base():
    global _cache_base
    if _cache_base:
        return _cache_base
    for b in MIRRORS:
        html = utils.getHtml(b + '/', timeout=7)
        if html and len(html) > 200:
            _cache_base = b
            return b
    _cache_base = MIRRORS[0]
    return _cache_base


def get_matches(sport_hub_id):
    import datetime
    b         = _base()
    data      = utils.getJson(b + '/schedule/schedule.json', referer=b + '/')
    if not data:
        return []

    today = datetime.datetime.now().strftime('%d/%m/%Y')
    day_data = data.get(today, {})
    if not day_data and data:
        day_data = data[sorted(data.keys())[0]]

    keywords = SPORT_CATS.get(sport_hub_id, [])
    events   = []

    for categoria, evs in day_data.items():
        if not isinstance(evs, list):
            continue
        cat_lower = categoria.lower()
        match_cat = (not keywords) or any(kw.lower() in cat_lower for kw in keywords)
        if not match_cat and sport_hub_id != 'other':
            continue

        for ev in evs:
            nome   = ev.get('event', '?')
            hora   = ev.get('time', '')
            canais = ev.get('channels', [])
            if not canais:
                continue

            c0   = canais[0]
            slug = c0.get('channel_name', '').lower().replace(' ', '_')
            icon = b + '/assets/logos/{}.png'.format(slug)

            # Gerar todos os players para todos os canais do evento
            streams = []
            for ci, canal in enumerate(canais, 1):
                cid = str(canal.get('channel_id', ''))
                if not cid:
                    continue
                for pnum, folder in enumerate(FOLDERS, 1):
                    streams.append({
                        'source':   '★ DaddyLive — Canal {} / P{}'.format(ci, pnum),
                        'url':      '{}/{}/stream-{}.php'.format(b, folder, cid),
                        'label':    '★ DaddyLive — Canal {} Player {}'.format(ci, pnum),
                        'hd':       True,
                        'language': 'Multi',
                        'star':     True,
                        'is_page':  True,
                        'base':     b,
                        'icon':     icon,
                    })

            events.append({
                'title':   nome,
                'time':    hora,
                'icon':    icon,
                'streams': streams,
                'source_name': NAME,
            })
    return events


def get_channels_247():
    b    = _base()
    html = utils.getHtml(b + '/24-7-channels.php', referer=b + '/')
    if not html:
        return []
    matches = re.findall(
        r'href=["\'](?:[^"\']*)?/watch\.php\?id=(\d+)["\'][^>]*>\s*([^\n<]{2,60})',
        html, re.IGNORECASE
    )
    seen = set()
    result = []
    for cid, nome in matches:
        nome = utils.cleantext(nome)
        if nome and cid not in seen and len(nome) > 1:
            seen.add(cid)
            result.append((nome, cid))
    return sorted(result, key=lambda x: x[0].lower())


def get_players(channel_id):
    b = _base()
    return [
        {
            'label': '★ DaddyLive — Player {} ({})'.format(i, folder),
            'url':   '{}/{}/stream-{}.php'.format(b, folder, channel_id),
            'star':  True,
        }
        for i, folder in enumerate(FOLDERS, 1)
    ]
