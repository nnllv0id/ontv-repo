# -*- coding: utf-8 -*-
"""
SportHub — DaddyLive
Site: https://dlstreams.top
24/7 Live TV + schedule de eventos desportivos
"""
import re
import json
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'daddylive',
    '[COLOR dodgerblue]DaddyLive[/COLOR]',
    'https://dlstreams.top/',
    'daddylive.png',
    about='DaddyLive — +1000 canais 24/7 e eventos ao vivo'
)

BASE   = 'https://dlstreams.top'
STREAM = BASE + '/stream/stream-{}.php'
ALT    = ['stream', 'cast', 'watch', 'plus', 'casting', 'player']


# ─── Canais 24/7 (lista local para velocidade) ────────────────────────────────
CANAIS_247 = [
    # (Nome, ID, Categoria)
    ('Sky Sports Football UK', 35, 'Sky Sports UK'),
    ('Sky Sports Main Event',  38, 'Sky Sports UK'),
    ('Sky Sports Action UK',   37, 'Sky Sports UK'),
    ('Sky Sports F1 UK',       60, 'Sky Sports UK'),
    ('Sky Sports Cricket',     65, 'Sky Sports UK'),
    ('Sky Sports Golf UK',     70, 'Sky Sports UK'),
    ('TNT Sports 1 UK',        31, 'TNT Sports UK'),
    ('TNT Sports 2 UK',        32, 'TNT Sports UK'),
    ('TNT Sports 3 UK',        33, 'TNT Sports UK'),
    ('TNT Sports 4 UK',        34, 'TNT Sports UK'),
    ('Sport TV1 Portugal',     49, 'Sport TV PT'),
    ('Sport TV2 Portugal',     74, 'Sport TV PT'),
    ('Sport TV3 Portugal',    454, 'Sport TV PT'),
    ('Sport TV4 Portugal',    289, 'Sport TV PT'),
    ('Sport TV5 Portugal',    290, 'Sport TV PT'),
    ('Eleven Sports 1 PT',    455, 'Eleven Sports PT'),
    ('Eleven Sports 2 PT',    456, 'Eleven Sports PT'),
    ('Eleven Sports 3 PT',    457, 'Eleven Sports PT'),
    ('ESPN USA',               44, 'ESPN'),
    ('ESPN2 USA',              45, 'ESPN'),
    ('Fox Sports 1 USA',       39, 'Fox Sports USA'),
    ('beIN Sports 1 France',  116, 'beIN Sports'),
    ('beIN Sports 2 France',  117, 'beIN Sports'),
    ('beIN Sports MENA Eng 1', 61, 'beIN Sports'),
    ('Canal+ Sport France',   122, 'Canal+'),
    ('Canal+ Sport Poland',    48, 'Canal+'),
    ('DAZN 1 Spain',          445, 'DAZN'),
    ('DAZN 2 Spain',          446, 'DAZN'),
    ('DAZN LaLiga',           538, 'DAZN'),
    ('Eurosport 1 Greece',     41, 'Eurosport'),
    ('Eurosport 2 Greece',     42, 'Eurosport'),
    ('Sky Sport MAX Italy',   460, 'Sky Sport Italy'),
    ('Sky Sport Calcio Italy',870, 'Sky Sport Italy'),
    ('Sky Sport Bundesliga 1',558, 'Sky Sport DE'),
    ('Movistar LaLiga',        84, 'Movistar Spain'),
    ('SporTV Brasil',          78, 'Brasil'),
    ('SporTV2 Brasil',         79, 'Brasil'),
    ('ESPN Brasil',            81, 'Brasil'),
    ('SuperSport Premier League', 414, 'SuperSport'),
    ('SuperSport Football',    56, 'SuperSport'),
    ('Nova Sports 1 Greece',  631, 'Nova Sports GR'),
    ('Nova Sports 2 Greece',  632, 'Nova Sports GR'),
    ('Cosmote Sport 1 HD',    622, 'Cosmote Sport GR'),
    ('Cosmote Sport 2 HD',    623, 'Cosmote Sport GR'),
    ('BBC One UK',            356, 'UK TV'),
    ('ITV 1 UK',              350, 'UK TV'),
    ('RTP 1 Portugal',        719, 'Portugal TV'),
    ('RTP 3 Portugal',        721, 'Portugal TV'),
    ('SIC Portugal',          722, 'Portugal TV'),
    ('WWE Network',           376, 'Combat'),
    ('NFL Network',           405, 'US Sports'),
    ('NBA TV USA',            404, 'US Sports'),
    ('TSN1',                  111, 'Canada'),
    ('TSN2',                  112, 'Canada'),
    ('CNN USA',               345, 'Noticias'),
    ('Fox News',              347, 'Noticias'),
]


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR yellow]📅 Eventos Hoje[/COLOR]', BASE, 'Schedule', site.img_live)
    site.add_dir('[COLOR dodgerblue]📺 Canais 24/7[/COLOR]', '', 'Canais247', site.img_cat)
    utils.eod()


@site.register()
def Schedule(url):
    """Obtém e lista o schedule de hoje do DaddyLive."""
    try:
        data = utils.getJson(BASE + '/schedule/schedule.json', referer=BASE + '/')
    except Exception:
        data = {}

    if not data:
        utils.notify('Schedule não disponível. A tentar scrape...')
        _schedule_scrape()
        return

    # Formato: {dia: {categoria: [{time, event, channels:[{channel_name, channel_id}]}]}}
    import datetime
    today = datetime.datetime.now().strftime('%d/%m/%Y')
    today_data = data.get(today, {})
    if not today_data:
        # Tentar primeira chave
        keys = list(data.keys())
        if keys:
            today_data = data[keys[0]]

    if not today_data:
        utils.notify('Sem eventos para hoje.')
        utils.eod()
        return

    for categoria, eventos in sorted(today_data.items()):
        for ev in eventos:
            nome   = ev.get('event', '?')
            hora   = ev.get('time', '')
            canais = ev.get('channels', [])
            if not canais:
                continue
            label  = '[COLOR gold]{}[/COLOR]  {}'.format(hora, nome)
            # Usar o primeiro canal disponível para o thumb
            cid_0  = canais[0].get('channel_id', '0')
            icon   = BASE + '/assets/logos/{}.png'.format(
                canais[0].get('channel_name', '').lower().replace(' ', '_'))
            channels_str = ','.join(str(c.get('channel_id', '')) for c in canais)
            site.add_dir(label, channels_str, 'EventPlayers', icon,
                         desc='{} — {}'.format(hora, nome))

    utils.eod()


def _schedule_scrape():
    """Fallback: scrape da página principal."""
    html = utils.getHtml(BASE + '/', referer=BASE + '/')
    if not html:
        utils.eod()
        return
    # Padrão: window.matches = JSON.parse(...)
    m = re.search(r'window\.matches\s*=\s*JSON\.parse\([\'"](.*?)[\'"]\)', html, re.DOTALL)
    if m:
        try:
            matches = json.loads(m.group(1).replace('\\"', '"'))
            for match in matches:
                nome   = match.get('event', match.get('name', '?'))
                hora   = match.get('time', '')
                canais = match.get('channels', [])
                if not canais:
                    continue
                label  = '[COLOR gold]{}[/COLOR]  {}'.format(hora, nome)
                channels_str = ','.join(str(c.get('channel_id', c)) for c in canais)
                site.add_dir(label, channels_str, 'EventPlayers', site.img_live,
                             desc='{} — {}'.format(hora, nome))
        except Exception as e:
            utils.kodilog('_schedule_scrape: ' + str(e))
    utils.eod()


@site.register()
def EventPlayers(url):
    """Lista os players disponíveis para um evento (vários canais/IDs)."""
    import xbmcplugin
    name = ''
    # url = "cid1,cid2,..."
    ids = [cid.strip() for cid in url.split(',') if cid.strip()]
    for i, cid in enumerate(ids, start=1):
        for j, folder in enumerate(ALT[:3], start=1):  # player 1-3 por canal
            player_url = '{}/{}/stream-{}.php'.format(BASE, folder, cid)
            label = '[COLOR gold]Canal {} — Player {}[/COLOR]'.format(i, j)
            site.add_download_link(label, player_url, 'Playvid',
                                   site.img_live, desc=label)
    utils.eod()


@site.register()
def Canais247(url):
    """Lista os canais 24/7 por categoria."""
    cats = {}
    for nome, cid, cat in CANAIS_247:
        cats.setdefault(cat, []).append((nome, cid))
    for cat in sorted(cats.keys()):
        site.add_dir('[COLOR white]{}[/COLOR]'.format(cat), cat, 'CanalsCat', site.img_cat)
    utils.eod()


@site.register()
def CanalsCat(url):
    """Lista canais de uma categoria."""
    cat = url
    canais = [(n, cid) for n, cid, c in CANAIS_247 if c == cat]
    for nome, cid in canais:
        slug  = nome.lower().replace(' ', '_').replace('/', '_')
        icon  = BASE + '/assets/logos/{}.png'.format(slug)
        site.add_dir(nome, str(cid), 'CanalPlayers', icon)
    utils.eod()


@site.register()
def CanalPlayers(url):
    """6 players para um canal 24/7."""
    cid = url
    for j, folder in enumerate(ALT, start=1):
        player_url = '{}/{}/stream-{}.php'.format(BASE, folder, cid)
        label = '[COLOR gold]Player {}[/COLOR]'.format(j)
        site.add_download_link(label, player_url, 'Playvid',
                               site.img_live, desc='Player ' + str(j))
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    stream, _ = __import__('resources.lib.resolver', fromlist=['resolve_stream']).resolve_stream(url)
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido. Tenta outro player.')
        import xbmcplugin
        import xbmcgui
        xbmcplugin.setResolvedUrl(int(__import__('sys').argv[1]), False, xbmcgui.ListItem())
