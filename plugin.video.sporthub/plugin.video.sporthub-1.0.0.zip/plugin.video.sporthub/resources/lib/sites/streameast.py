# -*- coding: utf-8 -*-
"""
SportHub — StreamEast
Site: https://www.streameast.app
Eventos de desporto ao vivo: NFL, NBA, NHL, MLB, Soccer, UFC, Boxing
"""
import re
import json
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'streameast',
    '[COLOR lime]StreamEast[/COLOR]',
    'https://www.streameast.app/',
    'streameast.png',
    about='StreamEast — NFL, NBA, NHL, MLB, Soccer, UFC, Boxing'
)

BASE = 'https://www.streameast.app'

SPORTS = [
    ('🏈 NFL',      BASE + '/nfl'),
    ('🏀 NBA',      BASE + '/nba'),
    ('🏒 NHL',      BASE + '/nhl'),
    ('⚾ MLB',      BASE + '/mlb'),
    ('⚽ Soccer',   BASE + '/soccer'),
    ('🥊 UFC/MMA',  BASE + '/ufc-mma'),
    ('🥊 Boxing',   BASE + '/boxing'),
    ('🏉 Rugby',    BASE + '/rugby'),
    ('🎾 Tennis',   BASE + '/tennis'),
    ('🏎️ Formula 1',BASE + '/formula-1'),
    ('🏌️ Golf',     BASE + '/golf'),
]


@site.register(default_mode=True)
def Main():
    for nome, url in SPORTS:
        site.add_dir(nome, url, 'List', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.notify('Erro ao carregar StreamEast.')
        utils.eod()
        return

    if not html:
        utils.eod()
        return

    # Padrão: links para eventos individuais
    matches = re.findall(
        r'href=["\'](/[^"\']+)["\'][^>]*>\s*(?:<[^>]+>)*\s*([^<]{5,})',
        html, re.IGNORECASE | re.DOTALL
    )
    seen = set()
    for path, nome in matches:
        nome = utils.cleantext(nome)
        if len(nome) < 4 or nome in seen:
            continue
        if any(x in path for x in ['/nfl', '/nba', '/nhl', '/mlb', '/soccer',
                                     '/ufc', '/boxing', '/rugby', '/tennis',
                                     '/formula', '/golf']):
            full_url = BASE + path
            seen.add(nome)
            site.add_dir(nome, full_url, 'Streams', site.img_live)

    if not seen:
        utils.notify('Sem eventos encontrados.')
    utils.eod()


@site.register()
def Streams(url):
    """Obtém os links de stream para um evento."""
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.eod()
        return

    if not html:
        utils.eod()
        return

    # Links de stream directo
    streams = re.findall(
        r'href=["\']([^"\']+)["\'][^>]*>[^<]*(?:Stream|Watch|Link)\s*(\d*)',
        html, re.IGNORECASE
    )
    if not streams:
        # Fallback: tentar encontrar iframes ou src de player
        iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
        for i, iframe in enumerate(iframes, start=1):
            if not iframe.startswith('http'):
                iframe = BASE + iframe
            label = 'Stream {}'.format(i)
            site.add_download_link(label, iframe, 'Playvid', site.img_live, desc=label)
    else:
        for stream_url, num in streams:
            if not stream_url.startswith('http'):
                stream_url = BASE + stream_url
            label = 'Stream {}'.format(num or '1')
            site.add_download_link(label, stream_url, 'Playvid', site.img_live, desc=label)

    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(url, referer=BASE + '/')
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido.')
        import xbmcplugin, xbmcgui, sys
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
