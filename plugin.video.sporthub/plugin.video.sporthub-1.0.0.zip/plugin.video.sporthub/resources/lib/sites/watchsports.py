# -*- coding: utf-8 -*-
"""
★ WatchSports — watchsports.to
Estrutura: watchsports.to/{sport} → lista de eventos
           watchsports.to/{sport}/{event_id} → lista de streams com links directos
Sport slugs: nba, nfl, nhl, mlb, soccer, ncaab, ncaaf, mma, boxing, nascar, golf, tennis
"""
import re
from resources.lib import utils

NAME = '★ WatchSports'
STAR = True
BASE = 'https://watchsports.to'

SPORT_MAP = {
    'football':          'soccer',
    'basketball':        'nba',
    'american-football': 'nfl',
    'hockey':            'nhl',
    'baseball':          'mlb',
    'fight':             'mma',
    'motor-sports':      'nascar',
    'tennis':            'tennis',
    'golf':              'golf',
    'rugby':             None,
    'cricket':           None,
}

# Pattern de evento na página de lista:
# /nba/401810802 → "[HORA] TEAM A vs TEAM B"
EVENT_PAT = re.compile(
    r'href=["\']({base}/(\w+)/(\d+))["\'][^>]*>.*?'
    r'([\d:apmAPM]+\s*(?:PM|AM|EDT|EST)?)'  # hora opcional
    r'.*?'
    r'([\w\s\(\)\.]+?)\s*\n'  # equipa home ou título
    r'.*?'
    r'([\w\s\(\)\.]+?)\s*\n',
    re.DOTALL
)

# Pattern simpler — links de evento
LINK_PAT = re.compile(r'href=["\']({base}/\w+/(\d+))["\']'.format(base=re.escape(BASE)))


def get_matches(sport_hub_id):
    sport = SPORT_MAP.get(sport_hub_id)
    if not sport:
        return []

    url  = '{}/{}'.format(BASE, sport)
    html = utils.getHtml(url, referer=BASE + '/')
    if not html:
        return []

    # Extrair eventos: links para /sport/eventid
    matches = re.findall(
        r'href=["\'](' + re.escape(BASE) + r'/\w+/(\d+))["\'][^>]*>'
        r'[\s\S]{0,200}?'
        r'(\d{1,2}/\d{1,2}[^\n<]{0,30})?'  # data
        r'[\s\S]{0,100}?'
        r'([A-Z][^<\n]{3,60})'               # nome equipa/evento
        r'[\s\S]{0,50}?vs[\s\S]{0,50}?'
        r'([A-Z][^<\n]{3,60})',              # nome equipa 2
        html, re.IGNORECASE
    )

    # Fallback simples
    if not matches:
        links = re.findall(
            r'href=["\'](' + re.escape(BASE) + r'/\w+/(\d+))["\']',
            html
        )
        # Extrair títulos a partir dos links + texto próximo
        # Usar outra abordagem: capturar blocos de eventos
        blocks = re.findall(
            r'href=["\'](' + re.escape(BASE) + r'/\w+/(\d+))["\'][^>]*>([\s\S]{5,200}?)</a>',
            html, re.IGNORECASE
        )
        events = []
        seen = set()
        for url_ev, eid, inner in blocks:
            inner = utils.cleantext(inner)
            if not inner or len(inner) < 4 or eid in seen:
                continue
            seen.add(eid)
            # Extrair hora
            hora_m = re.search(r'(\d{1,2}/\d{1,2}[^\n]{0,30}|\d{1,2}:\d{2}\s*(?:AM|PM)?)', inner)
            hora = hora_m.group(1).strip() if hora_m else ''
            # Título: remover hora e limpeza
            title = re.sub(r'\d{1,2}/\d{1,2}[^\n]{0,20}', '', inner).strip()[:60]
            if not title:
                title = inner[:40]
            events.append({
                'title':   title,
                'time':    hora,
                'icon':    '',
                'streams': [{
                    'source':   NAME,
                    'url':      url_ev,
                    'label':    '★ WatchSports',
                    'hd':       True,
                    'language': 'EN',
                    'star':     True,
                    'is_page':  True,
                    'icon':     '',
                }],
                'source_name': NAME,
            })
        return events

    events = []
    seen = set()
    for url_ev, eid, data_hora, team1, team2 in matches:
        title = '{} vs {}'.format(utils.cleantext(team1), utils.cleantext(team2))
        if eid in seen: continue
        seen.add(eid)
        hora = utils.cleantext(data_hora) if data_hora else ''
        events.append({
            'title':   title,
            'time':    hora,
            'icon':    '',
            'streams': [{
                'source':   NAME,
                'url':      url_ev,
                'label':    '★ WatchSports',
                'hd':       True,
                'language': 'EN',
                'star':     True,
                'is_page':  True,
                'icon':     '',
            }],
            'source_name': NAME,
        })
    return events


def get_streams_from_page(event_url):
    """
    Página do evento: lista de links directos para players externos.
    Devolve lista de {label, url, source, hd}
    """
    html = utils.getHtml(event_url, referer=BASE + '/')
    if not html:
        return []

    streams = []
    # Links de stream: padrão href="https://..." target="_blank"
    links = re.findall(
        r'href=["\']([^"\']+)["\'][^>]*(?:target=["\']_blank["\']|class=["\'][^"\']*stream[^"\']*["\'])',
        html, re.IGNORECASE
    )
    # Também capturar texto associado
    blocks = re.findall(
        r'href=["\']([^"\']+)["\'][^>]*>\s*([^<]{3,60})\s*</a>',
        html, re.IGNORECASE
    )

    seen = set()
    for url_s, label in blocks:
        url_s = url_s.strip()
        if url_s in seen or not url_s.startswith('http'): continue
        if any(x in url_s for x in ['watchsports.to', 'javascript:', 'mailto:']): continue
        label = utils.cleantext(label)
        if not label or len(label) < 3: continue
        seen.add(url_s)
        streams.append({
            'source':   '★ WatchSports — {}'.format(label[:30]),
            'url':      url_s,
            'label':    '★ WatchSports — {}'.format(label[:30]),
            'hd':       True,
            'language': 'EN',
            'star':     True,
        })

    return streams
