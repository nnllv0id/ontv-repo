# -*- coding: utf-8 -*-
"""
Sites de nicho:
  - NBAMonster (nbamonster.com) — NBA por equipa
  - OnHockey.tv — Hockey internacional
  - BuffStream (ms.buffstream.io) — NFL/NHL/MLB/Boxing/Motor
"""
import re
from resources.lib import utils

# ─── NBAMonster ──────────────────────────────────────────────────────────────

NAME_NBA  = 'NBAMonster'
BASE_NBA  = 'https://nbamonster.com'

NBA_TEAMS = [
    ('Atlanta Hawks',        'atlanta-hawks-live'),
    ('Boston Celtics',       'boston-celtics-live'),
    ('Brooklyn Nets',        'brooklyn-nets-live'),
    ('Charlotte Hornets',    'charlotte-hornets-live'),
    ('Chicago Bulls',        'chicago-bulls-live'),
    ('Cleveland Cavaliers',  'cleveland-cavaliers-live'),
    ('Dallas Mavericks',     'dallas-mavericks-live'),
    ('Denver Nuggets',       'denver-nuggets-live'),
    ('Detroit Pistons',      'detroit-pistons-live'),
    ('Golden State Warriors','golden-state-warriors-live'),
    ('Houston Rockets',      'houston-rockets-live'),
    ('Indiana Pacers',       'indiana-pacers-live'),
    ('LA Clippers',          'la-clipper-live'),
    ('Los Angeles Lakers',   'los-angeles-lakers-live'),
    ('Memphis Grizzlies',    'memphis-grizzlies-live'),
    ('Miami Heat',           'miami-heat-live'),
    ('Milwaukee Bucks',      'milwaukee-bucks-live'),
    ('Minnesota Timberwolves','minnesota-timberwolves-live'),
    ('New Orleans Pelicans', 'new-orleans-pelicans-live'),
    ('New York Knicks',      'new-york-knicks-live'),
    ('Oklahoma City Thunder','oklahoma-city-thunder-live'),
    ('Orlando Magic',        'orlando-magic-live'),
    ('Philadelphia 76ers',   'philadelphia-76ers-live'),
    ('Phoenix Suns',         'phoenix-suns-live'),
    ('Portland Trail Blazers','portland-trail-blazers-live'),
    ('Sacramento Kings',     'sacramento-kings-live'),
    ('San Antonio Spurs',    'san-antonio-spurs-live'),
    ('Toronto Raptors',      'toronto-raptors-live'),
    ('Utah Jazz',            'utah-jazz-live'),
    ('Washington Wizards',   'washington-wizards-live'),
]


def get_nbamonster_matches():
    """Devolve lista de equipas como "matches" — cada uma com stream."""
    events = []
    for name, slug in NBA_TEAMS:
        url = '{}/teams/{}'.format(BASE_NBA, slug)
        events.append({
            'title':   name,
            'time':    '',
            'icon':    '',
            'streams': [{
                'source':   NAME_NBA,
                'url':      url,
                'label':    'NBAMonster — {}'.format(name),
                'hd':       True,
                'language': 'EN',
                'star':     False,
                'is_page':  True,
                'base':     BASE_NBA,
                'icon':     '',
            }],
            'source_name': NAME_NBA,
        })
    return events


def get_nbamonster_streams(event_url):
    html = utils.getHtml(event_url, referer=BASE_NBA + '/')
    if not html:
        return []
    streams = []
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)
    for i, src in enumerate(iframes, 1):
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else BASE_NBA + '/' + src.lstrip('/')
        if any(x in src for x in ['ads', 'google']): continue
        streams.append({
            'source':   'NBAMonster — {}'.format(i),
            'url':      src,
            'label':    'NBAMonster — Stream {}'.format(i),
            'hd':       True,
            'language': 'EN',
            'star':     False,
        })
    return streams


# ─── OnHockey.tv ─────────────────────────────────────────────────────────────

NAME_HOCKEY = 'OnHockey'
BASE_HOCKEY = 'https://onhockey.tv'


def get_onhockey_matches():
    """
    onhockey.tv carrega via JS, mas tem uma API/JSON ou RSS.
    Tentamos scrape básico.
    """
    html = utils.getHtml(BASE_HOCKEY + '/', referer=BASE_HOCKEY + '/')
    if not html:
        return []

    # Tentar apanhar links de jogos: padrão /game/... ou /stream/...
    links = re.findall(
        r'href=["\'](' + re.escape(BASE_HOCKEY) + r'/[^\s"\']+)["\'][^>]*>\s*([^<]{5,60})',
        html, re.I
    )
    # Também procurar links de embed directos
    embeds = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.I)

    events = []
    seen = set()

    for src in embeds:
        if not src.startswith('http'):
            src = ('https:' + src) if src.startswith('//') else BASE_HOCKEY + '/' + src.lstrip('/')
        if src in seen: continue
        seen.add(src)
        events.append({
            'title':   'OnHockey — Live Stream',
            'time':    '🔴 LIVE',
            'icon':    '',
            'streams': [{
                'source':   NAME_HOCKEY,
                'url':      src,
                'label':    'OnHockey Live',
                'hd':       True,
                'language': 'Multi',
                'star':     False,
                'icon':     '',
            }],
            'source_name': NAME_HOCKEY,
        })

    for url_ev, title in links[:20]:
        title = utils.cleantext(title)
        if not title or url_ev in seen or len(title) < 4: continue
        if any(x in url_ev for x in ['#', 'chat', 'add']): continue
        seen.add(url_ev)
        events.append({
            'title':   title,
            'time':    '',
            'icon':    '',
            'streams': [{
                'source':   NAME_HOCKEY,
                'url':      url_ev,
                'label':    'OnHockey — {}'.format(title[:30]),
                'hd':       True,
                'language': 'Multi',
                'star':     False,
                'is_page':  True,
                'base':     BASE_HOCKEY,
                'icon':     '',
            }],
            'source_name': NAME_HOCKEY,
        })

    return events


# ─── BuffStream Homepage ──────────────────────────────────────────────────────

NAME_BUFF = 'BuffStream'
BASE_BUFF = 'https://ms.buffstream.io'

BUFF_SPORT_URLS = {
    'basketball':        BASE_BUFF + '/nba-streams',
    'american-football': BASE_BUFF + '/nfl-streams-live-30',
    'hockey':            BASE_BUFF + '/nhl-streams-live-28',
    'baseball':          BASE_BUFF + '/mlb-streams-live-28',
    'fight':             BASE_BUFF + '/mma-streams-live-35',
    'motor-sports':      BASE_BUFF + '/motor-streams-live-25',
    'football':          'https://ronaldo7.io/soccerstreams',
}


def get_buffstream_matches(sport_hub_id):
    url = BUFF_SPORT_URLS.get(sport_hub_id)
    if not url:
        return []

    base_url = '/'.join(url.split('/')[:3])
    html = utils.getHtml(url, referer=base_url + '/')
    if not html:
        return []

    # Padrão verificado: tabela com links de equipa
    matches = re.findall(
        r'href=["\'](' + re.escape(base_url) + r'/[^\s"\']+)["\'][^>]*>\s*'
        r'(?:<[^>]+>)*\s*([A-Z][^<]{3,60}?)\s*(?:Live Stream)?(?:</[^>]+>)*\s*</a>',
        html, re.IGNORECASE
    )

    events = []
    seen = set()
    for url_ev, name_ev in matches:
        name_ev = utils.cleantext(name_ev)
        if not name_ev or url_ev in seen or len(name_ev) < 4: continue
        if any(x in url_ev for x in ['index', 'mmastreams', 'olympic']): continue
        seen.add(url_ev)
        events.append({
            'title':   name_ev,
            'time':    '',
            'icon':    '',
            'streams': [{
                'source':   NAME_BUFF,
                'url':      url_ev,
                'label':    'BuffStream',
                'hd':       True,
                'language': 'EN',
                'star':     False,
                'is_page':  True,
                'base':     base_url,
                'icon':     '',
            }],
            'source_name': NAME_BUFF,
        })
    return events
