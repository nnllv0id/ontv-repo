# -*- coding: utf-8 -*-
"""
SportHub — SportsBay
Site: https://www.sportsbay.vc
Foco em futebol europeu, NFL, NBA, F1
"""
import re
from resources.lib import utils
from resources.lib.sportsite import SportSite

site = SportSite(
    'sportsbay',
    '[COLOR gold]SportsBay[/COLOR]',
    'https://www.sportsbay.vc/',
    'sportsbay.png',
    about='SportsBay — futebol, NFL, NBA, F1 ao vivo'
)

BASE = 'https://www.sportsbay.vc'

SPORTS = [
    ('⚽ Football/Soccer', BASE + '/football'),
    ('🏀 Basketball',       BASE + '/basketball'),
    ('🏈 American Football',BASE + '/american-football'),
    ('🏒 Ice Hockey',       BASE + '/ice-hockey'),
    ('⚾ Baseball',          BASE + '/baseball'),
    ('🥊 Boxing/MMA',        BASE + '/boxing'),
    ('🏎️ Formula 1',         BASE + '/formula-1'),
    ('🎾 Tennis',             BASE + '/tennis'),
    ('🏉 Rugby',              BASE + '/rugby'),
    ('🏌️ Golf',               BASE + '/golf'),
]


@site.register(default_mode=True)
def Main():
    for nome, url in SPORTS:
        site.add_dir(nome, url, 'List', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.eod()
        return
    if not html:
        utils.eod()
        return

    matches = re.findall(
        r'<a\s+href=["\']([^"\']+)["\'][^>]*>\s*<div[^>]*>\s*([^<]{5,80})',
        html, re.IGNORECASE | re.DOTALL
    )
    if not matches:
        matches = re.findall(
            r'href=["\']([^"\']+/(?:stream|watch|event|game)/[^"\']+)["\'][^>]*>\s*([^<]{5,80})',
            html, re.IGNORECASE
        )

    seen = set()
    for path, nome in matches:
        nome = utils.cleantext(nome)
        if not nome or nome in seen or len(nome) < 4:
            continue
        full = path if path.startswith('http') else BASE + path
        seen.add(nome)
        site.add_dir(nome, full, 'Streams', site.img_live)

    if not seen:
        utils.notify('Sem eventos. Domínio pode ter mudado.')
    utils.eod()


@site.register()
def Streams(url):
    try:
        html = utils.getHtml(url, referer=BASE + '/')
    except Exception:
        utils.eod()
        return

    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE)
    added = 0
    for i, iframe in enumerate(iframes, start=1):
        if not iframe.startswith('http'):
            iframe = BASE + iframe
        site.add_download_link('Stream {}'.format(i), iframe, 'Playvid', site.img_live)
        added += 1

    if not added:
        m3u8s = re.findall(r'(https?://[^\s\'"]+\.m3u8[^\s\'"]*)', html)
        for i, u in enumerate(m3u8s, start=1):
            site.add_download_link('Stream {}'.format(i), u, 'Playvid', site.img_live)
            added += 1

    if not added:
        utils.notify('Streams não encontrados.')
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(30)
    from resources.lib.resolver import resolve_stream
    stream, _ = resolve_stream(url, referer=BASE + '/')
    if stream:
        vp.play_from_resolver(stream)
    else:
        utils.notify('Stream não resolvido.')
        import xbmcplugin, xbmcgui, sys
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
