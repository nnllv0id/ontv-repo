# -*- coding: utf-8 -*-
"""
network.py — DNS over HTTPS (DoH) para contornar bloqueios do ISP.
O resto da lógica de rede está em utils.py.
"""
import socket, json, ssl
import xbmc

try:
    from urllib.request import urlopen, Request
except ImportError:
    from urllib2 import urlopen, Request

_doh_active = False

DOH_SERVERS = [
    'https://cloudflare-dns.com/dns-query',
    'https://dns.google/resolve',
    'https://dns.adguard.com/resolve',
]

_dns_cache = {}
_orig_getaddrinfo = socket.getaddrinfo


def _doh_resolve(host, doh_url=None):
    if host in _dns_cache:
        return _dns_cache[host]
    servers = [doh_url] + DOH_SERVERS if doh_url else DOH_SERVERS
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    except Exception:
        ctx = None
    for srv in servers:
        try:
            url = '{}?name={}&type=A'.format(srv, host)
            req = Request(url, headers={
                'Accept': 'application/dns-json',
                'User-Agent': 'SportHub/1.0'
            })
            if ctx:
                resp = urlopen(req, timeout=5, context=ctx)
            else:
                resp = urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            for ans in data.get('Answer', []):
                if ans.get('type') == 1:
                    ip = ans['data']
                    _dns_cache[host] = ip
                    return ip
        except Exception:
            pass
    return None


def _patched_getaddrinfo(host, port, *args, **kwargs):
    try:
        ip = _doh_resolve(host)
        if ip:
            return _orig_getaddrinfo(ip, port, *args, **kwargs)
    except Exception:
        pass
    return _orig_getaddrinfo(host, port, *args, **kwargs)


def enable_doh(custom_url=None):
    global _doh_active
    if _doh_active:
        return
    try:
        socket.getaddrinfo = _patched_getaddrinfo
        _doh_active = True
        xbmc.log('[SportHub/Net] DoH activado com sucesso', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log('[SportHub/Net] DoH falhou: ' + str(e), xbmc.LOGWARNING)


# Aliases para compatibilidade com código antigo
def fetch(url, referer='', headers=None, timeout=15):
    from resources.lib.utils import _do_request
    return _do_request(url, referer=referer, headers=headers, timeout=timeout)


def fetch_json(url, referer='', headers=None, timeout=15):
    from resources.lib.utils import getJson
    return getJson(url, referer=referer, headers=headers, timeout=timeout)


UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')
