# -*- coding: utf-8 -*-
"""
SportHub — network.py
Camada de rede robusta com:
  1. DNS over HTTPS (DoH) — contorna bloqueios de DNS do ISP
  2. Sessão HTTP persistente com headers realistas
  3. Retry automático (3 tentativas)
  4. Seguimento de redirects
  5. SSL sem verificação (para sites com cert problemático)
  6. Fallback automático para DNS normal se DoH falhar
"""
import re, ssl, gzip, json, socket, logging, time
import xbmc, xbmcaddon

try:
    from urllib.request import urlopen, Request, HTTPCookieProcessor, build_opener
    from urllib.parse import urlparse, urlencode
    from urllib.error import HTTPError, URLError
    from http.cookiejar import CookieJar
except ImportError:
    from urllib2 import urlopen, Request, HTTPError, URLError, HTTPCookieProcessor, build_opener
    from urllib import urlencode
    from urlparse import urlparse
    from cookielib import CookieJar

# ─── Logging ──────────────────────────────────────────────────────────────────

def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log('[SportHub/Net] ' + str(msg), level)

def _warn(msg):
    _log(msg, xbmc.LOGWARNING)

# ─── SSL sem verificação ──────────────────────────────────────────────────────

try:
    _ssl_ctx = ssl.create_default_context()
    _ssl_ctx.check_hostname = False
    _ssl_ctx.verify_mode    = ssl.CERT_NONE
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    _ssl_ctx = None

# ─── User-Agent realista ──────────────────────────────────────────────────────

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/122.0.0.0 Safari/537.36')

BASE_HEADERS = {
    'User-Agent':      UA,
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9,pt;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
    'Connection':      'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest':  'document',
    'Sec-Fetch-Mode':  'navigate',
    'Sec-Fetch-Site':  'none',
    'Cache-Control':   'no-cache',
}

# ─── Cookie jar global ────────────────────────────────────────────────────────

_cookiejar = CookieJar()
_opener    = build_opener(HTTPCookieProcessor(_cookiejar))

# ─── DoH — DNS over HTTPS ─────────────────────────────────────────────────────
#
# Substitui socket.getaddrinfo para resolver domínios via HTTPS
# em vez de usar o DNS do ISP (que pode bloquear os sites).
#
# Servidores DoH públicos (tenta por ordem):
#   1. Cloudflare  — dns.cloudflare.com
#   2. Google      — dns.google
#   3. AdGuard     — dns.adguard.com

DOH_SERVERS = [
    'https://cloudflare-dns.com/dns-query',
    'https://dns.google/dns-query',
    'https://dns.adguard.com/dns-query',
]

_dns_cache        = {}          # {domain: ip}
_original_getaddr = socket.getaddrinfo
_doh_active       = False


def _doh_resolve(domain, doh_url=None):
    """Resolve um domínio via DoH. Devolve IP (str) ou None."""
    if domain in _dns_cache:
        return _dns_cache[domain]

    servers = [doh_url] + DOH_SERVERS if doh_url else DOH_SERVERS

    for server in servers:
        try:
            # RFC 8484 — JSON format
            req_url = '{}?name={}&type=A'.format(server, domain)
            req = Request(req_url, headers={
                'Accept':     'application/dns-json',
                'User-Agent': UA,
            })
            resp = urlopen(req, timeout=5,
                           context=_ssl_ctx) if _ssl_ctx else urlopen(req, timeout=5)
            data = json.loads(resp.read().decode('utf-8', errors='replace'))
            answers = data.get('Answer', [])
            for ans in answers:
                ip = ans.get('data', '')
                # Verificar se é IPv4 válido
                try:
                    socket.inet_aton(ip)
                    _dns_cache[domain] = ip
                    _log('DoH resolved {} → {} (via {})'.format(domain, ip, server))
                    return ip
                except Exception:
                    continue
        except Exception as e:
            _log('DoH {} failed for {}: {}'.format(server, domain, e))
            continue

    return None


def _patched_getaddrinfo(host, port, *args, **kwargs):
    """
    Substitui socket.getaddrinfo:
    1. Tenta resolver via DoH
    2. Se falhar, usa o DNS original
    """
    try:
        # Não resolver IPs ou o próprio servidor DoH
        try:
            socket.inet_aton(host)
            return _original_getaddr(host, port, *args, **kwargs)
        except Exception:
            pass

        # Não resolver hosts locais
        if not '.' in host or host.endswith('.local'):
            return _original_getaddr(host, port, *args, **kwargs)

        ip = _doh_resolve(host)
        if ip:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]

    except Exception as e:
        _log('Patched getaddrinfo error for {}: {}'.format(host, e))

    # Fallback DNS normal
    return _original_getaddr(host, port, *args, **kwargs)


def enable_doh(custom_url=None):
    """Activa o DoH. Chama uma vez no arranque do addon."""
    global _doh_active
    if _doh_active:
        return
    try:
        # Tentar resolver um domínio de teste
        test = _doh_resolve('google.com', custom_url)
        if test:
            socket.getaddrinfo = _patched_getaddrinfo
            _doh_active = True
            _log('DoH activado com sucesso', xbmc.LOGINFO)
        else:
            _warn('DoH não conseguiu resolver teste — a usar DNS normal')
    except Exception as e:
        _warn('DoH init error: ' + str(e))


def disable_doh():
    """Restaura o DNS original."""
    global _doh_active
    socket.getaddrinfo = _original_getaddr
    _doh_active = False
    _dns_cache.clear()
    _log('DoH desactivado')


def clear_dns_cache():
    """Limpa a cache de DNS."""
    _dns_cache.clear()
    _log('Cache DNS limpa')


# ─── HTTP — fetch robusto ─────────────────────────────────────────────────────

def fetch(url, referer='', headers=None, timeout=20, retries=3, method='GET',
          post_data=None, json_response=False):
    """
    Fetch HTTP robusto com:
    - Headers realistas
    - Cookie jar automático
    - Retry com backoff
    - Gzip decode
    - Seguimento de redirects
    Devolve str (HTML) ou dict/list (JSON) ou None em caso de erro.
    """
    hdrs = dict(BASE_HEADERS)
    if referer:
        hdrs['Referer'] = referer
        hdrs['Origin']  = _origin(referer)
        hdrs['Sec-Fetch-Site'] = 'same-origin'
    if json_response:
        hdrs['Accept'] = 'application/json, */*'
    if headers:
        hdrs.update(headers)

    last_error = None
    for attempt in range(retries):
        try:
            if method == 'POST' and post_data:
                if isinstance(post_data, dict):
                    post_data = urlencode(post_data).encode('utf-8')
                elif isinstance(post_data, str):
                    post_data = post_data.encode('utf-8')
                req = Request(url, data=post_data, headers=hdrs)
            else:
                req = Request(url, headers=hdrs)

            if _ssl_ctx:
                resp = _opener.open(req, timeout=timeout)
            else:
                resp = _opener.open(req, timeout=timeout)

            raw = resp.read()
            encoding = resp.headers.get('Content-Encoding', '')
            if 'gzip' in encoding:
                raw = gzip.decompress(raw)
            elif 'deflate' in encoding:
                import zlib
                try:
                    raw = zlib.decompress(raw)
                except Exception:
                    raw = zlib.decompress(raw, -zlib.MAX_WBITS)

            text = raw.decode('utf-8', errors='replace')

            if json_response:
                try:
                    return json.loads(text)
                except Exception:
                    _warn('JSON parse error for: ' + url[:80])
                    return None

            return text

        except HTTPError as e:
            last_error = e
            code = e.code
            _log('HTTP {} for {} (attempt {}/{})'.format(code, url[:60], attempt+1, retries))
            # 403/429 → esperar mais
            if code in (403, 429, 503):
                time.sleep(2 * (attempt + 1))
            elif code in (404, 410):
                break  # Não retry em 404
        except URLError as e:
            last_error = e
            _log('URLError for {} (attempt {}/{}): {}'.format(url[:60], attempt+1, retries, e))
            time.sleep(1 * (attempt + 1))
        except Exception as e:
            last_error = e
            _log('Fetch error for {} (attempt {}/{}): {}'.format(url[:60], attempt+1, retries, e))
            time.sleep(1 * (attempt + 1))

    _warn('fetch failed after {} retries: {} | {}'.format(retries, url[:80], last_error))
    return None


def fetch_json(url, referer='', headers=None, timeout=20):
    """Fetch + parse JSON."""
    return fetch(url, referer=referer, headers=headers,
                 timeout=timeout, json_response=True)


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _origin(url):
    try:
        p = urlparse(url)
        return '{}://{}'.format(p.scheme or 'https', p.netloc)
    except Exception:
        return ''


def is_doh_active():
    return _doh_active
