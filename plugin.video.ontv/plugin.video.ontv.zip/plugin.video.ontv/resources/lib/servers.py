# -*- coding: utf-8 -*-
"""
OnTV — Configuração dos Servidores
"""
import json
import os
import xbmcvfs

# ─── Configuração ────────────────────────────────────────────────────────────
SERVERS_URL = 'https://raw.githubusercontent.com/nnllv0id/ontv-servers/main/servers.json'

# Personal Access Token com permissão contents:read
GITHUB_TOKEN  = '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'
TOKEN_EXPIRA  = '2026-05-05'  # Data de expiração do token (AAAA-MM-DD)
# ─────────────────────────────────────────────────────────────────────────────

_FALLBACK = []  # Sem fallback — usa sempre repositório remoto ou cache

_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_remoto():
    try:
        from urllib.request import urlopen, Request
        headers = {
            'User-Agent':    'Kodi/OnTV-Addon',
            'Authorization': 'token ' + GITHUB_TOKEN,
            'Accept':        'application/vnd.github.v3.raw',
        }
        req  = Request(SERVERS_URL, headers=headers)
        resp = urlopen(req, timeout=10)
        data = resp.read().decode('utf-8')
        servidores = json.loads(data)
        try:
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                f.write(data)
        except Exception:
            pass
        return servidores
    except Exception as e:
        import xbmc
        xbmc.log('[OnTV] Erro ao carregar servers.json remoto: ' + str(e), xbmc.LOGWARNING)
        return None


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def carregar_servidores():
    import xbmc, xbmcgui, datetime

    # Avisar quando o token expira em menos de 10 dias — apenas uma vez por dia
    try:
        expira    = datetime.date.fromisoformat(TOKEN_EXPIRA)
        hoje      = datetime.date.today()
        dias      = (expira - hoje).days
        aviso_key = _CACHE_FILE + '.aviso'

        # Verificar se já avisámos hoje
        ja_avisou_hoje = False
        try:
            if os.path.exists(aviso_key):
                with open(aviso_key, 'r') as _f:
                    ja_avisou_hoje = (_f.read().strip() == str(hoje))
        except Exception:
            pass

        if (dias <= 0 or dias <= 7) and not ja_avisou_hoje:
            if dias <= 0:
                xbmcgui.Dialog().notification(
                    'OnTV — Token Expirado',
                    'Renova o token GitHub em servers.py!',
                    xbmcgui.NOTIFICATION_ERROR, 8000)
                xbmc.log('[OnTV] Token GitHub EXPIRADO', xbmc.LOGERROR)
            else:
                xbmcgui.Dialog().notification(
                    'OnTV — Token expira em {} dias'.format(dias),
                    'Renova o token GitHub em breve!',
                    xbmcgui.NOTIFICATION_WARNING, 6000)
                xbmc.log('[OnTV] Token GitHub expira em {} dias'.format(dias), xbmc.LOGWARNING)
            # Guardar que já avisámos hoje
            try:
                with open(aviso_key, 'w') as _f:
                    _f.write(str(hoje))
            except Exception:
                pass
    except Exception:
        pass

    servidores = _carregar_remoto()
    if servidores:
        return servidores
    servidores = _carregar_cache()
    if servidores:
        xbmc.log('[OnTV] A usar cache local de servidores', xbmc.LOGWARNING)
        return servidores
    xbmc.log('[OnTV] A usar servidores de fallback', xbmc.LOGWARNING)
    return _FALLBACK


SERVIDORES = carregar_servidores()
