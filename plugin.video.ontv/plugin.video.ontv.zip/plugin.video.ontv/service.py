# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background
Monitoriza o player e reinicia streams .ts quando fecham por EOF.
Corre em background desde que o Kodi está aberto.
"""
import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import tempfile

ADDON     = xbmcaddon.Addon()
ADDON_ID  = ADDON.getAddonInfo('id')
STREAM_FILE = os.path.join(tempfile.gettempdir(), 'ontv_stream.json')
STOP_FILE   = os.path.join(tempfile.gettempdir(), 'ontv_stop.flag')


def log(msg):
    xbmc.log('[OnTV Service] ' + str(msg), xbmc.LOGINFO)


def ler_stream():
    """Lê o ficheiro com info do stream actual."""
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    """Remove o ficheiro de stream (utilizador parou manualmente)."""
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def eh_ts_live(url):
    """Verifica se é um stream .ts live (não um ficheiro local)."""
    if not url:
        return False
    url_lower = url.lower().split('?')[0]
    return url_lower.endswith('.ts') and url.startswith('http')


class OnTVMonitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.player = OnTVPlayer()

    def onAbortRequested(self):
        log('Kodi a fechar — serviço terminado')
        self.player.parar()


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._parado_pelo_user = False
        self._a_reiniciar      = False

    def parar(self):
        self._parado_pelo_user = True
        limpar_stream()

    def onPlayBackStarted(self):
        self._parado_pelo_user = False
        self._a_reiniciar      = False
        log('Stream iniciado')

    def onPlayBackStopped(self):
        """Utilizador parou — limpar e não reiniciar."""
        log('Stream parado pelo utilizador')
        self._parado_pelo_user = True
        limpar_stream()

    def onPlayBackEnded(self):
        """EOF — verificar se é stream .ts live e reiniciar."""
        if self._parado_pelo_user or self._a_reiniciar:
            return

        info = ler_stream()
        if not info:
            return

        url = info.get('url', '')
        if not eh_ts_live(url):
            log('EOF em stream não-TS, sem reiniciar')
            return

        log('EOF em stream .ts — a reiniciar: ' + url[:80])
        self._a_reiniciar = True
        xbmc.sleep(800)

        nome = info.get('nome', '')
        logo = info.get('logo', '')

        li = xbmcgui.ListItem(nome, path=url)
        li.setProperty('IsPlayable', 'true')
        li.setProperty('mimetype', 'video/mp2t')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo})
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})

        self.play(url, li)
        self._a_reiniciar = False

    def onPlayBackError(self):
        """Erro de rede — tentar reiniciar com delay maior."""
        if self._parado_pelo_user or self._a_reiniciar:
            return

        info = ler_stream()
        if not info:
            return

        url = info.get('url', '')
        if not eh_ts_live(url):
            return

        log('Erro no stream .ts — a reiniciar após 2s: ' + url[:80])
        self._a_reiniciar = True
        xbmc.sleep(2000)

        nome = info.get('nome', '')
        logo = info.get('logo', '')

        li = xbmcgui.ListItem(nome, path=url)
        li.setProperty('IsPlayable', 'true')
        li.setProperty('mimetype', 'video/mp2t')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo})
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})

        self.play(url, li)
        self._a_reiniciar = False


def run():
    log('Serviço iniciado')
    monitor = OnTVMonitor()

    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break

    log('Serviço terminado')


if __name__ == '__main__':
    run()
