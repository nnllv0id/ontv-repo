# -*- coding: utf-8 -*-
# Proxy identico ao f4mTester 1.0.3 server.py
# Usa requests (identico ao f4mTester) em vez de urlopen

import threading
import time

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    from http.server  import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

try:
    from urllib.request import urlopen, Request as URequest
except ImportError:
    from urllib2 import urlopen, Request as URequest

HOST        = '127.0.0.1'
PORT        = 52315
CHUNK_SIZE  = 300000   # identico ao f4mTester (iter_content(300000))

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/120.0.0.0 Safari/537.36')

_lock      = threading.Lock()
_stop_flag = False
_cur_url   = ''

GLOBAL_HEADERS = {'User-Agent': UA, 'Connection': 'keep-alive'}
GLOBAL_URL     = ''
HTTPS_PORT     = False


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _cur_url
    with _lock:
        _cur_url = url

def _get_url():
    with _lock:
        return _cur_url


def _is_m3u8_url(url):
    return '.m3u8' in url or ('/hl' in url and not url.endswith('.ts'))


def _basename(p):
    i = p.rfind('/') + 1
    return p[i:]


def convert_to_m3u8(url):
    """Identico ao f4mTester 1.0.3 convert_to_m3u8()."""
    if '|' in url:
        url = url.split('|')[0]
    if not '.m3u8' in url and not '/hl' in url \
            and url.count(':') == 2 and url.count('/') > 4:
        try:
            parsed = urlparse(url)
            host1  = '{}://{}'.format(parsed.scheme, parsed.netloc)
            host2  = url.split(host1)[1]
            url    = host1 + '/live' + host2
            fname  = _basename(url)
            if '.ts' in fname:
                url = url.replace(fname, fname.replace('.ts', '.m3u8'))
            else:
                url = url.replace(fname, fname + '.m3u8')
        except Exception:
            pass
    return url


def _resolve_seg(seg, base):
    if seg.startswith('http'):
        return seg
    if seg.startswith('/'):
        p = urlparse(base)
        return '{}://{}{}'.format(p.scheme, p.netloc, seg)
    return base.rsplit('/', 1)[0] + '/' + seg


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _parse_url(self):
        try:
            raw = self.path.split('url=')[1]
            try:
                return unquote_plus(raw)
            except Exception:
                return unquote(raw)
        except Exception:
            return ''

    def do_HEAD(self):
        self._route('HEAD')

    def do_GET(self):
        self._route('GET')

    def _route(self, method):
        if _is_stopped():
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True; t.start()
            return

        url = self._parse_url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        # Converter para m3u8 — identico ao f4mTester
        url = convert_to_m3u8(url)

        if _is_m3u8_url(url):
            self._serve_m3u8(url, method)
        else:
            self._serve_ts(url, method)

    def _serve_m3u8(self, url, method):
        """Identico ao m3u8() do f4mTester 1.0.3."""
        global GLOBAL_URL, HTTPS_PORT

        for i in range(20):
            if _is_stopped(): break
            try:
                if HAS_REQUESTS:
                    r = requests.get(url, headers=GLOBAL_HEADERS,
                                     timeout=4, verify=False)
                    last_url = r.url
                    text_    = r.text
                    status   = r.status_code
                    r.close()
                else:
                    resp     = urlopen(URequest(url, headers=GLOBAL_HEADERS), timeout=4)
                    last_url = url
                    text_    = resp.read().decode('utf-8', errors='replace')
                    status   = resp.status
                    resp.close()

                parsed   = urlparse(last_url)
                base_url = '{}://{}'.format(parsed.scheme, parsed.netloc)

                if status == 200:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.end_headers()
                    if method != 'HEAD':
                        # Reescrever segmentos para passar pelo proxy
                        # Identico ao f4mTester mas usando _resolve_seg
                        proxy_base = 'http://{}:{}'.format(HOST, PORT)
                        out = []
                        for line in text_.splitlines():
                            s = line.strip()
                            if not s or s.startswith('#'):
                                out.append(line)
                            else:
                                abs_seg = _resolve_seg(s, last_url)
                                out.append(proxy_base + '/?url=' + quote_plus(abs_seg))
                        self.wfile.write('\n'.join(out).encode('utf-8'))
                    return

                r_close = getattr(r, 'close', None)
                if r_close:
                    r_close()
                break

            except Exception:
                pass

            if _is_stopped(): break
            time.sleep(3)

            if i == 7:  # 8 tentativas = 24 segundos, identico ao f4mTester
                try:
                    self.send_response(404); self.end_headers()
                except Exception:
                    pass
                return

    def _serve_ts(self, url, method):
        """Identico ao ts() do f4mTester 1.0.3."""
        for i in range(30):
            if _is_stopped(): break
            try:
                if HAS_REQUESTS:
                    r = requests.get(url, headers=GLOBAL_HEADERS,
                                     stream=True, verify=False)
                    if r.status_code == 200:
                        self.send_response(200)
                        self.send_header('Content-type', 'video/mp2t')
                        self.end_headers()
                        if method != 'HEAD':
                            for chunk in r.iter_content(CHUNK_SIZE):
                                if _is_stopped():
                                    break
                                try:
                                    self.wfile.write(chunk)
                                except Exception:
                                    break
                    r.close()
                    break   # identico ao f4mTester: break apos ligacao bem sucedida
                else:
                    # Fallback sem requests
                    import socket
                    resp = urlopen(URequest(url, headers=GLOBAL_HEADERS), timeout=10)
                    try:
                        resp.fp.raw._sock.settimeout(8)
                    except Exception:
                        pass
                    if resp.status == 200:
                        self.send_response(200)
                        self.send_header('Content-type', 'video/mp2t')
                        self.end_headers()
                        if method != 'HEAD':
                            while not _is_stopped():
                                try:
                                    chunk = resp.read(CHUNK_SIZE)
                                except Exception:
                                    break
                                if not chunk:
                                    break
                                try:
                                    self.wfile.write(chunk)
                                except Exception:
                                    break
                    resp.close()
                    break

            except Exception:
                pass

            if _is_stopped(): break

            if i == 14:
                try:
                    self.send_response(404); self.end_headers()
                except Exception:
                    pass
                return


# ── Gestao do servidor ─────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    global _server_instance, _server_thread
    _set_stop(False)
    _set_url(url)

    if _server_thread and _server_thread.is_alive():
        return _make_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _Handler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _Handler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    for _ in range(20):
        if is_running(): break
        time.sleep(0.2)

    return _make_url(url)


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True; t.start(); t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        if HAS_REQUESTS:
            r = requests.get('http://{}:{}/check'.format(HOST, PORT), timeout=2)
            return r.status_code == 200
        else:
            resp = urlopen(URequest('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
            resp.close()
            return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)


def _make_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
