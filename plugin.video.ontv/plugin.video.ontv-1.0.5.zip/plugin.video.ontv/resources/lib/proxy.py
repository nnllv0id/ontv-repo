# -*- coding: utf-8 -*-
import binascii
import os
import threading
import time
from collections import deque

try:
    from http.server    import HTTPServer, BaseHTTPRequestHandler
    from urllib.request import urlopen, Request
    from urllib.parse   import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urllib2        import urlopen, Request
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

HOST         = '127.0.0.1'
PORT         = 52315
CHUNK_SIZE   = 65536
TIMEOUT_REQ  = 15
TIMEOUT_READ = 30
MAX_RETRIES  = 30

UA_BASE = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
           'AppleWebKit/537.36 (KHTML, like Gecko) '
           'Chrome/120.0.0.0 Safari/537.36')

# Backoff em segundos: reconexoes rapidas primeiro, depois mais espaçadas
# O indice NAO avanca se o stream esteve estavel — bug do for/range corrigido
_RETRY_BACKOFF = [0.5, 1, 1, 2, 2, 4, 4, 8, 16, 30,
                  30,  30, 30, 30, 30, 30, 30, 30, 30, 30,
                  30,  30, 30, 30, 30, 30, 30, 30, 30, 30]

_lock        = threading.Lock()
_stop_flag   = False
_current_url = ''

_chunk_cache = deque(maxlen=10)
_cache_lock  = threading.Lock()


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _current_url
    with _lock:
        _current_url = url

def _get_url():
    with _lock:
        return _current_url

def _cache_chunk(chunk):
    with _cache_lock:
        _chunk_cache.append(chunk)

def _get_cached_chunks():
    with _cache_lock:
        return list(_chunk_cache)[-5:]

def _clear_cache():
    with _cache_lock:
        _chunk_cache.clear()


def _ua(retry=False):
    if not retry:
        return UA_BASE
    return binascii.b2a_hex(os.urandom(20))[:32].decode()


def _build_headers(retry=False):
    return {
        'User-Agent':      _ua(retry),
        'Connection':      'keep-alive',
        'Accept':          '*/*',
        'Accept-Encoding': 'identity',
    }


def _is_m3u8(url):
    u = url.lower().split('?')[0]
    return '.m3u8' in u or '/hls/' in u


def _resolve_segment(seg_url, base):
    if seg_url.startswith('http'):
        return seg_url
    if seg_url.startswith('/'):
        p = urlparse(base)
        return '{}://{}{}'.format(p.scheme, p.netloc, seg_url)
    return base.rsplit('/', 1)[0] + '/' + seg_url


def _rewrite_m3u8(body_text, proxy_base, original_url):
    out = []
    for line in body_text.splitlines():
        s = line.strip()
        if s.startswith('#') or not s:
            out.append(line)
        else:
            abs_url = _resolve_segment(s, original_url)
            out.append(proxy_base + '/?url=' + quote_plus(abs_url))
    return '\n'.join(out)


class _StreamHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _get_target_url(self):
        if '?url=' in self.path:
            encoded = self.path.split('?url=', 1)[1]
            try:
                return unquote_plus(encoded)
            except Exception:
                return unquote(encoded)
        return ''

    def do_HEAD(self):
        self._handle('HEAD')

    def do_GET(self):
        self._handle('GET')

    def _send_chunk(self, chunk):
        self.wfile.write('{:X}\r\n'.format(len(chunk)).encode('ascii'))
        self.wfile.write(chunk)
        self.wfile.write(b'\r\n')
        self.wfile.flush()

    def _handle(self, method):
        if _is_stopped():
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True; t.start()
            return

        url = self._get_target_url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        proxy_base = 'http://{}:{}'.format(HOST, PORT)

        # ── HLS manifesto ─────────────────────────────────────────────────
        if _is_m3u8(url):
            attempt = 0
            while attempt < MAX_RETRIES:
                if _is_stopped(): break
                try:
                    resp = urlopen(
                        Request(url, headers=_build_headers(attempt > 0)),
                        timeout=TIMEOUT_REQ
                    )
                    body = resp.read().decode('utf-8', errors='replace')
                    resp.close()
                    rewritten = _rewrite_m3u8(body, proxy_base, url)
                    enc = rewritten.encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(enc)))
                    self.end_headers()
                    if method != 'HEAD':
                        self.wfile.write(enc)
                    return
                except Exception:
                    if _is_stopped(): break
                    time.sleep(_RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF)-1)])
                    attempt += 1
            try:
                self.send_response(503); self.end_headers()
            except Exception:
                pass
            return

        # ── TS / mp4 — reconexao silenciosa ──────────────────────────────
        #
        # CORRECAO DO BUG: usar while com contador manual.
        # O for/range em Python ignora atribuicoes ao iterador dentro do loop,
        # por isso o "recuar o contador em streams estaveis" nunca funcionava.
        # Com while, controlamos exactamente quando o contador avanca.
        #
        # Logica do contador:
        #   - Stream corta apos < 10s: contador avanca (genuinamente instavel)
        #   - Stream corta apos >= 10s: contador NAO avanca (corte ocasional)
        #   - Stream estavel por >= 60s: contador recua ate 0 (reset completo)
        #
        headers_sent  = False
        last_data     = time.time()
        attempt       = 0
        _clear_cache()

        while attempt < MAX_RETRIES:
            if _is_stopped(): break

            session_start = time.time()

            try:
                resp = urlopen(
                    Request(url, headers=_build_headers(attempt > 0)),
                    timeout=TIMEOUT_REQ
                )

                if not headers_sent:
                    self.send_response(200)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('Transfer-Encoding', 'chunked')
                    self.end_headers()
                    headers_sent = True
                else:
                    # Enviar cache de chunks para minimizar ecrã preto
                    for cached in _get_cached_chunks():
                        try:
                            self._send_chunk(cached)
                        except Exception:
                            resp.close(); return

                if method == 'HEAD':
                    resp.close(); return

                last_data = time.time()

                while not _is_stopped():
                    try:
                        chunk = resp.read(CHUNK_SIZE)
                    except Exception:
                        break
                    if not chunk:
                        if time.time() - last_data > TIMEOUT_READ:
                            break
                        time.sleep(0.05)
                        continue
                    last_data = time.time()
                    _cache_chunk(chunk)
                    try:
                        self._send_chunk(chunk)
                    except Exception:
                        resp.close(); return

                resp.close()

            except Exception:
                pass

            if _is_stopped(): break

            session_dur = time.time() - session_start

            # Decidir se o contador avanca, fica ou recua
            if session_dur >= 60:
                # Stream esteve estavel bastante tempo — reset completo
                attempt = 0
            elif session_dur >= 10:
                # Corte ocasional num stream razoavel — nao penalizar
                pass
            else:
                # Falha rapida — avancar o backoff
                attempt += 1

            espera = _RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF)-1)]
            time.sleep(espera)

        # Desistiu — fechar abruptamente (sem 0\r\n\r\n)
        try:
            self.wfile.close()
        except Exception:
            pass


# ── Gestao do servidor ─────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    global _server_instance, _server_thread
    _set_stop(False)
    _set_url(url)
    _clear_cache()

    if _server_thread and _server_thread.is_alive():
        return _make_proxy_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    for _ in range(15):
        if is_running(): break
        time.sleep(0.2)

    return _make_proxy_url(url)


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    _clear_cache()
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True; t.start(); t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        resp = urlopen(
            Request('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
        resp.close()
        return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)
    _clear_cache()


def _make_proxy_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
