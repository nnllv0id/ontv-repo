# -*- coding: utf-8 -*-
import binascii
import os
import socket
import threading
import time

try:
    from http.server    import HTTPServer, BaseHTTPRequestHandler
    from urllib.request import urlopen, Request
    from urllib.parse   import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urllib2        import urlopen, Request
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

HOST         = '127.0.0.1'
PORT         = 52315
CHUNK_SIZE   = 524288  # 512 KB
TIMEOUT_REQ  = 10
TIMEOUT_READ = 8

UA_BASE = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
           'AppleWebKit/537.36 (KHTML, like Gecko) '
           'Chrome/120.0.0.0 Safari/537.36')

_lock       = threading.Lock()
_stop_flag  = False
_cur_url    = ''
_bytes_sent = 0

# Cache de URLs testados: True = servidor suporta .m3u8, False = usar .ts directo
_m3u8_cache      = {}
_m3u8_cache_lock = threading.Lock()


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _cur_url
    with _lock:
        _cur_url = url

def _get_url():
    with _lock:
        return _cur_url

def _add_bytes(n):
    global _bytes_sent
    with _lock:
        _bytes_sent += n

def _get_bytes():
    with _lock:
        return _bytes_sent

def _reset_bytes():
    global _bytes_sent
    with _lock:
        _bytes_sent = 0

def _m3u8_supported(key):
    with _m3u8_cache_lock:
        return _m3u8_cache.get(key, None)

def _set_m3u8_supported(key, val):
    with _m3u8_cache_lock:
        _m3u8_cache[key] = val


def _ua(retry=False):
    if not retry:
        return UA_BASE
    return binascii.b2a_hex(os.urandom(20))[:32].decode()


def _hdrs(retry=False, byte_offset=0):
    h = {
        'User-Agent':      _ua(retry),
        'Connection':      'keep-alive',
        'Accept':          '*/*',
        'Accept-Encoding': 'identity',
    }
    if byte_offset > 0:
        h['Range'] = 'bytes={}-'.format(byte_offset)
    return h


def _is_m3u8(url):
    u = url.lower().split('?')[0]
    return '.m3u8' in u or '/hls/' in u


def _is_ts(url):
    """URL e um stream TS (nao m3u8, nao mp4/mkv, etc.)"""
    u = url.lower().split('?')[0]
    if _is_m3u8(url):
        return False
    non_ts = ('.mp4', '.mkv', '.avi', '.flv', '.wmv', '.mov', '.webm', '.mp3', '.aac')
    if any(u.endswith(e) for e in non_ts):
        return False
    if not url.startswith('http'):
        return False
    return True


def _to_m3u8(url):
    """Converte URL .ts para .m3u8 mantendo o resto igual."""
    try:
        parsed = urlparse(url)
        path   = parsed.path
        if path.lower().endswith('.ts'):
            path = path[:-3] + '.m3u8'
        elif not path.lower().endswith('.m3u8'):
            path = path + '.m3u8'
        return '{}://{}{}'.format(parsed.scheme, parsed.netloc, path)
    except Exception:
        return url


def _server_key(url):
    """Chave unica por servidor+stream para a cache de suporte .m3u8"""
    try:
        p = urlparse(url)
        return '{}://{}{}'.format(p.scheme, p.netloc, p.path)
    except Exception:
        return url


def _probe_m3u8(url):
    """
    Testa se o servidor serve .m3u8 para este URL.
    Faz um HEAD/GET rapido e verifica se a resposta e um manifesto HLS valido.
    Devolve True se suporta, False caso contrario.
    """
    m3u8_url = _to_m3u8(url)
    try:
        resp = urlopen(Request(m3u8_url, headers=_hdrs()), timeout=5)
        ct   = resp.headers.get('Content-Type', '')
        # Ler apenas os primeiros bytes para verificar se e um manifesto HLS
        first = resp.read(64).decode('utf-8', errors='replace')
        resp.close()
        is_hls = ('#EXTM3U' in first or
                  'application/vnd.apple' in ct or
                  'application/x-mpegurl' in ct.lower())
        return is_hls
    except Exception:
        return False


def _resolve_seg(seg, base):
    if seg.startswith('http'):
        return seg
    if seg.startswith('/'):
        p = urlparse(base)
        return '{}://{}{}'.format(p.scheme, p.netloc, seg)
    return base.rsplit('/', 1)[0] + '/' + seg


def _rewrite_m3u8(text, proxy_base, orig):
    out = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('#') or not s:
            out.append(line)
        else:
            out.append(proxy_base + '/?url=' + quote_plus(_resolve_seg(s, orig)))
    return '\n'.join(out)


def _set_sock_timeout(resp):
    try:
        resp.fp.raw._sock.settimeout(TIMEOUT_READ)
    except Exception:
        try:
            resp.fp._sock.settimeout(TIMEOUT_READ)
        except Exception:
            pass


def _range_accepted(resp):
    try:
        return resp.status == 206
    except Exception:
        return False


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _url(self):
        if '?url=' in self.path:
            enc = self.path.split('?url=', 1)[1]
            try:
                return unquote_plus(enc)
            except Exception:
                return unquote(enc)
        return ''

    def do_HEAD(self):
        self._handle('HEAD')

    def do_GET(self):
        self._handle('GET')

    def _handle(self, method):
        if _is_stopped():
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True; t.start()
            return

        url = self._url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        # Para streams TS: detectar automaticamente se o servidor suporta .m3u8
        # Resultado guardado em cache para nao repetir o teste em cada reconexao
        if _is_ts(url):
            key      = _server_key(url)
            supports = _m3u8_supported(key)
            if supports is None:
                # Primeira vez — testar
                supports = _probe_m3u8(url)
                _set_m3u8_supported(key, supports)
            if supports:
                url = _to_m3u8(url)

        proxy_base = 'http://{}:{}'.format(HOST, PORT)

        # ── HLS/m3u8 ──────────────────────────────────────────────────────
        if _is_m3u8(url):
            for attempt in range(20):
                if _is_stopped(): break
                try:
                    resp = urlopen(Request(url, headers=_hdrs(attempt > 0)),
                                   timeout=TIMEOUT_REQ)
                    body = resp.read().decode('utf-8', errors='replace')
                    resp.close()
                    # Verificar que e realmente um manifesto HLS
                    if '#EXTM3U' not in body:
                        # Servidor nao serve m3u8 — actualizar cache e usar TS
                        key = _server_key(url)
                        _set_m3u8_supported(key, False)
                        url = url.replace('.m3u8', '.ts')
                        break
                    enc = _rewrite_m3u8(body, proxy_base, url).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(enc)))
                    self.end_headers()
                    if method != 'HEAD':
                        self.wfile.write(enc)
                    return
                except Exception:
                    if _is_stopped(): break
                    time.sleep(min(attempt + 1, 5))
            # Se chegou aqui sem retornar, converter de volta para TS e continuar
            if _is_m3u8(url):
                try:
                    self.send_response(503); self.end_headers()
                except Exception:
                    pass
                return

        # ── TS / mp4 directo ───────────────────────────────────────────────
        headers_sent  = False
        range_support = False
        _reset_bytes()
        MAX_ATTEMPTS  = 30

        for attempt in range(MAX_ATTEMPTS):
            if _is_stopped(): break

            offset = _get_bytes() if (range_support and attempt > 0) else 0

            try:
                resp = urlopen(
                    Request(url, headers=_hdrs(attempt > 0, byte_offset=offset)),
                    timeout=TIMEOUT_REQ
                )
                _set_sock_timeout(resp)

                if attempt == 1:
                    range_support = _range_accepted(resp)

                if not headers_sent:
                    ct = resp.headers.get('Content-Type', 'video/mp2t')
                    if 'html' in ct or 'text' in ct:
                        ct = 'video/mp2t'
                    self.send_response(200)
                    self.send_header('Content-Type', ct)
                    self.end_headers()
                    headers_sent = True

                if method == 'HEAD':
                    resp.close(); return

                stream_ok = False
                while not _is_stopped():
                    try:
                        chunk = resp.read(CHUNK_SIZE)
                    except (socket.timeout, OSError, Exception):
                        break
                    if not chunk:
                        break
                    stream_ok = True
                    _add_bytes(len(chunk))
                    try:
                        self.wfile.write(chunk)
                        self.wfile.flush()
                    except Exception:
                        resp.close(); return

                resp.close()
                if _is_stopped(): break

                if stream_ok:
                    time.sleep(0.5)
                else:
                    time.sleep(min(attempt * 2 + 1, 10))

            except Exception:
                if _is_stopped(): break
                time.sleep(min(attempt + 1, 5))


# ── Gestao do servidor ─────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    global _server_instance, _server_thread
    _set_stop(False)
    _set_url(url)
    _reset_bytes()

    if _server_thread and _server_thread.is_alive():
        return _make_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _Handler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _Handler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    for _ in range(15):
        if is_running(): break
        time.sleep(0.2)

    return _make_url(url)


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True; t.start(); t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        resp = urlopen(Request('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
        resp.close()
        return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)
    _reset_bytes()


def _make_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
