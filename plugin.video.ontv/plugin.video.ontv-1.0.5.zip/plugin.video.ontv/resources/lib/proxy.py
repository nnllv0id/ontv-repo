# -*- coding: utf-8 -*-
# Proxy fiel ao f4mTester 1.0.3:
#   - TS: UMA ligacao, sem reconexao interna (break apos r.close())
#   - M3U8: reescrever manifesto, Kodi gere segmentos autonomamente
#   - convert_to_m3u8: identica ao f4mTester (count ':' == 2, count '/' > 4)

import binascii
import os
import socket
import threading
import time

try:
    from http.server    import HTTPServer, BaseHTTPRequestHandler
    from urllib.request import urlopen, Request
    from urllib.parse   import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urllib2        import urlopen, Request
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

HOST        = '127.0.0.1'
PORT        = 52315
CHUNK_SIZE  = 524288  # 512 KB — igual ao f4mTester (300000 ~ 512 KB)
TIMEOUT_REQ = 10
TIMEOUT_READ= 8

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/120.0.0.0 Safari/537.36')

_lock      = threading.Lock()
_stop_flag = False
_cur_url   = ''


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _cur_url
    with _lock:
        _cur_url = url

def _get_url():
    with _lock:
        return _cur_url


def _hdrs():
    return {
        'User-Agent':      UA,
        'Connection':      'keep-alive',
        'Accept':          '*/*',
        'Accept-Encoding': 'identity',
    }


def _is_m3u8(url):
    u = url.lower().split('?')[0]
    return '.m3u8' in u or '/hls/' in u


def convert_to_m3u8(url):
    """
    Identica ao f4mTester 1.0.3 convert_to_m3u8().
    Condicao: nao e m3u8, nao tem /hl, tem exactamente 2 ':', tem mais de 4 '/'
    """
    if '|' in url:
        url = url.split('|')[0]
    if '.m3u8' in url or '/hl' in url:
        return url
    if url.count(':') == 2 and url.count('/') > 4:
        try:
            parsed    = urlparse(url)
            host_part = '{}://{}'.format(parsed.scheme, parsed.netloc)
            path_part = url.split(host_part)[1]
            url       = host_part + '/live' + path_part
            basename  = url.split('/')[-1].split('?')[0]
            if '.ts' in basename:
                new_name = basename.replace('.ts', '.m3u8')
            else:
                new_name = basename + '.m3u8'
            url = url.replace(basename, new_name)
        except Exception:
            pass
    return url


def _resolve_seg(seg, base):
    if seg.startswith('http'):
        return seg
    if seg.startswith('/'):
        p = urlparse(base)
        return '{}://{}{}'.format(p.scheme, p.netloc, seg)
    return base.rsplit('/', 1)[0] + '/' + seg


def _rewrite_m3u8(text, proxy_base, orig_url):
    """Reescreve manifesto m3u8 — identico ao f4mTester mas usando urllib."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith('#'):
            out.append(line)
        else:
            abs_url = _resolve_seg(s, orig_url)
            out.append(proxy_base + '/?url=' + quote_plus(abs_url))
    return '\n'.join(out)


def _set_sock_timeout(resp):
    try:
        resp.fp.raw._sock.settimeout(TIMEOUT_READ)
    except Exception:
        try:
            resp.fp._sock.settimeout(TIMEOUT_READ)
        except Exception:
            pass


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _get_url(self):
        if '?url=' in self.path:
            enc = self.path.split('?url=', 1)[1]
            try:
                return unquote_plus(enc)
            except Exception:
                return unquote(enc)
        return ''

    def do_HEAD(self):
        self._handle('HEAD')

    def do_GET(self):
        self._handle('GET')

    def _handle(self, method):
        if _is_stopped():
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True; t.start()
            return

        url = self._get_url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        # Converter para m3u8 — logica identica ao f4mTester 1.0.3
        url = convert_to_m3u8(url)

        proxy_base = 'http://{}:{}'.format(HOST, PORT)

        # ── M3U8 — reescrever manifesto ───────────────────────────────────
        if _is_m3u8(url):
            for attempt in range(8):
                if _is_stopped(): break
                try:
                    resp = urlopen(Request(url, headers=_hdrs()), timeout=TIMEOUT_REQ)
                    body = resp.read().decode('utf-8', errors='replace')
                    resp.close()
                    enc = _rewrite_m3u8(body, proxy_base, url).encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(enc)))
                    self.end_headers()
                    if method != 'HEAD':
                        self.wfile.write(enc)
                    return
                except Exception:
                    if _is_stopped(): break
                    time.sleep(3)   # f4mTester usa time.sleep(3) entre tentativas m3u8
            try:
                self.send_response(404); self.end_headers()
            except Exception:
                pass
            return

        # ── TS — UMA ligacao, sem reconexao (fiel ao f4mTester 1.0.3) ─────
        # O f4mTester faz break apos r.close() — nao reconecta dentro do loop.
        # Isso evita rollbacks porque nao ha dados duplicados na reconexao.
        # O loop de 30 tentativas so serve para a PRIMEIRA ligacao falhar.
        for attempt in range(30):
            if _is_stopped(): break
            try:
                resp = urlopen(Request(url, headers=_hdrs()), timeout=TIMEOUT_REQ)
                _set_sock_timeout(resp)

                if resp.status not in (200, 206):
                    resp.close()
                    if attempt == 14:
                        try:
                            self.send_response(404); self.end_headers()
                        except Exception:
                            pass
                        return
                    continue

                self.send_response(200)
                self.send_header('Content-Type', 'video/mp2t')
                self.end_headers()

                if method != 'HEAD':
                    while not _is_stopped():
                        try:
                            chunk = resp.read(CHUNK_SIZE)
                        except (socket.timeout, OSError, Exception):
                            break
                        if not chunk:
                            break
                        try:
                            self.wfile.write(chunk)
                            self.wfile.flush()
                        except Exception:
                            break

                resp.close()
                break   # ← BREAK APOS LIGACAO BEM SUCEDIDA — identico ao f4mTester

            except Exception:
                if _is_stopped(): break
                if attempt == 14:
                    try:
                        self.send_response(404); self.end_headers()
                    except Exception:
                        pass
                    return


# ── Gestao do servidor ─────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    global _server_instance, _server_thread
    _set_stop(False)
    _set_url(url)

    if _server_thread and _server_thread.is_alive():
        return _make_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _Handler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _Handler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    for _ in range(15):
        if is_running(): break
        time.sleep(0.2)

    return _make_url(url)


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True; t.start(); t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        resp = urlopen(Request('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
        resp.close()
        return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)


def _make_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
