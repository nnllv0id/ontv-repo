# -*- coding: utf-8 -*-
import base64
import json
import os
import threading
import time

try:
    import xbmc
    import xbmcvfs
    def _log(msg, level=None):
        xbmc.log('[OnTV/servers] ' + str(msg), level or xbmc.LOGINFO)
    def _tmp(nome):
        return xbmcvfs.translatePath('special://temp/' + nome)
except Exception:
    def _log(msg, level=None):
        print('[OnTV/servers] ' + str(msg))
    def _tmp(nome):
        return os.path.join(os.path.dirname(__file__), nome)

_s0 = 'HBsgR0cXHS5bJDEdYBoAF11AZx0KUV1'
_s1 = '6TG5hD35ZB1ZFFzBLWQFZfh81YV0uDg'
_s2 = 'NdE1s3RFkSAydDOHsDIA5PERwRJ0MGB'
_s3 = 'x0uXiM2GycZCAJcACBEDktAcV4mIBon'
_k  = b'OnTV-Kodi-Stream'

def _r():
    raw = base64.b64decode(_s0 + _s1 + _s2 + _s3)[::-1]
    return bytes(b ^ _k[i % len(_k)] for i, b in enumerate(raw)).decode()

_CACHE_FILE = _tmp('ontv_servers.json')
_SRC_TS     = _tmp('ontv_src_ts.flag')
_TTL        = 1800

_servidores      = None
_servidores_lock = threading.Lock()


def _ler_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        _log('Erro cache: ' + str(e))
    return None


def _escrever_cache(dados):
    try:
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(dados, f, ensure_ascii=False)
    except Exception as e:
        _log('Erro ao guardar cache: ' + str(e))


def _cache_fresca():
    try:
        if os.path.exists(_SRC_TS):
            with open(_SRC_TS, 'r') as f:
                ts = float(f.read().strip())
            return (time.time() - ts) < _TTL
    except Exception:
        pass
    return False


def _marcar_visitado():
    try:
        with open(_SRC_TS, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _apagar_flag():
    try:
        if os.path.exists(_SRC_TS):
            os.remove(_SRC_TS)
    except Exception:
        pass


def _fetch():
    try:
        from urllib.request import urlopen, Request
    except ImportError:
        from urllib2 import urlopen, Request

    url = _r() + '?t=' + str(int(time.time()))
    req = Request(url, headers={
        'User-Agent':    'Kodi/OnTV',
        'Cache-Control': 'no-cache, no-store',
        'Pragma':        'no-cache',
    })
    resp = urlopen(req, timeout=12)
    return json.loads(resp.read().decode('utf-8'))


def carregar_servidores():
    global _servidores

    if _servidores is not None:
        return _servidores

    with _servidores_lock:
        if _servidores is not None:
            return _servidores

        if _cache_fresca():
            dados = _ler_cache()
            if dados:
                _log('Servidores da cache ({})'.format(len(dados)))
                _servidores = dados
                return _servidores

        try:
            dados = _fetch()
            if dados:
                _escrever_cache(dados)
                _marcar_visitado()
                _log('Servidores carregados ({})'.format(len(dados)))
                _servidores = dados
                return _servidores
        except Exception as e:
            _log('Fonte indisponivel: ' + str(e))

        dados = _ler_cache()
        if dados:
            _log('A usar cache expirada ({})'.format(len(dados)))
            _servidores = dados
            return _servidores

        _log('Sem servidores!')
        _servidores = []
        return _servidores


def invalidar_cache():
    global _servidores
    _servidores = None
    _apagar_flag()
