# -*- coding: utf-8 -*-
"""
OnTV — Proxy Local de Streams  v1.0.2

Servidor HTTP local em 127.0.0.1:52315 que faz de intermediário
entre o Kodi e o servidor IPTV.

Vantagens:
  - O Kodi reproduz sempre de localhost — nunca "vê" cortes do servidor real
  - Quando há interrupção, o proxy reconecta automaticamente ao servidor
    sem o Kodi saber → sem reabrir o canal visualmente
  - Funciona com streams .ts e .m3u8 (HLS com segmentos)
  - Sem dependências externas — usa apenas stdlib do Python

Baseado na abordagem do F4mTester/Proxy2, reescrito limpo e sem
dependências de kodi-six, requests ou script.module.six.
"""

import threading
import time
import os

try:
    from http.server       import HTTPServer, BaseHTTPRequestHandler
    from urllib.request    import urlopen, Request
    from urllib.parse      import urlparse, unquote, quote_plus, unquote_plus
    from urllib.error      import URLError
except ImportError:
    from BaseHTTPServer    import HTTPServer, BaseHTTPRequestHandler  # type: ignore
    from urllib2           import urlopen, Request, URLError          # type: ignore
    from urlparse          import urlparse, unquote                   # type: ignore
    from urllib            import quote_plus, unquote_plus            # type: ignore

HOST        = '127.0.0.1'
PORT        = 52315
UA          = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
               'AppleWebKit/537.36 (KHTML, like Gecko) '
               'Chrome/120.0.0.0 Safari/537.36')
CHUNK_SIZE  = 65536   # 64 KB por chunk — equilíbrio entre latência e CPU
TIMEOUT_REQ = 20      # segundos para estabelecer ligação ao servidor IPTV
TIMEOUT_READ= 30      # segundos sem dados antes de reconectar
MAX_RETRIES = 10      # reconexões automáticas antes de desistir

# Estado global partilhado entre handler e controlo externo
_lock        = threading.Lock()
_stop_flag   = False
_current_url = ''
_base_url    = ''     # base URL para segmentos relativos de HLS


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _current_url
    with _lock:
        _current_url = url

def _get_url():
    with _lock:
        return _current_url


def _build_headers():
    return {
        'User-Agent':  UA,
        'Connection':  'keep-alive',
        'Accept':      '*/*',
        'Accept-Encoding': 'identity',  # evitar gzip — o Kodi não descomprime
    }


def _is_m3u8(url):
    u = url.lower().split('?')[0]
    return '.m3u8' in u or '/hls/' in u


def _resolve_segment(seg_url, base):
    """Converte URL relativo de segmento HLS em absoluto."""
    if seg_url.startswith('http'):
        return seg_url
    if seg_url.startswith('/'):
        parsed = urlparse(base)
        return '{}://{}{}'.format(parsed.scheme, parsed.netloc, seg_url)
    # relativo ao directório
    return base.rsplit('/', 1)[0] + '/' + seg_url


def _rewrite_m3u8(body_text, proxy_base, original_url):
    """
    Reescreve um manifesto M3U8 para que todos os segmentos
    passem pelo proxy local em vez de ir directamente ao servidor.
    """
    lines = body_text.splitlines()
    out   = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('#') or not stripped:
            out.append(line)
        else:
            # É um URI de segmento ou sub-playlist
            abs_url = _resolve_segment(stripped, original_url)
            proxied = proxy_base + '/?url=' + quote_plus(abs_url)
            out.append(proxied)
    return '\n'.join(out)


class _StreamHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass   # silenciar logs do HTTPServer no terminal

    def _get_target_url(self):
        """Extrai e decodifica o URL alvo do path do pedido."""
        path = self.path
        if '?url=' in path:
            encoded = path.split('?url=', 1)[1]
            try:
                url = unquote_plus(encoded)
            except Exception:
                url = unquote(encoded)
        else:
            # pedido de /check ou /stop
            url = ''
        return url

    def do_HEAD(self):
        self._handle('HEAD')

    def do_GET(self):
        self._handle('GET')

    def _handle(self, method):
        global _base_url

        if _is_stopped():
            self.send_response(503)
            self.end_headers()
            return

        # Pedidos de controlo
        if self.path == '/check':
            self.send_response(200)
            self.end_headers()
            return
        if self.path == '/stop':
            self.send_response(200)
            self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True
            t.start()
            return

        url = self._get_target_url()
        if not url or not url.startswith('http'):
            # Fallback: usar URL guardado globalmente
            url = _get_url()
            if not url:
                self.send_response(404)
                self.end_headers()
                return

        proxy_base = 'http://{}:{}'.format(HOST, PORT)
        is_m3u8   = _is_m3u8(url)
        headers   = _build_headers()

        for attempt in range(MAX_RETRIES):
            if _is_stopped():
                break
            try:
                req  = Request(url, headers=headers)
                resp = urlopen(req, timeout=TIMEOUT_REQ)

                if is_m3u8:
                    # ── Manifesto HLS ────────────────────────────────
                    body = resp.read().decode('utf-8', errors='replace')
                    resp.close()

                    # Guardar base URL para segmentos relativos
                    with _lock:
                        _base_url = url

                    rewritten = _rewrite_m3u8(body, proxy_base, url)
                    encoded   = rewritten.encode('utf-8')

                    self.send_response(200)
                    self.send_header('Content-Type',   'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(encoded)))
                    self.end_headers()
                    if method != 'HEAD':
                        self.wfile.write(encoded)
                    return

                else:
                    # ── Stream binário (TS, mp4, etc.) ───────────────
                    self.send_response(200)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.end_headers()
                    if method == 'HEAD':
                        resp.close()
                        return
                    while not _is_stopped():
                        try:
                            chunk = resp.read(CHUNK_SIZE)
                        except Exception:
                            break
                        if not chunk:
                            break
                        try:
                            self.wfile.write(chunk)
                        except Exception:
                            break
                    resp.close()
                    return

            except Exception:
                if attempt < MAX_RETRIES - 1 and not _is_stopped():
                    time.sleep(2)
                continue

        # Todas as tentativas falharam
        try:
            self.send_response(503)
            self.end_headers()
        except Exception:
            pass


# ── Gestão do servidor ────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    """
    Inicia o servidor proxy (se não estiver já a correr) e regista o URL
    do stream actual. Devolve o URL proxied para passar ao Kodi.
    """
    global _server_instance, _server_thread

    _set_stop(False)
    _set_url(url)

    # Verificar se já está a correr
    if _server_thread and _server_thread.is_alive():
        return _make_proxy_url(url)

    # Iniciar servidor
    try:
        _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
        _server_instance.allow_reuse_address = True
    except Exception as e:
        # Porta em uso — tentar fechar a instância anterior
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url   # fallback: usar URL original

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    # Aguardar o servidor ficar disponível (máx 3s)
    for _ in range(15):
        if is_running():
            break
        time.sleep(0.2)

    return _make_proxy_url(url)


def stop():
    """Para o servidor proxy."""
    global _server_instance, _server_thread
    _set_stop(True)
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True
            t.start()
            t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    """Verifica se o proxy está a responder."""
    try:
        req  = Request('http://{}:{}/check'.format(HOST, PORT))
        resp = urlopen(req, timeout=2)
        resp.close()
        return True
    except Exception:
        return False


def update_url(url):
    """Actualiza o URL do stream sem reiniciar o servidor."""
    _set_url(url)


def _make_proxy_url(url):
    """Constrói o URL proxied para passar ao Kodi."""
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
