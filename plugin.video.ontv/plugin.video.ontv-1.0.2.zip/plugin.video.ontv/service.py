# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background

MELHORIAS v1.1.0:
  - Backoff exponencial no reinício (1s → 3s → 10s → desiste)
  - Janela de tempo correcta para contagem de reinícios
  - Não sobrescreve advancedsettings.xml
  - Logs mais claros com motivo e tentativa
"""

import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import time
import xbmcvfs

ADDON       = xbmcaddon.Addon()
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')
STOP_FILE   = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')

# Backoff em segundos para cada tentativa consecutiva de reinício
_BACKOFF = [1.5, 3.0, 10.0]   # 3 tentativas; após a 3.ª desiste


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def ler_stream():
    """Lê as informações do stream activo a partir do ficheiro temporário."""
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def _utilizador_parou():
    """Verifica se o utilizador parou manualmente o stream."""
    return os.path.exists(STOP_FILE)


def _criar_stop_flag():
    try:
        with open(STOP_FILE, 'w') as f:
            f.write('1')
    except Exception:
        pass


def _remover_stop_flag():
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
    except Exception:
        pass


def _fazer_listitem(url, nome, logo):
    """
    Cria um ListItem compatível com todos os dispositivos.
    Detecção de tipo de stream por extensão/conteúdo da URL.
    """
    url_lower = url.lower().split('?')[0]
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url_lower:
        # HLS — usa inputstream.adaptive se disponível
        try:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('mimetype', 'application/x-mpegURL')
        except Exception:
            # Dispositivos mais antigos podem não ter o addon — fallback nativo
            li.setMimeType('application/x-mpegURL')
    elif url_lower.endswith('.mp4') or url_lower.endswith('.mkv'):
        li.setMimeType('video/mp4')
    else:
        # MPEG-TS / streams ao vivo
        try:
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('mimetype', 'video/mp2t')
            li.setProperty('inputstream.ffmpegdirect.read_chunk_size', '131072')
        except Exception:
            li.setMimeType('video/mp2t')

    # Configurações de rede comuns a todos os tipos
    li.setProperty('network.curlcachebytes',  '20971520')  # 20 MB cache
    li.setProperty('network.bandwidth',       '0')
    li.setProperty('network.readtimeout',     '60')
    li.setProperty('network.connecttimeout',  '10')

    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video', 'playcount': 0, 'overlay': 0})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super(OnTVPlayer, self).__init__()
        self._reset()

    def _reset(self):
        """Reinicia contadores de reinício."""
        self._tempo_inicio    = 0.0
        self._tentativa       = 0      # índice no array _BACKOFF
        self._a_reiniciar     = False

    def onPlayBackStarted(self):
        self._tempo_inicio = time.time()
        self._tentativa    = 0
        self._a_reiniciar  = False
        _remover_stop_flag()
        log('Stream iniciado')

    def onPlayBackStopped(self):
        """Utilizador parou manualmente — nunca reiniciar."""
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._reset()
        _criar_stop_flag()
        try:
            import sys, os
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
            from proxy import stop as proxy_stop
            proxy_stop()
        except Exception:
            pass

    def onPlayBackEnded(self):
        """EOF — servidor fechou ligação (ex: fim de VOD ou corte de live)."""
        if _utilizador_parou():
            return
        # Pequena pausa antes de tentar reiniciar
        xbmc.sleep(1500)
        self._tentar_reiniciar('EOF')

    def onPlayBackError(self):
        """Erro de rede ou codec."""
        if _utilizador_parou():
            return
        xbmc.sleep(2000)
        self._tentar_reiniciar('Erro')

    def _tentar_reiniciar(self, motivo):
        """
        Reinicia o stream com backoff exponencial.
        Máximo de len(_BACKOFF) tentativas consecutivas.
        Se o stream correu bem por mais de 30s, reset dos contadores.
        """
        if self._a_reiniciar:
            return
        if _utilizador_parou():
            return

        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            log('Reinício cancelado — sem info de stream válida')
            return

        # Se o stream correu mais de 30 segundos, considera-se "limpo"
        # e reinicia os contadores de backoff
        duracao = time.time() - self._tempo_inicio
        if duracao > 30:
            self._tentativa = 0

        if self._tentativa >= len(_BACKOFF):
            log('{} — limite de reinícios atingido após {} tentativas'.format(
                motivo, len(_BACKOFF)), xbmc.LOGWARNING)
            return

        espera   = _BACKOFF[self._tentativa]
        self._tentativa += 1
        self._a_reiniciar = True

        log('{} em {:.0f}s — tentativa {}/{}, aguardar {:.1f}s'.format(
            motivo, duracao, self._tentativa, len(_BACKOFF), espera))

        xbmc.sleep(int(espera * 1000))

        # Verificar novamente após a espera (utilizador pode ter parado entretanto)
        if _utilizador_parou():
            self._a_reiniciar = False
            return

        url  = info.get('url', '')
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        # Parar proxy antes de reiniciar — o reproduzir() irá iniciá-lo de novo
        try:
            import sys, os
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
            from proxy import stop as proxy_stop
            proxy_stop()
        except Exception:
            pass
        self.play(url, _fazer_listitem(url, nome, logo))
        self._a_reiniciar = False


def run():
    log('Serviço iniciado (v1.1.0)')

    # Invalidar cache de servidores para forçar actualização
    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(5)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
