# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background  v1.0.2

Reinicia automaticamente o stream em caso de EOF ou erro de rede
(token expirado, corte do servidor, etc.), mas NUNCA quando o
utilizador para manualmente.
"""

import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import time
import xbmcvfs

ADDON       = xbmcaddon.Addon()
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')
STOP_FILE   = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')

# Máximo de reinícios consecutivos rápidos (dentro de _JANELA_RAPIDA segundos)
# antes de desistir. Se o stream correu bem mais de _JANELA_RAPIDA segundos,
# o contador reseta — permite reiniciar indefinidamente streams que falham
# raramente (ex: token que expira a cada 30 min).
_MAX_RAPIDOS   = 3      # desiste após 3 falhas rápidas seguidas
_JANELA_RAPIDA = 30     # "rápida" = falhou em menos de 30s de stream
_ESPERA_EOF    = 1500   # ms a aguardar antes de reiniciar após EOF
_ESPERA_ERRO   = 3000   # ms a aguardar antes de reiniciar após erro


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def _utilizador_parou():
    return os.path.exists(STOP_FILE)


def _criar_stop_flag():
    try:
        with open(STOP_FILE, 'w') as f:
            f.write('1')
    except Exception:
        pass


def _remover_stop_flag():
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
    except Exception:
        pass


def _fazer_listitem(url, nome, logo):
    url_lower = url.lower().split('?')[0]
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url_lower:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('mimetype', 'application/x-mpegURL')
            li.setProperty('inputstream.adaptive.live_delay', '4')
        else:
            li.setMimeType('application/x-mpegURL')
    elif url_lower.endswith('.mp4') or url_lower.endswith('.mkv'):
        li.setMimeType('video/mp4')
    else:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('mimetype', 'video/mp2t')
            li.setProperty('inputstream.ffmpegdirect.read_chunk_size', '524288')
            li.setProperty('network.buffer_factor', '8.0')
        else:
            li.setMimeType('video/mp2t')

    li.setProperty('network.curlcachebytes', '33554432')  # 32 MB
    li.setProperty('network.bandwidth',      '0')
    li.setProperty('network.readtimeout',    '90')
    li.setProperty('network.connecttimeout', '15')

    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video', 'playcount': 0, 'overlay': 0})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super(OnTVPlayer, self).__init__()
        self._tempo_inicio  = 0.0
        self._rapidos       = 0      # contador de falhas rápidas consecutivas
        self._a_reiniciar   = False

    def onPlayBackStarted(self):
        agora = time.time()
        # Se o stream anterior correu mais de _JANELA_RAPIDA segundos,
        # o novo arranque é considerado limpo — reset do contador de falhas rápidas
        if (agora - self._tempo_inicio) > _JANELA_RAPIDA:
            self._rapidos = 0
        self._tempo_inicio = agora
        self._a_reiniciar  = False
        _remover_stop_flag()
        log('Stream iniciado (falhas rápidas acumuladas: {})'.format(self._rapidos))

    def onPlayBackStopped(self):
        """Utilizador parou manualmente — nunca reiniciar."""
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._rapidos     = 0
        self._a_reiniciar = False
        _criar_stop_flag()

    def onPlayBackEnded(self):
        """EOF — servidor fechou ligação (token expirado, corte, fim de VOD)."""
        if _utilizador_parou():
            return
        xbmc.sleep(_ESPERA_EOF)
        self._reiniciar('EOF')

    def onPlayBackError(self):
        """Erro de rede ou codec."""
        if _utilizador_parou():
            return
        xbmc.sleep(_ESPERA_ERRO)
        self._reiniciar('Erro')

    def _reiniciar(self, motivo):
        if self._a_reiniciar:
            return
        if _utilizador_parou():
            return

        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            log('Reinício cancelado — sem info de stream')
            return

        duracao = time.time() - self._tempo_inicio

        # Contar falha como "rápida" se o stream correu menos de _JANELA_RAPIDA s
        if duracao < _JANELA_RAPIDA:
            self._rapidos += 1
        else:
            # Correu bem durante bastante tempo — não conta como falha rápida
            self._rapidos = 0

        if self._rapidos > _MAX_RAPIDOS:
            log('{} — {} falhas rápidas consecutivas, a desistir'.format(
                motivo, self._rapidos), xbmc.LOGWARNING)
            self._rapidos = 0
            return

        self._a_reiniciar = True
        log('{} em {:.0f}s — a reiniciar (falhas rápidas: {}/{})'.format(
            motivo, duracao, self._rapidos, _MAX_RAPIDOS))

        url  = info.get('url', '')
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        self.play(url, _fazer_listitem(url, nome, logo))
        self._a_reiniciar = False


def run():
    log('Serviço iniciado')

    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    # Limpar flags de sessões anteriores
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass

    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(5)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
