# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background  v1.0.2

O serviço NÃO reinicia streams automaticamente.
O Kodi tem recuperação nativa de rede e buffer próprio — interferir com
self.play() causa o flash/reabrir visual que perturba o utilizador.
O serviço limita-se a:
  - Invalidar a cache de servidores ao arrancar (força refresh na próxima abertura)
  - Limpar ficheiros temporários de sessões anteriores
"""

import xbmc
import xbmcaddon
import os
import xbmcvfs

ADDON     = xbmcaddon.Addon()
STOP_FILE = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def _limpar_ficheiros_temp():
    for f in (STOP_FILE, STREAM_FILE):
        try:
            if os.path.exists(f):
                os.remove(f)
        except Exception:
            pass


def run():
    log('Serviço iniciado')

    # Forçar actualização dos servidores na próxima abertura do addon
    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    # Limpar flags de sessões anteriores
    _limpar_ficheiros_temp()

    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        monitor.waitForAbort(10)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
