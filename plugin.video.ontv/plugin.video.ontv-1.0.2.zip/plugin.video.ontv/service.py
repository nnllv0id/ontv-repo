# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background  v1.0.2

Dois modos de recuperação:
  1. Travamento/lentidão (erro em <5s ou getTime()==0 logo após erro)
     → tenta retomar silenciosamente sem reabrir o canal
  2. Corte real do servidor / token expirado (EOF após vários segundos de stream)
     → reinicia reabrindo o canal (self.play)

Nunca actua quando o utilizador para manualmente.
"""

import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import time
import xbmcvfs

ADDON       = xbmcaddon.Addon()
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')
STOP_FILE   = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')

# ── Limiares de decisão ───────────────────────────────────────────────────
# Se o stream correu menos de _LIMIAR_CORTE_REAL segundos antes de parar,
# trata-se de travamento/buffering — tenta recuperar silenciosamente.
# Se correu mais, é um corte real (EOF do servidor) — reabre o canal.
_LIMIAR_CORTE_REAL = 8      # segundos; abaixo → travamento, acima → corte real

# Máximo de reaberturas reais consecutivas antes de desistir
# (protege contra canais completamente mortos)
_MAX_REABERT       = 5

# Máximo de tentativas silenciosas consecutivas antes de tentar reabrir
_MAX_SILENCIOSAS   = 3

_ESPERA_SILENCIOSA = 1500   # ms antes de tentar recuperação silenciosa
_ESPERA_REABRIR    = 2000   # ms antes de reabrir o canal


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def _utilizador_parou():
    return os.path.exists(STOP_FILE)


def _criar_stop_flag():
    try:
        with open(STOP_FILE, 'w') as f:
            f.write('1')
    except Exception:
        pass


def _remover_stop_flag():
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
    except Exception:
        pass


def _fazer_listitem(url, nome, logo):
    """ListItem para reabrir o canal (recuperação completa)."""
    url_lower = url.lower().split('?')[0]
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url_lower:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('mimetype', 'application/x-mpegURL')
            li.setProperty('inputstream.adaptive.live_delay', '4')
        else:
            li.setMimeType('application/x-mpegURL')
    elif url_lower.endswith('.mp4') or url_lower.endswith('.mkv'):
        li.setMimeType('video/mp4')
    else:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('mimetype', 'video/mp2t')
            li.setProperty('inputstream.ffmpegdirect.read_chunk_size', '524288')
            li.setProperty('network.buffer_factor', '8.0')
        else:
            li.setMimeType('video/mp2t')

    li.setProperty('network.curlcachebytes', '33554432')
    li.setProperty('network.bandwidth',      '0')
    li.setProperty('network.readtimeout',    '90')
    li.setProperty('network.connecttimeout', '15')

    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video', 'playcount': 0, 'overlay': 0})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super(OnTVPlayer, self).__init__()
        self._tempo_inicio   = 0.0
        self._silenciosas    = 0   # tentativas silenciosas consecutivas
        self._reabert        = 0   # reaberturas completas consecutivas
        self._a_actuar       = False

    def _reset(self):
        self._silenciosas = 0
        self._reabert     = 0
        self._a_actuar    = False

    def onPlayBackStarted(self):
        self._tempo_inicio = time.time()
        self._a_actuar     = False
        # Reset dos contadores: novo arranque limpo
        self._silenciosas  = 0
        self._reabert      = 0
        _remover_stop_flag()
        log('Stream iniciado')

    def onPlayBackStopped(self):
        """Utilizador parou manualmente — nunca actuar."""
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._reset()
        _criar_stop_flag()

    def onPlayBackEnded(self):
        """
        EOF limpo — o servidor fechou a ligação correctamente.
        Quase sempre é um corte real (token expirado, servidor caiu).
        Raramente é travamento — o Kodi não reporta EOF em buffering,
        reporta Error. Por isso EOF → sempre reabrir.
        """
        if _utilizador_parou():
            return
        duracao = time.time() - self._tempo_inicio
        xbmc.sleep(_ESPERA_REABRIR)
        log('EOF em {:.0f}s → reabrir'.format(duracao))
        self._reabrir('EOF')

    def onPlayBackError(self):
        """
        Erro de rede ou codec.
        Distingue travamento (stream correu poucos segundos ou zero)
        de corte real (stream correu bastante tempo).
        """
        if _utilizador_parou():
            return

        duracao = time.time() - self._tempo_inicio

        if duracao < _LIMIAR_CORTE_REAL:
            # Erro muito rápido — provavelmente travamento/buffering
            xbmc.sleep(_ESPERA_SILENCIOSA)
            log('Erro em {:.1f}s (< {}s) → recuperação silenciosa'.format(
                duracao, _LIMIAR_CORTE_REAL))
            self._recuperar_silencioso()
        else:
            # Erro após bastante tempo — corte real do servidor
            xbmc.sleep(_ESPERA_REABRIR)
            log('Erro em {:.0f}s (>= {}s) → reabrir'.format(
                duracao, _LIMIAR_CORTE_REAL))
            self._reabrir('Erro')

    # ── Recuperação silenciosa (sem reabrir o canal) ──────────────────────

    def _recuperar_silencioso(self):
        """
        Tenta retomar a reprodução sem reabrir o canal visualmente.
        Usa executebuiltin('PlayerControl(Play)') para forçar o Kodi
        a tentar reconectar ao stream sem destruir o player actual.
        Se falhar _MAX_SILENCIOSAS vezes consecutivas, escala para reabrir.
        """
        if self._a_actuar:
            return
        if _utilizador_parou():
            return

        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            return

        self._silenciosas += 1

        if self._silenciosas > _MAX_SILENCIOSAS:
            log('Silenciosas esgotadas ({}) → a escalar para reabrir'.format(
                self._silenciosas))
            self._silenciosas = 0
            self._reabrir('Erro (escalonado)')
            return

        self._a_actuar = True
        log('Recuperação silenciosa {}/{}'.format(self._silenciosas, _MAX_SILENCIOSAS))

        # Tentar retomar via PlayerControl — não reabre o canal
        xbmc.executebuiltin('PlayerControl(Play)')
        # Dar tempo ao Kodi para tentar reconectar
        xbmc.sleep(3000)

        # Verificar se retomou
        if self.isPlaying():
            log('Recuperação silenciosa bem-sucedida')
            self._silenciosas = 0
        else:
            log('Recuperação silenciosa falhou — o Kodi não retomou')
            # onPlayBackError ou onPlayBackEnded voltará a disparar se necessário

        self._a_actuar = False

    # ── Reabrir o canal completamente ─────────────────────────────────────

    def _reabrir(self, motivo):
        """
        Reabre o canal com self.play() — causa o flash visual mas é necessário
        para cortes reais do servidor (token expirado, EOF, etc.).
        """
        if self._a_actuar:
            return
        if _utilizador_parou():
            return

        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            log('Reabrir cancelado — sem info de stream')
            return

        self._reabert += 1
        if self._reabert > _MAX_REABERT:
            log('{} — {} reaberturas consecutivas, a desistir'.format(
                motivo, self._reabert), xbmc.LOGWARNING)
            self._reabert = 0
            return

        self._a_actuar = True
        log('{} → reabrir canal (tentativa {}/{})'.format(
            motivo, self._reabert, _MAX_REABERT))

        url  = info.get('url', '')
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        self.play(url, _fazer_listitem(url, nome, logo))
        self._a_actuar = False


def run():
    log('Serviço iniciado')

    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass

    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(5)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
