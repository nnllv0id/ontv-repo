# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background  v1.0.2
"""

import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import time
import xbmcvfs

ADDON       = xbmcaddon.Addon()
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')
STOP_FILE   = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')

# ── Backoff: quanto esperar em cada tentativa consecutiva ─────────────────
# 3 tentativas máximo; se o stream correu menos de _JANELA_ESTAVEL segundos
# entre reinícios consecutivos, os contadores NÃO fazem reset.
_BACKOFF          = [2.0, 5.0, 15.0]   # segundos de espera por tentativa
_JANELA_ESTAVEL   = 120                 # stream "estável" se correu +2 min sem erro


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


# ── Helpers de ficheiros temporários ──────────────────────────────────────

def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def _utilizador_parou():
    return os.path.exists(STOP_FILE)


def _criar_stop_flag():
    try:
        with open(STOP_FILE, 'w') as f:
            f.write('1')
    except Exception:
        pass


def _remover_stop_flag():
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
    except Exception:
        pass


# ── Construção do ListItem para reinício ──────────────────────────────────

def _fazer_listitem(url, nome, logo):
    """
    Cria um ListItem para reinício do stream.
    Usa os mesmos inputstreams que o navigator — com fallback para dispositivos
    que não tenham inputstream.adaptive / inputstream.ffmpegdirect instalados.
    Inclui propriedades de buffer para absorver picos de rede.
    """
    url_lower = url.lower().split('?')[0]
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')

    if '.m3u8' in url_lower:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setProperty('mimetype', 'application/x-mpegURL')
        else:
            li.setMimeType('application/x-mpegURL')
    elif url_lower.endswith('.mp4') or url_lower.endswith('.mkv'):
        li.setMimeType('video/mp4')
    else:
        if xbmc.getCondVisibility('System.HasAddon(inputstream.ffmpegdirect)'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('mimetype', 'video/mp2t')
            li.setProperty('inputstream.ffmpegdirect.read_chunk_size', '131072')
            li.setProperty('network.buffer_factor', '4.0')
        else:
            li.setMimeType('video/mp2t')

    # Buffer de rede — 20 MB para absorver picos sem interrupção visível
    li.setProperty('network.curlcachebytes', '20971520')
    li.setProperty('network.bandwidth',      '0')
    li.setProperty('network.readtimeout',    '60')
    li.setProperty('network.connecttimeout', '10')

    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video', 'playcount': 0, 'overlay': 0})
    return li


# ── Player com lógica de reinício controlada ──────────────────────────────

class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super(OnTVPlayer, self).__init__()
        self._reset_completo()

    def _reset_completo(self):
        """Reset total — chamado ao parar manualmente ou ao arrancar o serviço."""
        self._tempo_inicio   = 0.0
        self._ultimo_erro    = 0.0   # timestamp do último erro/EOF
        self._tentativa      = 0     # contador de reinícios consecutivos
        self._a_reiniciar    = False

    def _reset_se_estavel(self):
        """
        Se o stream correu mais de _JANELA_ESTAVEL segundos desde o último
        erro, considera-se estável e reseta o contador de tentativas.
        Isto evita que um canal instável que falha a cada 2 min nunca atinja
        o limite, mas permite reinício limpo de streams que funcionam bem.
        """
        agora = time.time()
        if self._ultimo_erro > 0 and (agora - self._ultimo_erro) > _JANELA_ESTAVEL:
            log('Stream estável por {}s — reset de contadores'.format(int(agora - self._ultimo_erro)))
            self._tentativa = 0
        # Se nunca houve erro nesta sessão e o stream correu bastante tempo, reset também
        elif self._ultimo_erro == 0 and (agora - self._tempo_inicio) > _JANELA_ESTAVEL:
            self._tentativa = 0

    def onPlayBackStarted(self):
        self._tempo_inicio = time.time()
        self._a_reiniciar  = False
        # NÃO reseta _tentativa aqui — só reseta em _reset_se_estavel
        # para não perder o histórico de falhas rápidas
        _remover_stop_flag()
        log('Stream iniciado (tentativa acumulada: {})'.format(self._tentativa))

    def onPlayBackStopped(self):
        """Utilizador parou manualmente — bloquear qualquer reinício."""
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._reset_completo()
        _criar_stop_flag()

    def onPlayBackEnded(self):
        """
        EOF — servidor fechou ligação.
        Pode ser: fim de VOD, corte do servidor, ou token Stalker expirado.
        """
        if _utilizador_parou():
            log('EOF ignorado — utilizador parou')
            return
        self._ultimo_erro = time.time()
        xbmc.sleep(1500)
        self._tentar_reiniciar('EOF')

    def onPlayBackError(self):
        """Erro de rede, codec ou token inválido."""
        if _utilizador_parou():
            log('Erro ignorado — utilizador parou')
            return
        self._ultimo_erro = time.time()
        xbmc.sleep(2500)
        self._tentar_reiniciar('Erro')

    def _tentar_reiniciar(self, motivo):
        """
        Reinicia o stream com backoff progressivo.

        Lógica de contadores:
          - Se os erros ocorrem rapidamente (stream instável), a tentativa
            sobe e o backoff aumenta, até desistir ao fim de _BACKOFF tentativas.
          - Se entre erros passou mais de _JANELA_ESTAVEL segundos, reset.
          - O utilizador pode sempre parar manualmente; a stop_flag é verificada
            antes e depois da espera.
        """
        if self._a_reiniciar:
            return
        if _utilizador_parou():
            return

        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            log('Reinício cancelado — sem info de stream')
            return

        # Verificar se o stream estava estável antes deste erro
        self._reset_se_estavel()

        if self._tentativa >= len(_BACKOFF):
            log('{} — desistindo após {} tentativas consecutivas'.format(
                motivo, len(_BACKOFF)), xbmc.LOGWARNING)
            # Reset para a próxima vez que o utilizador abrir um canal
            self._tentativa = 0
            return

        espera = _BACKOFF[self._tentativa]
        self._tentativa += 1
        self._a_reiniciar = True
        duracao = time.time() - self._tempo_inicio

        log('{} ({:.0f}s de stream) — tentativa {}/{}, esperar {:.0f}s'.format(
            motivo, duracao, self._tentativa, len(_BACKOFF), espera))

        xbmc.sleep(int(espera * 1000))

        if _utilizador_parou():
            log('Reinício cancelado durante espera — utilizador parou')
            self._a_reiniciar = False
            return

        url  = info.get('url', '')
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        log('A reiniciar: ' + nome)
        self.play(url, _fazer_listitem(url, nome, logo))
        self._a_reiniciar = False


# ── Loop principal do serviço ─────────────────────────────────────────────

def run():
    log('Serviço iniciado')

    # Forçar actualização dos servidores na próxima abertura do addon
    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    # Limpar flags de sessões anteriores
    _remover_stop_flag()
    limpar_stream()

    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(5)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
