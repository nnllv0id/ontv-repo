# -*- coding: utf-8 -*-
# OnTV — servico de background
#
#  - Hospeda o motor de streaming local (proxy) num processo sempre vivo
#  - Watchdog do proxy
#  - Liberta a ligacao ao servidor assim que a reproducao pára (contas de 1 ligacao)
#  - Fallback automatico para reproducao directa se o proxy falhar no arranque do canal
#  - Restaura DNS, migra favoritos, limpa caches antigas

import os
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
_LIB = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'lib')
if _LIB not in sys.path:
    sys.path.insert(0, _LIB)

import common
import proxy

PROP_LAST = 'ontv.last_play'      # JSON do ultimo pedido de reproducao (para o fallback)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def _activar_dns():
    """Restaura o DNS escolhido (ficheiro no perfil; le tambem o local antigo em temp)."""
    try:
        provider = ''
        for p in (os.path.join(common.profile_dir(), 'ontv_dns_provider.txt'),
                  os.path.join(common.temp_dir(), 'ontv_dns_provider.txt')):
            if os.path.exists(p):
                with open(p, 'r') as f:
                    provider = f.read().strip()
                break
        if provider and provider != 'sistema':
            import dns_override
            dns_override.activate(provider)
            log('DNS activado: ' + provider)
    except Exception as e:
        log('Aviso DNS: ' + str(e), xbmc.LOGWARNING)


def _manutencao():
    try:
        import favourites
        favourites.migrar_antigo()
    except Exception as e:
        log('Aviso favoritos: ' + str(e), xbmc.LOGWARNING)
    try:
        common.cache_prune()
    except Exception as e:
        log('Aviso cache: ' + str(e), xbmc.LOGWARNING)
    try:
        from mediacfg import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso servidores: ' + str(e), xbmc.LOGWARNING)


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self._t_start = 0
        self._via_proxy = False
        self._retried = False

    def _is_ours(self):
        try:
            f = self.getPlayingFile()
        except Exception:
            return False
        self._via_proxy = f.startswith('http://127.0.0.1:') and ('/live.' in f or '/vod.' in f)
        return self._via_proxy

    def onAVStarted(self):
        self._t_start = time.time()
        self._is_ours()

    def onPlayBackStarted(self):
        self._t_start = time.time()
        self._retried = False

    def _libertar(self):
        # So cancela ligacoes com mais de 2s: protege um canal novo que acabou de arrancar
        proxy.cancel_all(older_than=time.time() - 2.0)
        t = threading.Timer(3.0, lambda: proxy.cancel_all(older_than=time.time() - 2.0))
        t.daemon = True
        t.start()

    def onPlayBackStopped(self):
        self._libertar()

    def onPlayBackEnded(self):
        self._libertar()

    def onPlayBackError(self):
        log('Erro de reproducao reportado pelo Kodi', xbmc.LOGWARNING)
        self._libertar()
        self._fallback()

    def _fallback(self):
        """Se o proxy falhou, tenta 1x reproduzir directamente (so no motor Auto)."""
        if self._retried or common.setting_int('engine', 0) != 0:
            self._aviso()
            return
        self._retried = True
        try:
            import json
            raw = xbmcgui.Window(10000).getProperty(PROP_LAST)
            if not raw:
                return self._aviso()
            d = json.loads(raw)
            if d.get('engine') != 'proxy' or d.get('kind') != 'live':
                return self._aviso()
            import playback
            path, li, eng = playback.build(d['url'], d.get('nome', ''), d.get('logo', ''),
                                           kind='live', headers=d.get('h'), engine='direct')
            log('Fallback: proxy falhou — a tentar reproducao directa')
            xbmcgui.Dialog().notification('OnTV', 'A tentar ligacao directa…',
                                          xbmcgui.NOTIFICATION_INFO, 2500)
            self.play(path, li)
        except Exception as e:
            log('Fallback falhou: ' + str(e), xbmc.LOGWARNING)

    def _aviso(self):
        xbmcgui.Dialog().notification(
            'OnTV', 'Falha ao reproduzir. Experimente outro motor em Definições › Reprodução.',
            xbmcgui.NOTIFICATION_WARNING, 5000)


class OnTVMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        log('Definicoes alteradas')


def run():
    log('Servico iniciado (RAM={}MB, perfil={})'.format(common.ram_mb(), common.device_tier()))
    monitor = OnTVMonitor()
    _activar_dns()
    port = proxy.start_server()
    log('Proxy na porta {}'.format(port))
    threading.Thread(target=_manutencao, daemon=True).start()
    player = OnTVPlayer()                                   # manter referencia viva

    n = 0
    while not monitor.waitForAbort(5):
        n += 1
        if not proxy._alive(proxy.get_port()):
            log('Proxy nao responde — a reiniciar', xbmc.LOGWARNING)
            proxy.stop_server()
            port = proxy.start_server()
        if n % 720 == 0:                                    # ~1h
            try:
                common.cache_prune()
            except Exception:
                pass

    proxy.stop_server()
    log('Servico terminado')


if __name__ == '__main__':
    run()
