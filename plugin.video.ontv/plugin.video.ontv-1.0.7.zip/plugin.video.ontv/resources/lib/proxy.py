# -*- coding: utf-8 -*-
# Proxy fiel ao f4mTester 1.0.3 server.py
# Correcoes: get_headers() actualiza GLOBAL_HEADERS, prepare_url() converte |,
# _serve_ts() faz break apos ligacao bem sucedida (identico ao f4mTester),
# _serve_m3u8() trata chunklist_ e media_ e /hl relativo

import threading
import time

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

try:
    from http.server  import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

try:
    from urllib.request import urlopen, Request as URequest
except ImportError:
    from urllib2 import urlopen, Request as URequest

HOST        = '127.0.0.1'
PORT        = 52315
CHUNK_SIZE  = 300000   # identico ao f4mTester

UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/120.0.0.0 Safari/537.36')

_lock      = threading.Lock()
_stop_flag = False
_cur_url   = ''

GLOBAL_HEADERS = {'User-Agent': UA, 'Connection': 'keep-alive'}
GLOBAL_URL     = ''
HTTPS_PORT     = False


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _cur_url
    with _lock:
        _cur_url = url

def _get_url():
    with _lock:
        return _cur_url


def _is_m3u8_url(url):
    return '.m3u8' in url or ('/hl' in url and not url.endswith('.ts'))


def _basename(p):
    i = p.rfind('/') + 1
    return p[i:]


def get_headers(url):
    """
    Identico ao get_headers() do f4mTester 1.0.3.
    Extrai Referer, Origin, Cookie, User-Agent do URL inline
    e actualiza o GLOBAL_HEADERS global.
    """
    global GLOBAL_HEADERS
    try:
        url = url.split('url=')[1]
    except Exception:
        pass
    data = {'User-Agent': UA, 'Connection': 'keep-alive'}
    if '|' in url or '&' in url or 'h123' in url:
        def _extract(key):
            try:
                val = url.split(key + '=')[1]
                try:
                    val = val.split('&')[0]
                except Exception:
                    pass
                return unquote_plus(val)
            except Exception:
                return None
        referer    = _extract('Referer')
        origin     = _extract('Origin')
        cookie     = _extract('Cookie')
        user_agent = _extract('User-Agent')
        if referer:
            data['Referer'] = referer
        if origin:
            data['Origin'] = origin
        if cookie:
            data['Cookie'] = cookie
        if user_agent:
            data['User-Agent'] = user_agent
        if referer or origin or cookie:
            GLOBAL_HEADERS = data
    if not GLOBAL_HEADERS:
        GLOBAL_HEADERS = data


def convert_to_m3u8(url):
    """Identico ao f4mTester 1.0.3 convert_to_m3u8()."""
    if '|' in url:
        url = url.split('|')[0]
    elif '&h123' in url:
        url = url.split('&h123')[0]
    if not '.m3u8' in url and not '/hl' in url             and url.count(':') == 2 and url.count('/') > 4:
        try:
            parsed = urlparse(url)
            host1  = '{}://{}'.format(parsed.scheme, parsed.netloc)
            host2  = url.split(host1)[1]
            url    = host1 + '/live' + host2
            fname  = _basename(url)
            if '.ts' in fname:
                url = url.replace(fname, fname.replace('.ts', '.m3u8'))
            else:
                url = url.replace(fname, fname + '.m3u8')
        except Exception:
            pass
    return url


def prepare_url(url):
    """
    Identico ao prepare_url() do f4mTester 1.0.3.
    Converte | para &h123=true& antes de encodar —
    garante que headers inline sao sempre interpretados correctamente.
    """
    try:
        url = unquote_plus(url)
    except Exception:
        pass
    try:
        url = unquote(url)
    except Exception:
        pass
    url = url.replace('|', '&h123=true&')
    url = quote_plus(url)
    return 'http://{}:{}/?url={}'.format(HOST, PORT, url)


def _renovar_stalker_url():
    """
    Renova o link Stalker/MAC apenas quando o servidor recusa (401/403/404).
    Zero overhead — so e chamada quando necessario.
    """
    try:
        import json as _json, os as _os
        try:
            import xbmcvfs as _xv
            sfile = _xv.translatePath('special://temp/ontv_stalker_stream.json')
        except Exception:
            import tempfile
            sfile = _os.path.join(tempfile.gettempdir(), 'ontv_stalker_stream.json')
        if not _os.path.exists(sfile):
            return None
        with open(sfile, 'r', encoding='utf-8') as f:
            info = _json.load(f)
        if info.get('tipo') != 'stalker':
            return None
        import sys
        _lib = _os.path.dirname(__file__)
        if _lib not in sys.path:
            sys.path.insert(0, _lib)
        from navigator import stalker_create_link
        new_url = stalker_create_link(
            info['host'], info['mac'],
            info['stalker_tipo'], info['cmd']
        )
        if new_url and new_url.startswith('http'):
            _set_url(new_url)
            return new_url
    except Exception:
        pass
    return None


class _Handler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _parse_url(self):
        try:
            raw = self.path.split('url=')[1]
            try:
                return unquote_plus(raw)
            except Exception:
                return unquote(raw)
        except Exception:
            return ''

    def do_HEAD(self):
        self._route('HEAD')

    def do_GET(self):
        self._route('GET')

    def _route(self, method):
        global GLOBAL_HEADERS, HTTPS_PORT, STOP_SERVER
        if _is_stopped() or STOP_SERVER:
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown)
            t.daemon = True; t.start()
            return

        url = self._parse_url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        # Actualizar GLOBAL_HEADERS com headers inline do URL
        if not GLOBAL_HEADERS or GLOBAL_HEADERS == {'User-Agent': UA, 'Connection': 'keep-alive'}:
            get_headers(url)

        # Converter para m3u8 — identico ao f4mTester
        url = convert_to_m3u8(url)

        if ':443' in url or url.startswith('https://'):
            HTTPS_PORT = True

        if _is_m3u8_url(url):
            self._serve_m3u8(url, method)
        else:
            self._serve_ts(url, method)

    def _serve_m3u8(self, url, method):
        """Identico ao m3u8() do f4mTester 1.0.3."""
        global GLOBAL_URL, HTTPS_PORT

        for i in range(20):
            if _is_stopped(): break
            try:
                if HAS_REQUESTS:
                    r        = requests.get(url, headers=GLOBAL_HEADERS,
                                            timeout=4, verify=False)
                    last_url = r.url
                    text_    = r.text
                    status   = r.status_code
                    r.close()
                else:
                    resp     = urlopen(URequest(url, headers=GLOBAL_HEADERS), timeout=4)
                    last_url = url
                    text_    = resp.read().decode('utf-8', errors='replace')
                    status   = resp.status
                    resp.close()

                r_parse  = urlparse(last_url)
                if HTTPS_PORT:
                    base_url = 'https://' + r_parse.netloc
                else:
                    base_url = 'http://' + r_parse.netloc

                if status == 200:
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.end_headers()
                    if method != 'HEAD':
                        proxy_base = 'http://{}:{}'.format(HOST, PORT)
                        # Reescrita identica ao f4mTester — todos os casos
                        if '.html' in text_ and 'http' in text_:
                            text_ = text_.replace('http', proxy_base + '/?url=http')
                        elif 'chunklist_' in text_ and 'http' not in text_:
                            fname    = _basename(url)
                            base_url2 = url.replace(fname, '').rstrip('/')
                            text_ = text_.replace('chunklist_', proxy_base + '/?url=' + base_url2 + '/chunklist_')
                        elif 'media_' in text_ and '.ts' in text_ and 'http' not in text_:
                            fname    = _basename(url)
                            base_url2 = url.replace(fname, '').rstrip('/')
                            text_ = text_.replace('media_', proxy_base + '/?url=' + base_url2 + '/media_')
                        elif '/hl' in text_ and 'http' not in text_:
                            text_ = text_.replace('/hl', proxy_base + '/?url=' + base_url + '/hl')
                        else:
                            text_ = text_.replace('http', proxy_base + '/?url=http')
                        self.wfile.write(text_.encode('utf-8'))
                    return
                break

            except Exception:
                pass

            if _is_stopped(): break
            time.sleep(3)

            if i == 7:
                try:
                    self.send_response(404); self.end_headers()
                except Exception:
                    pass
                return

    def _serve_ts(self, url, method):
        """
        Identico ao ts() do f4mTester 1.0.3.
        CRITICO: faz break apos ligacao bem sucedida — nao reconecta
        internamente. Deixa o Kodi gerir a reconexao via o proxy.
        """
        for i in range(30):
            if _is_stopped(): break
            try:
                if HAS_REQUESTS:
                    r = requests.get(url, headers=GLOBAL_HEADERS,
                                     stream=True, verify=False)
                    if r.status_code in (401, 403, 404):
                        r.close()
                        renewed = _renovar_stalker_url()
                        if renewed:
                            url = renewed
                        continue
                    if r.status_code == 200:
                        self.send_response(200)
                        self.send_header('Content-type', 'video/mp2t')
                        self.end_headers()
                        if method != 'HEAD':
                            for chunk in r.iter_content(CHUNK_SIZE):
                                if _is_stopped():
                                    break
                                try:
                                    self.wfile.write(chunk)
                                except Exception:
                                    break
                    r.close()
                    break   # IDENTICO AO F4MTESTER: break apos ligacao bem sucedida
                else:
                    import socket
                    resp = urlopen(URequest(url, headers=GLOBAL_HEADERS), timeout=10)
                    try:
                        resp.fp.raw._sock.settimeout(8)
                    except Exception:
                        pass
                    if resp.status == 200:
                        self.send_response(200)
                        self.send_header('Content-type', 'video/mp2t')
                        self.end_headers()
                        if method != 'HEAD':
                            while not _is_stopped():
                                try:
                                    chunk = resp.read(CHUNK_SIZE)
                                except Exception:
                                    break
                                if not chunk:
                                    break
                                try:
                                    self.wfile.write(chunk)
                                except Exception:
                                    break
                    resp.close()
                    break   # break identico ao f4mTester

            except Exception:
                pass

            if _is_stopped(): break

            if i == 14:
                try:
                    self.send_response(404); self.end_headers()
                except Exception:
                    pass
                return


# ── Gestao do servidor ─────────────────────────────────────────────────────

_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def in_use():
    """Identico ao in_use() do f4mTester."""
    try:
        if HAS_REQUESTS:
            r = requests.head('http://{}:{}/check'.format(HOST, PORT), timeout=1)
            return r.status_code == 200
        else:
            resp = urlopen(URequest('http://{}:{}/check'.format(HOST, PORT)), timeout=1)
            resp.close()
            return True
    except Exception:
        return False


def start(url):
    global _server_instance, _server_thread, GLOBAL_HEADERS
    _set_stop(False)
    _set_url(url)
    GLOBAL_HEADERS = {'User-Agent': UA, 'Connection': 'keep-alive'}
    get_headers(url)

    if in_use():
        return prepare_url(url)

    if _server_thread and _server_thread.is_alive():
        return prepare_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _Handler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _Handler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    # Identico ao f4mTester mediaserver.start() — aguardar 4 segundos
    time.sleep(4)

    return prepare_url(url)


def _req_shutdown():
    """Identico ao req_shutdown() do f4mTester."""
    try:
        if HAS_REQUESTS:
            r = requests.get('http://{}:{}/stop'.format(HOST, PORT), timeout=2)
            r.close()
        else:
            resp = urlopen(URequest('http://{}:{}/stop'.format(HOST, PORT)), timeout=2)
            resp.close()
    except Exception:
        pass


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    t = threading.Thread(target=_req_shutdown)
    t.daemon = True; t.start(); t.join(timeout=3)
    try:
        if _server_instance:
            _server_instance.shutdown()
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        if HAS_REQUESTS:
            r = requests.get('http://{}:{}/check'.format(HOST, PORT), timeout=2)
            return r.status_code == 200
        else:
            resp = urlopen(URequest('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
            resp.close()
            return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)


def _make_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
