# -*- coding: utf-8 -*-
"""
OnTV — decisao do motor de reproducao e construcao do ListItem.

Motores:
  proxy         proxy local do addon (reconexao, buffer, HLS->TS, Range)
  direct        Kodi nativo (FFmpeg) — ideal para VOD (seek) e protocolos nao-HTTP
  ffmpegdirect  inputstream.ffmpegdirect (reconexao nativa + timeshift), se instalado

Usado pelo navigator (setResolvedUrl) e pelo servico (fallback automatico).
"""

import re
from urllib.parse import urlsplit, quote

import common
from common import log, log_warn, mascarar, setting_int

try:
    import xbmc
    import xbmcgui
    IN_KODI = True
except Exception:
    IN_KODI = False

_VOD_MIME = {
    'mp4': 'video/mp4', 'm4v': 'video/mp4', 'mkv': 'video/x-matroska',
    'avi': 'video/x-msvideo', 'mov': 'video/quicktime', 'ts': 'video/mp2t',
    'mpg': 'video/mpeg', 'mpeg': 'video/mpeg', 'flv': 'video/x-flv', 'wmv': 'video/x-ms-wmv',
}
_VOD_EXT = tuple('.' + e for e in ('mp4', 'm4v', 'mkv', 'avi', 'mov', 'mpg', 'mpeg', 'flv', 'wmv'))


def split_pipe(url):
    """'url|User-Agent=x&Referer=y' -> (url, {headers})."""
    if '|' not in url:
        return url, {}
    base, _, rest = url.partition('|')
    hdr = {}
    from urllib.parse import unquote_plus
    for kv in rest.split('&'):
        k, _, v = kv.partition('=')
        if k:
            hdr[k] = unquote_plus(v)
    return base, hdr


def join_pipe(url, headers):
    if not headers:
        return url
    return url + '|' + '&'.join('{}={}'.format(k, quote(str(v), safe='')) for k, v in headers.items())


def guess_kind(url):
    """'live' ou 'vod' a partir do URL (para itens antigos/favoritos sem tipo)."""
    p = urlsplit(url).path.lower()
    if '/movie/' in p or '/series/' in p or p.endswith(_VOD_EXT):
        return 'vod'
    return 'live'


def has_ffmpegdirect():
    if not IN_KODI:
        return False
    try:
        return bool(xbmc.getCondVisibility('System.AddonIsEnabled(inputstream.ffmpegdirect)'))
    except Exception:
        return False


def decide_engine(url, kind):
    """Devolve 'proxy' | 'direct' | 'ffmpegdirect'."""
    if not url.lower().startswith(('http://', 'https://')):
        return 'direct'                                    # rtmp/rtsp/udp/ficheiros locais
    pref = setting_int('engine', 0)                        # 0 auto 1 proxy 2 direto 3 ffmpegdirect
    if kind == 'vod':
        return 'proxy' if pref == 1 else 'direct'          # VOD: seek nativo do Kodi
    if pref == 2:
        return 'direct'
    if pref == 3:
        if has_ffmpegdirect():
            return 'ffmpegdirect'
        log_warn('ffmpegdirect nao instalado — a usar proxy')
        return 'proxy'
    return 'proxy'


def build(url, nome='', logo='', kind=None, headers=None, stalker=None, engine=None):
    """
    Prepara o item a reproduzir.
    Devolve (path, ListItem, engine_usado).
    """
    url, pipe_h = split_pipe(url)
    hdrs = dict(pipe_h)
    if headers:
        hdrs.update(headers)
    kind = kind or guess_kind(url)
    engine = engine or decide_engine(url, kind)

    path = url
    if engine == 'proxy':
        import proxy
        spec = {'u': url}
        if hdrs:
            spec['h'] = hdrs
        if kind == 'live':
            spec['f'] = {0: 'auto', 1: 'ts', 2: 'hls'}.get(setting_int('live_format', 0), 'auto')
        if stalker:
            spec['st'] = stalker
        purl = proxy.build_url(spec, kind)
        if purl:
            path = purl
        else:
            log_warn('Proxy indisponivel — reproducao directa')
            engine = 'direct'
    if engine in ('direct', 'ffmpegdirect'):
        path = common_join(url, hdrs)

    li = xbmcgui.ListItem(nome, path=path)
    icon = logo or ''
    li.setArt({'thumb': icon, 'icon': icon})
    common.set_video_info(li, title=nome, mediatype='movie' if kind == 'vod' else 'video')
    li.setProperty('IsPlayable', 'true')

    ext = urlsplit(url).path.rsplit('.', 1)[-1].lower() if '.' in urlsplit(url).path else ''
    if engine == 'proxy':
        if kind == 'live':
            li.setMimeType('video/mp2t')
        elif ext in _VOD_MIME:
            li.setMimeType(_VOD_MIME[ext])
        li.setContentLookup(False)
    elif engine == 'ffmpegdirect':
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true' if kind == 'live' else 'false')
        li.setProperty('inputstream.ffmpegdirect.stream_mode', 'timeshift' if kind == 'live' else 'default')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        if ext == 'm3u8':
            li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    else:                                                  # direct
        if kind == 'live':
            li.setMimeType('application/x-mpegURL' if ext == 'm3u8' else 'video/mp2t')
            li.setContentLookup(False)                     # evita 1 ligacao extra (contas de 1 ligacao)
        elif ext in _VOD_MIME:
            li.setMimeType(_VOD_MIME[ext])
            li.setContentLookup(False)
    log('Play [{}/{}] {}'.format(engine, kind, mascarar(url[:90])))
    return path, li, engine


def common_join(url, hdrs):
    return join_pipe(url, hdrs)
