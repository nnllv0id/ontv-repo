# -*- coding: utf-8 -*-
"""
OnTV
"""
import json
import os
import threading
import xbmcvfs


GIST_URL   = 'https://gist.githubusercontent.com/nnllv0id/a8bca35c256e0fcc73f41a58a125c044/raw/servers.json'
_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def _fetch_gist():
    import time
    from urllib.request import urlopen, Request
    # Adicionar timestamp ao URL para evitar cache HTTP do Kodi
    url = GIST_URL + '?t=' + str(int(time.time()))
    req = Request(url, headers={
        'User-Agent':     'Kodi/OnTV-Addon',
        'Cache-Control':  'no-cache, no-store, must-revalidate',
        'Pragma':         'no-cache',
        'Expires':        '0',
    })
    resp = urlopen(req, timeout=10)
    return json.loads(resp.read().decode('utf-8'))


def _actualizar_cache_background():
    def _fetch():
        try:
            servidores = _fetch_gist()
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(servidores, f)
            import xbmc
            xbmc.log('[OnTV] Cache de servidores actualizado', xbmc.LOGINFO)
        except Exception as e:
            import xbmc
            xbmc.log('[OnTV] Erro ao actualizar servidores: ' + str(e), xbmc.LOGWARNING)
    t = threading.Thread(target=_fetch)
    t.daemon = True
    t.start()


def carregar_servidores():
    """Tenta sempre o Gist primeiro — fallback para cache se falhar."""
    import xbmc
    try:
        servidores = _fetch_gist()
        try:
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(servidores, f)
        except Exception:
            pass
        xbmc.log('[OnTV] Servidores carregados do Gist ({})'.format(len(servidores)), xbmc.LOGINFO)
        return servidores
    except Exception as e:
        xbmc.log('[OnTV] Gist indisponível — a usar cache: ' + str(e), xbmc.LOGWARNING)
        servidores = _carregar_cache()
        if servidores:
            return servidores
        xbmc.log('[OnTV] Sem servidores disponíveis', xbmc.LOGERROR)
        return []


# Variável de módulo — só é None na primeira importação do processo Python
# Nas reimportações seguintes o Python reutiliza o módulo já em sys.modules
# e esta linha não é executada novamente
SERVIDORES = None

def obter_servidores():
    """Devolve servidores já carregados ou vai ao Gist se ainda não carregou."""
    global SERVIDORES
    if SERVIDORES is not None:
        return SERVIDORES
    SERVIDORES = carregar_servidores()
    return SERVIDORES
