# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════════════════╗
# ║              OnTV — Configuração dos Servidores                  ║
# ║                                                                  ║
# ║  TIPOS SUPORTADOS:                                               ║
# ║                                                                  ║
# ║  1) Xtream Codes:                                                ║
# ║     'tipo': 'xtream'                                             ║
# ║     'host', 'username', 'password'                               ║
# ║                                                                  ║
# ║  2) MAC / Stalker Portal:                                        ║
# ║     'tipo': 'stalker'                                            ║
# ║     'host'  → URL do portal  ex: http://servidor.com/c/         ║
# ║     'mac'   → MAC address    ex: 00:1A:79:XX:XX:XX              ║
# ║                                                                  ║
# ║  3) M3U por URL:                                                 ║
# ║     'tipo': 'm3u'                                                ║
# ║     'url'  → URL da lista M3U                                    ║
# ╚══════════════════════════════════════════════════════════════════╝

SERVIDORES = [

    # ── Xtream Codes - Exemplo Configuracao ─────────────────────────────────────────────────
    # {
    #    'nome':     'Servidor 1',
    #    'tipo':     'xtream',
    #    'host':     'http://vipfdedgevv.top:8080',
    #    'username': 'VIP011001752687394517',
    #    'password': '6574ccdc4d9d',
    #    'icon':     ''
    #},
    
    # ── MAC / Stalker Portal - Exemplo Configuracao  ──────────────────────────────────────────
    # {
    #    'nome': 'Servidor 4',
    #    'tipo': 'stalker',
    #    'host': 'http://line.tvdsz.cc/c/',
    #    'mac':  '00:1A:79:B6:29:A3',
    #},
    # ──────────────────────────────────────────────────────────────────────────────────────────
    # ──────────────────────────────────────────────────────────────────────────────────────────
    
    
    #EXPIRA: 29 outubro 2026
    {
        'nome': 'Servidor 1',
        'tipo': 'stalker',
        'host': 'http://owliptv.streamtv.to:8080/c',
        'mac':  '00:1A:79:C1:EF:58',
        'icon': ''
    },
    #EXPIRA: 10 abril 2026
    {
        'nome': 'Servidor 2',
        'tipo': 'stalker',
        'host': 'http://4kpro2.com:8789/c',
        'mac':  '00:1A:79:54:C5:2A',
        'icon': ''
    },
    #EXPIRA: 15 setembro 2026
    {
        'nome': 'Servidor 3',
        'tipo': 'stalker',
        'host': 'http://iptv-premium-ott.com:8789/c',
        'mac':  '00:1A:79:10:7E:53',
        'icon': ''
    },
    #EXPIRA: 5 janeiro 2027
    {
        'nome': 'Servidor 4',
        'tipo': 'stalker',
        'host': 'http://line.tvdsz.cc/c/',
        'mac':  '00:1A:79:B6:29:A3',
        'icon': ''
    },
    #EXPIRA: 30 outubro 2026
    {
        'nome': 'Servidor 5',
        'tipo': 'stalker',
        'host': 'http://iptvswiss.com.123tv.to:8080/c',
        'mac':  '00:1A:79:D5:D2:24',
        'icon': ''
    },
    #EXPIRA: 13 setembro 2026
    {
        'nome': 'Servidor 6',
        'tipo': 'stalker',
        'host': 'http://onfireboxtv.com/c',
        'mac':  '00:1A:79:85:2D:5E',
        'icon': ''
    },
    #EXPIRA: 7 agosto 2026
    {
        'nome': 'Servidor 7',
        'tipo': 'stalker',
        'host': 'http://glupiec.gnojek.pedal.123tv.to:8080/c',
        'mac':  '00:1A:79:AE:C3:FD',
        'icon': ''
    },
    #EXPIRA: 23 fevereiro 2027
    {
        'nome': 'Servidor 8',
        'tipo': 'stalker',
        'host': 'http://bsiptv.123tv.to:8080/c',
        'mac':  '00:1A:79:C3:44:B1',
        'icon': ''
    },
    #EXPIRA: 21 setembro 2026
    {
        'nome': 'Servidor 9',
        'tipo': 'stalker',
        'host': 'http://iptvswiss.com.123tv.to:8080/c',
        'mac':  '00:1A:79:AB:D3:D8',
        'icon': ''
    },
]
