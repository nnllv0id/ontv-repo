# -*- coding: utf-8 -*-
"""
OnTV — Configuração dos Servidores
"""
import json
import os
import xbmcvfs

# ─── Configuração ────────────────────────────────────────────────────────────
SERVERS_URL  = 'https://raw.githubusercontent.com/nnllv0id/ontv-servers/main/servers.json'

# Personal Access Token com permissão contents:read no repositório privado
# Cria em: GitHub → Settings → Developer settings → Personal access tokens → Fine-grained
GITHUB_TOKEN = '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'
# ─────────────────────────────────────────────────────────────────────────────

_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_remoto():
    try:
        from urllib.request import urlopen, Request
        headers = {
            'User-Agent':    'Kodi/OnTV-Addon',
            'Authorization': 'token ' + GITHUB_TOKEN,
            'Accept':        'application/vnd.github.v3.raw',
        }
        req  = Request(SERVERS_URL, headers=headers)
        resp = urlopen(req, timeout=10)
        data = resp.read().decode('utf-8')
        servidores = json.loads(data)
        try:
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                f.write(data)
        except Exception:
            pass
        return servidores
    except Exception as e:
        import xbmc
        xbmc.log('[OnTV] Erro ao carregar servers.json remoto: ' + str(e), xbmc.LOGWARNING)
        return None


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def carregar_servidores():
    import xbmc
    servidores = _carregar_remoto()
    if servidores:
        return servidores
    servidores = _carregar_cache()
    if servidores:
        xbmc.log('[OnTV] A usar cache local de servidores', xbmc.LOGWARNING)
        return servidores
    xbmc.log('[OnTV] Sem servidores disponíveis', xbmc.LOGERROR)
    return []


SERVIDORES = carregar_servidores()
