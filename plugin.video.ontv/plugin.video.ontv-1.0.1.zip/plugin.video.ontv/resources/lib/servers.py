# -*- coding: utf-8 -*-
"""
OnTV
"""
import json
import os
import threading
import xbmcvfs

GIST_URL    = 'https://gist.githubusercontent.com/nnllv0id/a8bca35c256e0fcc73f41a58a125c044/raw/servers.json'
_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def _fetch_gist():
    import time
    from urllib.request import urlopen, Request
    url = GIST_URL + '?t=' + str(int(time.time()))
    req = Request(url, headers={
        'User-Agent':    'Kodi/OnTV-Addon',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma':        'no-cache',
        'Expires':       '0',
    })
    resp = urlopen(req, timeout=10)
    return json.loads(resp.read().decode('utf-8'))


def carregar_servidores():
    import xbmc
    # Mostrar cache imediatamente — actualizar em background
    servidores = _carregar_cache()
    if servidores:
        xbmc.log('[OnTV] Servidores do cache ({})'.format(len(servidores)), xbmc.LOGINFO)
        # Actualizar cache em background para a próxima sessão
        def _actualizar():
            try:
                novos = _fetch_gist()
                with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                    json.dump(novos, f)
                xbmc.log('[OnTV] Cache actualizado ({})'.format(len(novos)), xbmc.LOGINFO)
            except Exception as e:
                xbmc.log('[OnTV] Erro ao actualizar cache: ' + str(e), xbmc.LOGWARNING)
        t = threading.Thread(target=_actualizar)
        t.daemon = True
        t.start()
        return servidores
    # Sem cache — primeira instalação, ir ao Gist de forma síncrona
    xbmc.log('[OnTV] Sem cache — a carregar do Gist...', xbmc.LOGINFO)
    try:
        servidores = _fetch_gist()
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(servidores, f)
        xbmc.log('[OnTV] Servidores carregados do Gist ({})'.format(len(servidores)), xbmc.LOGINFO)
        return servidores
    except Exception as e:
        xbmc.log('[OnTV] Erro: ' + str(e), xbmc.LOGERROR)
        return []


SERVIDORES = carregar_servidores()
