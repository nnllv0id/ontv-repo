# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════════════════╗
# ║              OnTV — Configuração dos Servidores                  ║
# ║                                                                  ║
# ║  TIPOS SUPORTADOS:                                               ║
# ║                                                                  ║
# ║  1) Xtream Codes:                                                ║
# ║     'tipo': 'xtream'                                             ║
# ║     'host', 'username', 'password'                               ║
# ║                                                                  ║
# ║  2) MAC / Stalker Portal:                                        ║
# ║     'tipo': 'stalker'                                            ║
# ║     'host'  → URL do portal  ex: http://servidor.com/c/         ║
# ║     'mac'   → MAC address    ex: 00:1A:79:XX:XX:XX              ║
# ║                                                                  ║
# ║  3) M3U por URL:                                                 ║
# ║     'tipo': 'm3u'                                                ║
# ║     'url'  → URL da lista M3U                                    ║
# ╚══════════════════════════════════════════════════════════════════╝

SERVIDORES = [

    # ── Xtream Codes - Exemplo Configuracao ─────────────────────────────────────────────────
    # {
    #    'nome':     'Servidor 1',
    #    'tipo':     'xtream',
    #    'host':     'http://vipfdedgevv.top:8080',
    #    'username': 'VIP011001752687394517',
    #    'password': '6574ccdc4d9d',
    #    'icon':     ''
    #},
    
    # ── MAC / Stalker Portal - Exemplo Configuracao  ──────────────────────────────────────────
    # {
    #    'nome': 'Servidor 4',
    #    'tipo': 'stalker',
    #    'host': 'http://line.tvdsz.cc/c/',
    #    'mac':  '00:1A:79:B6:29:A3',
    #},
    # ──────────────────────────────────────────────────────────────────────────────────────────
    # ──────────────────────────────────────────────────────────────────────────────────────────
    
    
    #EXPIRA: 13 setembro 2026
    {
        'nome': 'Servidor 1',
        'tipo': 'stalker',
        'host': 'http://nameoff.online:80/c/',
        'mac':  '00:1A:79:00:11:2F',
        'icon': ''
    },
    {
        'nome': 'Servidor 2',
        'tipo': 'stalker',
        'host': 'http://nameoff.online:80/c/',
        'mac':  '00:1A:79:00:10:EC',
        'icon': ''
    },
    {
        'nome': 'Servidor 3',
        'tipo': 'stalker',
        'host': 'http://nameoff.online:80/c/',
        'mac':  '00:1A:79:00:11:01',
        'icon': ''
    },
    #EXPIRA: 5 janeiro 2027
    {
        'nome': 'Servidor 4',
        'tipo': 'stalker',
        'host': 'http://line.tvdsz.cc/c/',
        'mac':  '00:1A:79:B6:29:A3',
        'icon': ''
    },
    #EXPIRA: 30 outubro 2026
    {
        'nome': 'Servidor 5',
        'tipo': 'stalker',
        'host': 'http://iptvswiss.com.123tv.to:8080/c',
        'mac':  '00:1A:79:D5:D2:24',
        'icon': ''
    },
    #EXPIRA: 13 setembro 2026
    {
        'nome': 'Servidor 6',
        'tipo': 'stalker',
        'host': 'http://onfireboxtv.com/c',
        'mac':  '00:1A:79:85:2D:5E',
        'icon': ''
    },
]
