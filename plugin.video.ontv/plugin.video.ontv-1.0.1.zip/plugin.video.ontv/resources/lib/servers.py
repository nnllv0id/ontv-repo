# -*- coding: utf-8 -*-
"""
OnTV
"""
import json
import os
import threading
import xbmcvfs


GIST_URL   = 'https://gist.githubusercontent.com/nnllv0id/a8bca35c256e0fcc73f41a58a125c044/raw/servers.json'
_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def _fetch_gist():
    import time
    from urllib.request import urlopen, Request
    # Adicionar timestamp ao URL para evitar cache HTTP do Kodi
    url = GIST_URL + '?t=' + str(int(time.time()))
    req = Request(url, headers={
        'User-Agent':     'Kodi/OnTV-Addon',
        'Cache-Control':  'no-cache, no-store, must-revalidate',
        'Pragma':         'no-cache',
        'Expires':        '0',
    })
    resp = urlopen(req, timeout=10)
    return json.loads(resp.read().decode('utf-8'))


def _actualizar_cache_background():
    def _fetch():
        try:
            servidores = _fetch_gist()
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(servidores, f)
            import xbmc
            xbmc.log('[OnTV] Cache de servidores actualizado', xbmc.LOGINFO)
        except Exception as e:
            import xbmc
            xbmc.log('[OnTV] Erro ao actualizar servidores: ' + str(e), xbmc.LOGWARNING)
    t = threading.Thread(target=_fetch)
    t.daemon = True
    t.start()


def carregar_servidores():
    """Tenta sempre o Gist primeiro — fallback para cache se falhar."""
    import xbmc
    try:
        servidores = _fetch_gist()
        try:
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(servidores, f)
        except Exception:
            pass
        xbmc.log('[OnTV] Servidores carregados do Gist ({})'.format(len(servidores)), xbmc.LOGINFO)
        return servidores
    except Exception as e:
        xbmc.log('[OnTV] Gist indisponível — a usar cache: ' + str(e), xbmc.LOGWARNING)
        servidores = _carregar_cache()
        if servidores:
            return servidores
        xbmc.log('[OnTV] Sem servidores disponíveis', xbmc.LOGERROR)
        return []


# Carregar apenas uma vez por sessão usando ficheiro de flag
_SESSION_FLAG = xbmcvfs.translatePath('special://temp/ontv_session.flag')

def _e_nova_sessao():
    """Verifica se é uma nova sessão do Kodi (flag não existe ou é de outra sessão)."""
    import time
    try:
        if os.path.exists(_SESSION_FLAG):
            with open(_SESSION_FLAG, 'r') as f:
                ts = float(f.read().strip())
            # Se a flag tem menos de 10 minutos, é a mesma sessão
            if time.time() - ts < 600:
                return False
    except Exception:
        pass
    # Nova sessão — escrever flag
    try:
        with open(_SESSION_FLAG, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass
    return True


def carregar_servidores_sessao():
    """Vai ao Gist apenas uma vez por sessão — usa cache nas restantes chamadas."""
    import xbmc, time
    if _e_nova_sessao():
        return carregar_servidores()
    # Mesma sessão — usar cache local sem ir ao Gist
    servidores = _carregar_cache()
    if servidores:
        xbmc.log('[OnTV] Servidores do cache de sessão ({})'.format(len(servidores)), xbmc.LOGINFO)
        return servidores
    return carregar_servidores()


SERVIDORES = carregar_servidores_sessao()
