# -*- coding: utf-8 -*-
"""
OnTV — Configuração dos Servidores
Mostra imediatamente a cache local e actualiza em background.
"""
import json
import os
import threading
import xbmcvfs

# ─── Configuração ────────────────────────────────────────────────────────────
SERVERS_URL  = 'https://raw.githubusercontent.com/nnllv0id/ontv-servers/main/servers.json'
GITHUB_TOKEN = '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'
# ─────────────────────────────────────────────────────────────────────────────

_CACHE_FILE = xbmcvfs.translatePath('special://temp/ontv_servers.json')


def _carregar_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def _actualizar_cache_background():
    """Actualiza o cache em background sem bloquear a interface."""
    def _fetch():
        try:
            from urllib.request import urlopen, Request
            headers = {
                'User-Agent':    'Kodi/OnTV-Addon',
                'Authorization': 'token ' + GITHUB_TOKEN,
                'Accept':        'application/vnd.github.v3.raw',
            }
            req  = Request(SERVERS_URL, headers=headers)
            resp = urlopen(req, timeout=10)
            data = resp.read().decode('utf-8')
            json.loads(data)  # validar JSON antes de guardar
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                f.write(data)
            import xbmc
            xbmc.log('[OnTV] Cache de servidores actualizado', xbmc.LOGINFO)
        except Exception as e:
            import xbmc
            xbmc.log('[OnTV] Erro ao actualizar servidores: ' + str(e), xbmc.LOGWARNING)

    t = threading.Thread(target=_fetch)
    t.daemon = True
    t.start()


def carregar_servidores():
    import xbmc
    # Mostrar imediatamente o que está em cache
    servidores = _carregar_cache()
    if servidores:
        xbmc.log('[OnTV] Servidores carregados do cache ({})'.format(len(servidores)), xbmc.LOGINFO)
        # Actualizar cache em background para a próxima abertura
        _actualizar_cache_background()
        return servidores

    # Sem cache — primeira instalação, tem de esperar
    xbmc.log('[OnTV] Sem cache — a carregar servidores remotamente...', xbmc.LOGINFO)
    try:
        from urllib.request import urlopen, Request
        headers = {
            'User-Agent':    'Kodi/OnTV-Addon',
            'Authorization': 'token ' + GITHUB_TOKEN,
            'Accept':        'application/vnd.github.v3.raw',
        }
        req  = Request(SERVERS_URL, headers=headers)
        resp = urlopen(req, timeout=10)
        data = resp.read().decode('utf-8')
        servidores = json.loads(data)
        try:
            with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
                f.write(data)
        except Exception:
            pass
        return servidores
    except Exception as e:
        xbmc.log('[OnTV] Erro ao carregar servidores: ' + str(e), xbmc.LOGERROR)
        return []


SERVIDORES = carregar_servidores()
