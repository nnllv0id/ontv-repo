# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background
Monitoriza o player e reinicia streams .ts quando fecham por EOF ou erro.
"""
import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import tempfile
import time

ADDON       = xbmcaddon.Addon()
STREAM_FILE = os.path.join(tempfile.gettempdir(), 'ontv_stream.json')


def log(msg):
    xbmc.log('[OnTV Service] ' + str(msg), xbmc.LOGINFO)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def eh_ts_live(url):
    if not url:
        return False
    return url.lower().split('?')[0].endswith('.ts') and url.startswith('http')


def _fazer_listitem(url, nome, logo):
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setProperty('IsLive', 'true')
    li.setProperty('mimetype', 'video/mp2t')
    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._tempo_inicio   = 0
        self._reinicios_init = 0

    def onPlayBackStarted(self):
        agora = time.time()
        if agora - self._tempo_inicio > 10:
            self._tempo_inicio   = agora
            self._reinicios_init = 0
        log('Stream iniciado')

    def onPlayBackStopped(self):
        """Utilizador parou manualmente — nunca reiniciar."""
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._reinicios_init = 0

    def onPlayBackEnded(self):
        """EOF — o servidor fechou a ligação. Reiniciar."""
        xbmc.sleep(800)
        self._reiniciar('EOF')

    def onPlayBackError(self):
        """Erro de rede ou codec. Reiniciar com delay maior."""
        xbmc.sleep(2000)
        self._reiniciar('Erro')

    def _reiniciar(self, motivo):
        info = ler_stream()
        if not info:
            return

        url = info.get('url', '')
        if not eh_ts_live(url):
            return

        duracao = time.time() - self._tempo_inicio

        # Primeiros 10s: máximo 1 reinício (evita loop por segmento apanhado a meio)
        if duracao < 10:
            if self._reinicios_init >= 1:
                log('{} em {}s — limite inicial atingido'.format(motivo, int(duracao)))
                return
            self._reinicios_init += 1
            log('{} em {}s — reinício inicial {}/1'.format(
                motivo, int(duracao), self._reinicios_init))
        else:
            log('{} em {}s — a reiniciar'.format(motivo, int(duracao)))

        xbmc.sleep(1000)
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        self.play(url, _fazer_listitem(url, nome, logo))


def run():
    log('Serviço iniciado')
    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(5)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
