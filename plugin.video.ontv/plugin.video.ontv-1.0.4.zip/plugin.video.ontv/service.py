# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background  v1.0.4

Melhorias v1.0.4:
  - Activação automática do DNS personalizado ao arrancar
  - Optimizador de buffer adaptativo por RAM disponível
"""

import xbmc
import xbmcgui
import xbmcaddon
import json
import os
import sys
import time
import xbmcvfs

ADDON       = xbmcaddon.Addon()
ADDON_PATH  = ADDON.getAddonInfo('path')
STREAM_FILE = xbmcvfs.translatePath('special://temp/ontv_stream.json')
STOP_FILE   = xbmcvfs.translatePath('special://temp/ontv_user_stop.flag')

_LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
if _LIB_PATH not in sys.path:
    sys.path.insert(0, _LIB_PATH)

_EOF_BACKOFF = [2.0, 5.0, 10.0, 20.0, 30.0]
_MAX_EOF     = len(_EOF_BACKOFF)


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[OnTV Service] ' + str(msg), level)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def _utilizador_parou():
    return os.path.exists(STOP_FILE)


def _criar_stop_flag():
    try:
        with open(STOP_FILE, 'w') as f:
            f.write('1')
    except Exception:
        pass


def _remover_stop_flag():
    try:
        if os.path.exists(STOP_FILE):\
            os.remove(STOP_FILE)
    except Exception:
        pass


def _parar_proxy():
    try:
        from proxy import stop as proxy_stop
        proxy_stop()
    except Exception:
        pass


# ── Optimizador de buffer por RAM ────────────────────────────────────────
def _optimizar_buffer():
    """
    Ajusta o tamanho do buffer do proxy em função da RAM disponível.
    Inspirado nos perfis lessthan1GB / morethan1GB do Eagle TV.
    """
    try:
        import sys
        # Heurística: tentar ler RAM via xbmc (só funciona nalgumas versões)
        ram_str = xbmc.getInfoLabel('System.Memory(total)')   # ex: "4096 MB"
        ram_mb  = int(''.join(filter(str.isdigit, ram_str)))
    except Exception:
        ram_mb  = 2048   # assumir 2 GB por defeito

    if ram_mb >= 2048:
        chunk   = 131072   # 128 KB — mais RAM → chunks maiores → menos syscalls
        buf_mb  = 100      # 100 MB de buffer
    else:
        chunk   = 65536    # 64 KB — conservador
        buf_mb  = 32       # 32 MB

    try:
        from proxy import CHUNK_SIZE
        import proxy as _proxy
        _proxy.CHUNK_SIZE = chunk
        log('Buffer optimizado: chunk={}KB, ram={}MB'.format(chunk // 1024, ram_mb))
    except Exception:
        pass


# ── Activação do DNS ao arrancar ────────────────────────────────────────
def _activar_dns():
    """Activa DNS personalizado guardado na última sessão (se existir)."""
    try:
        dns_file = xbmcvfs.translatePath('special://temp/ontv_dns_provider.txt')
        if os.path.exists(dns_file):
            with open(dns_file, 'r') as f:
                provider = f.read().strip()
            if provider and provider != 'sistema':
                import dns_override
                dns_override.activate(provider)
                log('DNS activado ao arrancar: ' + provider)
    except Exception as e:
        log('Aviso DNS: ' + str(e), xbmc.LOGWARNING)


def _fazer_listitem(url, nome, logo):
    url_lower = url.lower().split('?')[0]
    url_play  = url
    via_proxy = False
    try:
        from proxy import start as proxy_start
        url_play  = proxy_start(url)
        via_proxy = url_play.startswith('http://127.0.0.1')
    except Exception:
        pass

    li = xbmcgui.ListItem(nome, path=url_play)
    li.setProperty('IsPlayable', 'true')

    if via_proxy:
        if '.m3u8' in url_lower or '/hls/' in url_lower:
            li.setMimeType('application/vnd.apple.mpegurl')
        else:
            li.setMimeType('video/mp2t')
        li.setContentLookup(False)
    else:
        if '.m3u8' in url_lower or '/hls/' in url_lower:
            try:
                li.setProperty('inputstream', 'inputstream.adaptive')
                li.setProperty('inputstream.adaptive.manifest_type', 'hls')
                li.setProperty('mimetype', 'application/x-mpegURL')
            except Exception:
                li.setMimeType('application/x-mpegURL')
        elif url_lower.endswith('.mp4') or url_lower.endswith('.mkv'):
            li.setMimeType('video/mp4')
        else:
            try:
                li.setProperty('inputstream', 'inputstream.ffmpegdirect')
                li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
                li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
                li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
                li.setProperty('mimetype', 'video/mp2t')
                li.setProperty('inputstream.ffmpegdirect.read_chunk_size', '131072')
            except Exception:
                li.setMimeType('video/mp2t')

    li.setProperty('network.curlcachebytes', '20971520')
    li.setProperty('network.bandwidth',      '0')
    li.setProperty('network.readtimeout',    '60')
    li.setProperty('network.connecttimeout', '10')
    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video', 'playcount': 0, 'overlay': 0})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super(OnTVPlayer, self).__init__()
        self._eof_count   = 0
        self._a_reiniciar = False

    def onPlayBackStarted(self):
        self._eof_count   = 0
        self._a_reiniciar = False
        _remover_stop_flag()
        log('Stream iniciado')

    def onPlayBackStopped(self):
        log('Stream parado pelo utilizador')
        limpar_stream()
        self._eof_count   = 0
        self._a_reiniciar = False
        _criar_stop_flag()
        _parar_proxy()

    def onPlayBackEnded(self):
        if _utilizador_parou():
            return
        log('EOF do servidor — a reiniciar canal')
        xbmc.sleep(2000)
        self._reiniciar_por_eof()

    def onPlayBackError(self):
        if _utilizador_parou():
            return
        log('Erro/buffer — proxy a reconectar (sem acção do serviço)')

    def _reiniciar_por_eof(self):
        if self._a_reiniciar:
            return
        if _utilizador_parou():
            return
        info = ler_stream()
        if not info or not info.get('url', '').startswith('http'):
            log('Reinício cancelado — sem info de stream')
            return
        if self._eof_count >= _MAX_EOF:
            log('EOF consecutivos esgotados ({}) — a desistir'.format(self._eof_count), xbmc.LOGWARNING)
            self._eof_count = 0
            return
        espera = _EOF_BACKOFF[min(self._eof_count, len(_EOF_BACKOFF) - 1)]
        self._eof_count  += 1
        self._a_reiniciar = True
        log('EOF #{} — aguardar {:.0f}s e reiniciar'.format(self._eof_count, espera))
        xbmc.sleep(int(espera * 1000))
        if _utilizador_parou():
            self._a_reiniciar = False
            return
        _parar_proxy()
        xbmc.sleep(500)
        url  = info.get('url', '')
        nome = info.get('nome', '')
        logo = info.get('logo', '')
        self.play(url, _fazer_listitem(url, nome, logo))
        self._a_reiniciar = False


def run():
    log('Serviço iniciado v1.0.4')

    # Optimizar buffer por RAM
    _optimizar_buffer()

    # Activar DNS da sessão anterior (se guardado)
    _activar_dns()

    try:
        from servers import invalidar_cache
        invalidar_cache()
    except Exception as e:
        log('Aviso ao invalidar cache: ' + str(e), xbmc.LOGWARNING)

    _remover_stop_flag()
    limpar_stream()
    _parar_proxy()

    monitor = xbmc.Monitor()
    player  = OnTVPlayer()
    while not monitor.abortRequested():
        monitor.waitForAbort(5)
    log('Serviço terminado')


if __name__ == '__main__':
    run()
