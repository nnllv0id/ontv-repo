# -*- coding: utf-8 -*-
"""
OnTV — Gestão de Servidores
Carrega a lista de servidores a partir de um Gist remoto, com cache em disco.

MELHORIAS v1.1.0:
  - Carregamento lazy (não bloqueia o import)
  - Cache em disco com TTL de 30 minutos
  - Singleton thread-safe para evitar pedidos duplicados
  - Fallback robusto para cache anterior quando o Gist é inacessível
"""

import json
import os
import threading
import time

try:
    import xbmc
    import xbmcvfs
    def _log(msg, level=None):
        xbmc.log('[OnTV/servers] ' + str(msg), level or xbmc.LOGINFO)
    def _tmp(nome):
        return xbmcvfs.translatePath('special://temp/' + nome)
except Exception:
    # Fallback para testes fora do Kodi
    def _log(msg, level=None):
        print('[OnTV/servers] ' + str(msg))
    def _tmp(nome):
        return os.path.join(os.path.dirname(__file__), nome)

GIST_URL    = 'https://gist.githubusercontent.com/nnllv0id/a8bca35c256e0fcc73f41a58a125c044/raw/servers.json'
_CACHE_FILE = _tmp('ontv_servers.json')
_GIST_TS    = _tmp('ontv_gist_ts.flag')
_TTL        = 1800   # 30 minutos

# Singleton para evitar carregar mais do que uma vez por sessão
_servidores       = None
_servidores_lock  = threading.Lock()


# ── Helpers de cache ───────────────────────────────────────────────────────

def _ler_cache():
    """Lê a cache de servidores do disco. Devolve lista ou None."""
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        _log('Erro ao ler cache: ' + str(e), xbmc.LOGWARNING if 'xbmc' in dir() else None)
    return None


def _escrever_cache(dados):
    """Persiste a lista de servidores em disco."""
    try:
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(dados, f, ensure_ascii=False)
    except Exception as e:
        _log('Erro ao escrever cache: ' + str(e))


def _cache_fresca():
    """Devolve True se o Gist foi consultado há menos de _TTL segundos."""
    try:
        if os.path.exists(_GIST_TS):
            with open(_GIST_TS, 'r') as f:
                ts = float(f.read().strip())
            return (time.time() - ts) < _TTL
    except Exception:
        pass
    return False


def _marcar_gist_visitado():
    try:
        with open(_GIST_TS, 'w') as f:
            f.write(str(time.time()))
    except Exception:
        pass


def _apagar_flag_gist():
    """Chamado pelo serviço ao arrancar para forçar refresh na próxima abertura."""
    try:
        if os.path.exists(_GIST_TS):
            os.remove(_GIST_TS)
            _log('Flag do Gist apagada — servidores serão actualizados')
    except Exception:
        pass


# ── Fetch remoto ───────────────────────────────────────────────────────────

def _fetch_gist():
    """Descarrega a lista de servidores do Gist. Lança excepção em caso de erro."""
    try:
        from urllib.request import urlopen, Request
    except ImportError:
        from urllib2 import urlopen, Request

    url = GIST_URL + '?t=' + str(int(time.time()))
    req = Request(url, headers={
        'User-Agent':    'Kodi/OnTV-Addon',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma':        'no-cache',
        'Expires':       '0',
    })
    resp = urlopen(req, timeout=12)
    return json.loads(resp.read().decode('utf-8'))


# ── Carregamento principal (lazy + singleton) ──────────────────────────────

def carregar_servidores():
    """
    Devolve a lista de servidores.
    Usa cache em memória (singleton), depois cache em disco, depois Gist.
    Thread-safe.
    """
    global _servidores

    # Singleton: se já carregou nesta sessão, devolver imediatamente
    if _servidores is not None:
        return _servidores

    with _servidores_lock:
        # Verificar novamente dentro do lock (double-checked locking)
        if _servidores is not None:
            return _servidores

        # Cache de disco ainda válida → usar directamente
        if _cache_fresca():
            dados = _ler_cache()
            if dados:
                _log('Servidores do cache em disco ({})'.format(len(dados)))
                _servidores = dados
                return _servidores

        # Tentar Gist
        try:
            dados = _fetch_gist()
            if dados:
                _escrever_cache(dados)
                _marcar_gist_visitado()
                _log('Servidores carregados do Gist ({})'.format(len(dados)))
                _servidores = dados
                return _servidores
        except Exception as e:
            _log('Gist indisponível: ' + str(e))

        # Fallback: cache de disco (mesmo expirada)
        dados = _ler_cache()
        if dados:
            _log('Gist falhou — a usar cache expirada ({})'.format(len(dados)))
            _servidores = dados
            return _servidores

        _log('Sem servidores disponíveis!', xbmc.LOGERROR if 'xbmc' in dir() else None)
        _servidores = []
        return _servidores


def invalidar_cache():
    """Força recarga dos servidores na próxima chamada."""
    global _servidores
    _servidores = None
    _apagar_flag_gist()
