# -*- coding: utf-8 -*-
# OnTV - Proxy Local de Streams  v1.0.4
#
# RECONEXAO SILENCIOSA:
#   O socket HTTP para o Kodi fica aberto durante toda a sessao.
#   Quando o servidor IPTV corta, o proxy tenta reconectar internamente
#   com backoff exponencial. O Kodi nao fecha nem reabre o canal.
#   Transfer-Encoding: chunked garante que o socket permanece aberto.

import threading
import time

try:
    from http.server    import HTTPServer, BaseHTTPRequestHandler
    from urllib.request import urlopen, Request
    from urllib.parse   import urlparse, unquote, quote_plus, unquote_plus
except ImportError:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urllib2        import urlopen, Request
    from urlparse       import urlparse, unquote
    from urllib         import quote_plus, unquote_plus

HOST         = '127.0.0.1'
PORT         = 52315
UA           = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                'AppleWebKit/537.36 (KHTML, like Gecko) '
                'Chrome/120.0.0.0 Safari/537.36')
CHUNK_SIZE   = 65536
TIMEOUT_REQ  = 15
TIMEOUT_READ = 20
MAX_RETRIES  = 20

_RETRY_BACKOFF = [1, 2, 4, 8, 16, 30, 30, 30, 30, 30,
                  30, 30, 30, 30, 30, 30, 30, 30, 30, 30]

_lock        = threading.Lock()
_stop_flag   = False
_current_url = ''
_base_url    = ''


def _set_stop(val):
    global _stop_flag
    with _lock:
        _stop_flag = val

def _is_stopped():
    with _lock:
        return _stop_flag

def _set_url(url):
    global _current_url
    with _lock:
        _current_url = url

def _get_url():
    with _lock:
        return _current_url


def _build_headers():
    return {'User-Agent': UA, 'Connection': 'keep-alive',
            'Accept': '*/*', 'Accept-Encoding': 'identity'}


def _is_m3u8(url):
    u = url.lower().split('?')[0]
    return '.m3u8' in u or '/hls/' in u


def _resolve_segment(seg_url, base):
    if seg_url.startswith('http'):
        return seg_url
    if seg_url.startswith('/'):
        p = urlparse(base)
        return '{}://{}{}'.format(p.scheme, p.netloc, seg_url)
    return base.rsplit('/', 1)[0] + '/' + seg_url


def _rewrite_m3u8(body_text, proxy_base, original_url):
    out = []
    for line in body_text.splitlines():
        s = line.strip()
        if s.startswith('#') or not s:
            out.append(line)
        else:
            abs_url = _resolve_segment(s, original_url)
            out.append(proxy_base + '/?url=' + quote_plus(abs_url))
    return '\n'.join(out)


class _StreamHandler(BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        pass

    def _get_target_url(self):
        path = self.path
        if '?url=' in path:
            encoded = path.split('?url=', 1)[1]
            try:
                return unquote_plus(encoded)
            except Exception:
                return unquote(encoded)
        return ''

    def do_HEAD(self):
        self._handle('HEAD')

    def do_GET(self):
        self._handle('GET')

    def _handle(self, method):
        global _base_url

        if _is_stopped():
            self.send_response(503); self.end_headers(); return

        if self.path == '/check':
            self.send_response(200); self.end_headers(); return
        if self.path == '/stop':
            self.send_response(200); self.end_headers()
            _set_stop(True)
            t = threading.Thread(target=self.server.shutdown); t.daemon = True; t.start()
            return

        url = self._get_target_url()
        if not url or not url.startswith('http'):
            url = _get_url()
        if not url:
            self.send_response(404); self.end_headers(); return

        proxy_base = 'http://{}:{}'.format(HOST, PORT)
        headers    = _build_headers()

        # ── HLS ───────────────────────────────────────────────────────────
        if _is_m3u8(url):
            for attempt in range(MAX_RETRIES):
                if _is_stopped(): break
                try:
                    resp = urlopen(Request(url, headers=headers), timeout=TIMEOUT_REQ)
                    body = resp.read().decode('utf-8', errors='replace')
                    resp.close()
                    with _lock:
                        _base_url = url
                    rewritten = _rewrite_m3u8(body, proxy_base, url)
                    enc = rewritten.encode('utf-8')
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                    self.send_header('Content-Length', str(len(enc)))
                    self.end_headers()
                    if method != 'HEAD':
                        self.wfile.write(enc)
                    return
                except Exception:
                    if _is_stopped(): break
                    time.sleep(_RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF)-1)])
            try:
                self.send_response(503); self.end_headers()
            except Exception:
                pass
            return

        # ── TS / mp4 - reconexao silenciosa ──────────────────────────────
        # Headers enviados uma vez; socket do Kodi fica aberto.
        # Quando o IPTV corta, reconectamos internamente sem o Kodi saber.
        headers_sent = False
        last_data    = time.time()

        for attempt in range(MAX_RETRIES):
            if _is_stopped(): break

            try:
                resp = urlopen(Request(url, headers=headers), timeout=TIMEOUT_REQ)

                if not headers_sent:
                    self.send_response(200)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('Transfer-Encoding', 'chunked')
                    self.end_headers()
                    headers_sent = True

                if method == 'HEAD':
                    resp.close(); return

                last_data = time.time()

                while not _is_stopped():
                    try:
                        chunk = resp.read(CHUNK_SIZE)
                    except Exception:
                        break
                    if not chunk:
                        if time.time() - last_data > TIMEOUT_READ:
                            break
                        time.sleep(0.05)
                        continue
                    last_data = time.time()
                    try:
                        self.wfile.write('{:X}\r\n'.format(len(chunk)).encode('ascii'))
                        self.wfile.write(chunk)
                        self.wfile.write(b'\r\n')
                        self.wfile.flush()
                    except Exception:
                        resp.close(); return  # Kodi fechou o socket (utilizador saiu)

                resp.close()
                if _is_stopped(): break

                # Reconexao silenciosa - aguardar e tentar novamente
                espera = _RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF)-1)]
                time.sleep(espera)
                # Se o stream esteve saudavel por mais de 60s, nao penalizar
                if time.time() - last_data > 60:
                    attempt = max(0, attempt - 1)

            except Exception:
                if _is_stopped(): break
                time.sleep(_RETRY_BACKOFF[min(attempt, len(_RETRY_BACKOFF)-1)])

        # Terminar chunked transfer
        if headers_sent:
            try:
                self.wfile.write(b'0\r\n\r\n')
                self.wfile.flush()
            except Exception:
                pass
        else:
            try:
                self.send_response(503); self.end_headers()
            except Exception:
                pass


_server_instance = None
_server_thread   = None


def _serve(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass
    finally:
        try:
            httpd.server_close()
        except Exception:
            pass


def start(url):
    global _server_instance, _server_thread
    _set_stop(False)
    _set_url(url)

    if _server_thread and _server_thread.is_alive():
        return _make_proxy_url(url)

    try:
        _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
        _server_instance.allow_reuse_address = True
    except Exception:
        stop()
        time.sleep(1)
        try:
            _server_instance = HTTPServer((HOST, PORT), _StreamHandler)
            _server_instance.allow_reuse_address = True
        except Exception:
            return url

    _server_thread = threading.Thread(target=_serve, args=(_server_instance,))
    _server_thread.daemon = True
    _server_thread.start()

    for _ in range(15):
        if is_running(): break
        time.sleep(0.2)

    return _make_proxy_url(url)


def stop():
    global _server_instance, _server_thread
    _set_stop(True)
    try:
        if _server_instance:
            t = threading.Thread(target=_server_instance.shutdown)
            t.daemon = True; t.start(); t.join(timeout=3)
            _server_instance.server_close()
    except Exception:
        pass
    _server_instance = None
    _server_thread   = None


def is_running():
    try:
        resp = urlopen(Request('http://{}:{}/check'.format(HOST, PORT)), timeout=2)
        resp.close()
        return True
    except Exception:
        return False


def update_url(url):
    _set_url(url)


def _make_proxy_url(url):
    return 'http://{}:{}/?url={}'.format(HOST, PORT, quote_plus(url))
