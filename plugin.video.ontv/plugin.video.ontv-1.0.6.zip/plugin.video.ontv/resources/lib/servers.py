# -*- coding: utf-8 -*-
import base64
import hashlib
import json
import os
import ssl
import threading
import time

try:
    import xbmc
    import xbmcvfs
    def _log(msg, level=None):
        xbmc.log('[OnTV/servers] ' + str(msg), level or xbmc.LOGINFO)
    def _tmp(nome):
        return xbmcvfs.translatePath('special://temp/' + nome)
except Exception:
    def _log(msg, level=None):
        print('[OnTV/servers] ' + str(msg))
    def _tmp(nome):
        return os.path.join(os.path.dirname(__file__), nome)

_k  = b'Kodi-Media-Player-Stream-Handler'
_r0 = 'gQ1I2CvuKGnwnIyYf+GZvOSkWmuj0z'
_r1 = 'oRdUWNyycR4pHKNW9ATk0LJNhqas66'
_r2 = 'ORnajNJEjl/TvPRo22jXwxPdToQbV8'
_r3 = 'Epnqsc4LOu7lOOsVWiiarm2I/9PsbA'
_r4 = 'vyLXB6etgzNsVsbLsc/ypIy55O3tNV'
_r5 = 'QL7+K9CxdG7G8zkKHNMCx9vM1ayyq='
_dt = {88:65,90:66,72:67,87:68,116:69,104:70,84:71,55:72,117:73,74:74,111:75,
       83:76,113:77,102:78,81:79,86:80,107:81,112:82,100:83,85:84,76:85,121:86,
       110:87,119:88,68:89,101:90,89:97,51:98,69:99,53:100,50:101,120:102,75:103,
       65:104,56:105,99:106,115:107,97:108,48:109,77:110,106:111,49:112,109:113,
       103:114,54:115,78:116,122:117,43:118,67:119,98:120,108:121,70:122,105:48,
       52:49,114:50,71:51,57:52,73:53,47:54,80:55,82:56,118:57,66:43,79:47}

def _r():
    _hk  = hashlib.sha256(_k).digest()
    _raw = base64.b64decode((_r0+_r1+_r2+_r3+_r4+_r5).translate(_dt))[::-1]
    return bytes(b ^ _hk[i % len(_hk)] for i, b in enumerate(_raw)).decode()

def _ctx():
    """Contexto SSL sem verificacao — identico ao f4mTester (verify=False)."""
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        return ctx
    except Exception:
        return None

_CACHE_FILE = _tmp('ontv_servers.json')

_servidores      = None
_servidores_lock = threading.Lock()


def _ler_cache():
    try:
        if os.path.exists(_CACHE_FILE):
            with open(_CACHE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        _log('Erro cache: ' + str(e))
    return None


def _escrever_cache(dados):
    try:
        with open(_CACHE_FILE, 'w', encoding='utf-8') as f:
            json.dump(dados, f, ensure_ascii=False)
    except Exception as e:
        _log('Erro ao guardar cache: ' + str(e))


def _fetch():
    try:
        from urllib.request import urlopen, Request
    except ImportError:
        from urllib2 import urlopen, Request

    url  = _r() + '?t=' + str(int(time.time()))
    req  = Request(url, headers={
        'User-Agent':    'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Cache-Control': 'no-cache, no-store',
        'Pragma':        'no-cache',
    })
    ctx  = _ctx()
    resp = urlopen(req, timeout=12, context=ctx) if ctx else urlopen(req, timeout=12)
    return json.loads(resp.read().decode('utf-8'))


def carregar_servidores():
    """
    Vai sempre buscar dados frescos do Gist ao abrir o addon.
    Cache em disco apenas como fallback se o Gist nao estiver acessivel.
    """
    global _servidores

    if _servidores is not None:
        return _servidores

    with _servidores_lock:
        if _servidores is not None:
            return _servidores

        try:
            dados = _fetch()
            if dados:
                _escrever_cache(dados)
                _log('Servidores carregados ({}).'.format(len(dados)))
                _servidores = dados
                return _servidores
        except Exception as e:
            _log('Fonte indisponivel, a usar cache: ' + str(e))

        dados = _ler_cache()
        if dados:
            _log('A usar cache ({}).'.format(len(dados)))
            _servidores = dados
            return _servidores

        _log('Sem servidores!')
        _servidores = []
        return _servidores


def invalidar_cache():
    """Limpa servidores em memoria para forcar nova leitura do Gist."""
    global _servidores
    _servidores = None
