# -*- coding: utf-8 -*-
"""
OnTV — Favoritos e Recentes persistentes.

Guardados em addon_data (NAO em special://temp, que o Kodi/Android pode limpar).
Migra automaticamente o ficheiro antigo de special://temp.
Escrita atomica; leitura com cache em memoria (valida com a data do ficheiro,
por isso funciona com reuselanguageinvoker).
"""
import hashlib
import json
import os
import time

import common

_FAV = 'ontv_favourites.json'
_HIST = 'ontv_history.json'
_HIST_MAX = 30
_mem = {}


def _path(name):
    return os.path.join(common.profile_dir(), name)


def _load(name):
    p = _path(name)
    try:
        mt = os.path.getmtime(p)
    except OSError:
        mt = None
    c = _mem.get(name)
    if c and c[0] == mt:
        return c[1]
    data = []
    if mt is not None:
        try:
            with open(p, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            data = []
    _mem[name] = (mt, data)
    return data


def _save(name, data):
    try:
        common.atomic_write(_path(name), json.dumps(data, ensure_ascii=False, indent=1))
        _mem[name] = (os.path.getmtime(_path(name)), data)
    except Exception as e:
        common.log('favoritos: erro a gravar: ' + str(e))


def migrar_antigo():
    """Copia favoritos de special://temp (versoes <= 1.0.7) se ainda nao existirem no perfil."""
    try:
        novo = _path(_FAV)
        antigo = os.path.join(common.temp_dir(), 'ontv_favourites.json')
        if not os.path.exists(novo) and os.path.exists(antigo):
            with open(antigo, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if data:
                _save(_FAV, data)
                common.log('Favoritos migrados: {}'.format(len(data)), None)
    except Exception as e:
        common.log('migrar favoritos: ' + str(e))


def _make_id(nome, url):
    return hashlib.md5((nome + (url or '')).encode('utf-8')).hexdigest()[:12]


# ── Favoritos ───────────────────────────────────────────────
def listar():
    return sorted(_load(_FAV), key=lambda x: x.get('nome', '').lower())


def adicionar(nome, url='', logo='', tipo='video', **kwargs):
    favs = list(_load(_FAV))
    fid = _make_id(nome, url or kwargs.get('cmd', '') or kwargs.get('series_id', ''))
    if any(f['id'] == fid for f in favs):
        return False
    fav = {'id': fid, 'nome': nome, 'url': url, 'logo': logo, 'tipo': tipo, 'ts': time.time()}
    fav.update({k: v for k, v in kwargs.items() if v})
    favs.append(fav)
    _save(_FAV, favs)
    return True


def remover(fid):
    favs = _load(_FAV)
    novo = [f for f in favs if f['id'] != fid]
    if len(novo) < len(favs):
        _save(_FAV, novo)
        return True
    return False


def existe(nome, url=''):
    fid = _make_id(nome, url)
    return any(f['id'] == fid for f in _load(_FAV))


def contar():
    return len(_load(_FAV))


# ── Recentes ────────────────────────────────────────────────
def hist_add(entry):
    """entry: dict com nome, logo, tipo e os campos para voltar a reproduzir (url | srv_idx+cmd...)."""
    h = [e for e in _load(_HIST) if e.get('id') != entry.get('id')]
    entry = dict(entry, ts=time.time())
    h.insert(0, entry)
    _save(_HIST, h[:_HIST_MAX])


def hist_listar():
    return list(_load(_HIST))


def hist_limpar():
    _save(_HIST, [])
