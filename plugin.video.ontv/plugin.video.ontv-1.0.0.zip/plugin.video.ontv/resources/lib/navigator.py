# -*- coding: utf-8 -*-
"""
OnTV — Navigator Xtream Codes
  Menu: Servidor → Live TV / Movies / Series
        → Categorias (sem conteúdo adulto) → Canais/Filmes/Séries
        → Reprodução via F4mTester
"""

import sys
import os
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.parse   import urlencode, parse_qsl
except ImportError:
    from urllib2  import urlopen, Request
    from urllib   import urlencode
    from urlparse import parse_qsl

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.jpg')
UA         = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0'
F4M_ID     = 'plugin.video.f4mTester'
_CACHE     = {}

# ── Filtro de conteúdo adulto ─────────────────────────────────────────────
PALAVRAS_ADULTO = [
    'adult', 'xxx', 'porn', 'sex', '18+', 'erotic', 'erotica',
    'x-rated', 'xrated', 'hentai', 'playboy', 'nude', 'naked',
    'adulto', 'adultos', 'adulte', 'adultes',
]

def e_adulto(nome):
    nome_lower = nome.lower()
    for palavra in PALAVRAS_ADULTO:
        if palavra in nome_lower:
            return True
    return False

def filtrar_adulto(categorias):
    return [cat for cat in categorias if not e_adulto(cat.get('category_name', ''))]


def log(msg):
    xbmc.log('[OnTV] ' + str(msg), xbmc.LOGDEBUG)

def url_para(params):
    return BASE_URL + '?' + urlencode(params)

def notificar(msg, tipo=xbmcgui.NOTIFICATION_ERROR):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, tipo, 4000)

def api_get(url):
    if url in _CACHE:
        return _CACHE[url]
    try:
        req  = Request(url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=15)
        data = json.loads(resp.read().decode('utf-8', errors='replace'))
        _CACHE[url] = data
        return data
    except Exception as e:
        log('ERRO API: ' + str(e))
        return None


# ── Ecrã 1 — Servidores ──────────────────────────────────────────────────

def mostrar_principal():
    from servers import SERVIDORES
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')

    for i, srv in enumerate(SERVIDORES):
        li = xbmcgui.ListItem(srv['nome'])
        li.setArt({'thumb': srv.get('icon') or ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'tipos', 'srv_idx': str(i)}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 2 — Tipos (Live TV / Movies / Series) ───────────────────────────

def mostrar_tipos(srv_idx):
    from servers import SERVIDORES
    srv = SERVIDORES[int(srv_idx)]
    xbmcplugin.setPluginCategory(HANDLE, srv['nome'])

    tipos = [
        ('Live TV', 'live_cats'),
        ('Movies',  'vod_cats'),
        ('Series',  'series_cats'),
    ]

    for nome, acao_cat in tipos:
        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': acao_cat, 'srv_idx': srv_idx}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 3 — Categorias (com filtro adulto) ──────────────────────────────

def mostrar_categorias(srv_idx, tipo):
    from servers import SERVIDORES
    srv  = SERVIDORES[int(srv_idx)]
    host = srv['host']
    u    = srv['username']
    p    = srv['password']

    endpoints = {
        'live_cats':   '/player_api.php?username={u}&password={p}&action=get_live_categories',
        'vod_cats':    '/player_api.php?username={u}&password={p}&action=get_vod_categories',
        'series_cats': '/player_api.php?username={u}&password={p}&action=get_series_categories',
    }

    url  = host + endpoints[tipo].format(u=u, p=p)
    data = api_get(url)

    if not data:
        notificar('Erro ao carregar categorias!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # Filtrar conteúdo adulto
    data = filtrar_adulto(data)

    acao_canais = {
        'live_cats':   'live_canais',
        'vod_cats':    'vod_canais',
        'series_cats': 'series_canais',
    }[tipo]

    for cat in data:
        nome   = cat.get('category_name', 'Sem Nome')
        cat_id = str(cat.get('category_id', ''))
        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': acao_canais, 'srv_idx': srv_idx, 'cat_id': cat_id, 'cat_nome': nome}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 4a — Canais Live ────────────────────────────────────────────────

def mostrar_live(srv_idx, cat_id, cat_nome):
    from servers import SERVIDORES
    srv  = SERVIDORES[int(srv_idx)]
    host = srv['host']
    u    = srv['username']
    p    = srv['password']

    url  = '{host}/player_api.php?username={u}&password={p}&action=get_live_streams&category_id={cat}'.format(
        host=host, u=u, p=p, cat=cat_id)
    data = api_get(url)

    if not data:
        notificar('Erro ao carregar canais!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, cat_nome)

    for ch in data:
        nome       = ch.get('name', 'Canal')
        stream_id  = str(ch.get('stream_id', ''))
        logo       = ch.get('stream_icon', '') or ICON
        ext        = ch.get('container_extension', 'ts')
        stream_url = '{host}/live/{u}/{p}/{sid}.{ext}'.format(
            host=host, u=u, p=p, sid=stream_id, ext=ext)

        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': logo, 'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'play', 'url': stream_url, 'nome': nome, 'logo': logo}),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 4b — VOD (Movies) ───────────────────────────────────────────────

def mostrar_vod(srv_idx, cat_id, cat_nome):
    from servers import SERVIDORES
    srv  = SERVIDORES[int(srv_idx)]
    host = srv['host']
    u    = srv['username']
    p    = srv['password']

    url  = '{host}/player_api.php?username={u}&password={p}&action=get_vod_streams&category_id={cat}'.format(
        host=host, u=u, p=p, cat=cat_id)
    data = api_get(url)

    if not data:
        notificar('Erro ao carregar filmes!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, cat_nome)

    for item in data:
        nome       = item.get('name', 'Filme')
        stream_id  = str(item.get('stream_id', ''))
        logo       = item.get('stream_icon', '') or ICON
        ext        = item.get('container_extension', 'mp4')
        stream_url = '{host}/movie/{u}/{p}/{sid}.{ext}'.format(
            host=host, u=u, p=p, sid=stream_id, ext=ext)

        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': logo, 'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': nome, 'mediatype': 'movie'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'play', 'url': stream_url, 'nome': nome, 'logo': logo}),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 4c — Series ─────────────────────────────────────────────────────

def mostrar_series(srv_idx, cat_id, cat_nome):
    from servers import SERVIDORES
    srv  = SERVIDORES[int(srv_idx)]
    host = srv['host']
    u    = srv['username']
    p    = srv['password']

    url  = '{host}/player_api.php?username={u}&password={p}&action=get_series&category_id={cat}'.format(
        host=host, u=u, p=p, cat=cat_id)
    data = api_get(url)

    if not data:
        notificar('Erro ao carregar séries!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, cat_nome)

    for serie in data:
        nome      = serie.get('name', 'Série')
        series_id = str(serie.get('series_id', ''))
        logo      = serie.get('cover', '') or ICON

        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': logo, 'fanart': logo or FANART})
        li.setInfo('video', {'title': nome, 'mediatype': 'tvshow'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'series_eps', 'srv_idx': srv_idx, 'series_id': series_id, 'serie_nome': nome}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'tvshows')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 5 — Episódios de Série ──────────────────────────────────────────

def mostrar_episodios(srv_idx, series_id, serie_nome):
    from servers import SERVIDORES
    srv  = SERVIDORES[int(srv_idx)]
    host = srv['host']
    u    = srv['username']
    p    = srv['password']

    url  = '{host}/player_api.php?username={u}&password={p}&action=get_series_info&series_id={sid}'.format(
        host=host, u=u, p=p, sid=series_id)
    data = api_get(url)

    if not data:
        notificar('Erro ao carregar episódios!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, serie_nome)
    episodes = data.get('episodes', {})

    for season_num in sorted(episodes.keys(), key=lambda x: int(x) if x.isdigit() else 0):
        for ep in episodes[season_num]:
            titulo     = 'S{s}E{e} - {t}'.format(
                s=str(season_num).zfill(2),
                e=str(ep.get('episode_num', '')).zfill(2),
                t=ep.get('title', 'Episódio'))
            ep_id      = str(ep.get('id', ''))
            logo       = ep.get('info', {}).get('movie_image', '') or ICON
            ext        = ep.get('container_extension', 'mp4')
            stream_url = '{host}/series/{u}/{p}/{eid}.{ext}'.format(
                host=host, u=u, p=p, eid=ep_id, ext=ext)

            li = xbmcgui.ListItem(titulo)
            li.setArt({'thumb': logo, 'fanart': FANART})
            li.setProperty('IsPlayable', 'true')
            li.setInfo('video', {'title': titulo, 'mediatype': 'episode'})
            xbmcplugin.addDirectoryItem(
                HANDLE,
                url_para({'acao': 'play', 'url': stream_url, 'nome': titulo, 'logo': logo}),
                li, False
            )

    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ── Ecrã 6 — Reprodução (direto ou via F4mTester) ────────────────────────

def reproduzir(stream_url, nome='', logo=''):
    log('Reproduzir: ' + stream_url)

    # F4mTester só para streams .f4m — tudo o resto reproduz direto
    # Reprodução direta funciona em Android TV e Linux sem timeout
    usar_f4m = stream_url.endswith('.f4m') or '.f4m?' in stream_url

    if usar_f4m:
        log('Stream f4m — usando F4mTester')
        params = urlencode({'url': stream_url, 'name': nome, 'iconImage': logo or ICON, 'streamtype': 'HLS'})
        path   = 'plugin://{0}/?{1}'.format(F4M_ID, params)
    else:
        log('Stream direto — player nativo')
        path = stream_url

    li = xbmcgui.ListItem(nome, path=path)
    li.setArt({'thumb': logo or ICON})
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')

    if not usar_f4m:
        if stream_url.endswith('.ts'):
            li.setProperty('mimetype', 'video/mp2t')
        elif '.m3u8' in stream_url:
            li.setProperty('mimetype', 'application/x-mpegURL')
        elif stream_url.endswith('.mp4'):
            li.setProperty('mimetype', 'video/mp4')

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ── Roteador ──────────────────────────────────────────────────────────────

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    acao   = params.get('acao', 'main')
    log('Acao=' + acao)

    if   acao == 'main':          mostrar_principal()
    elif acao == 'tipos':         mostrar_tipos(params['srv_idx'])
    elif acao == 'live_cats':     mostrar_categorias(params['srv_idx'], 'live_cats')
    elif acao == 'vod_cats':      mostrar_categorias(params['srv_idx'], 'vod_cats')
    elif acao == 'series_cats':   mostrar_categorias(params['srv_idx'], 'series_cats')
    elif acao == 'live_canais':   mostrar_live(params['srv_idx'], params.get('cat_id',''), params.get('cat_nome',''))
    elif acao == 'vod_canais':    mostrar_vod(params['srv_idx'], params.get('cat_id',''), params.get('cat_nome',''))
    elif acao == 'series_canais': mostrar_series(params['srv_idx'], params.get('cat_id',''), params.get('cat_nome',''))
    elif acao == 'series_eps':    mostrar_episodios(params['srv_idx'], params.get('series_id',''), params.get('serie_nome',''))
    elif acao == 'play':          reproduzir(params.get('url',''), params.get('nome',''), params.get('logo',''))
    else:                         mostrar_principal()
