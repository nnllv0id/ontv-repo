# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════════════════╗
# ║              OnTV — Configuração dos Servidores                  ║
# ║                                                                  ║
# ║  TIPOS SUPORTADOS:                                               ║
# ║                                                                  ║
# ║  1) Xtream Codes:                                                ║
# ║     'tipo': 'xtream'                                             ║
# ║     'host', 'username', 'password'                               ║
# ║                                                                  ║
# ║  2) MAC / Stalker Portal:                                        ║
# ║     'tipo': 'stalker'                                            ║
# ║     'host'  → URL do portal  ex: http://servidor.com/c/         ║
# ║     'mac'   → MAC address    ex: 00:1A:79:XX:XX:XX              ║
# ║                                                                  ║
# ║  3) M3U por URL:                                                 ║
# ║     'tipo': 'm3u'                                                ║
# ║     'url'  → URL da lista M3U                                    ║
# ╚══════════════════════════════════════════════════════════════════╝

SERVIDORES = [

    # ── Xtream Codes ─────────────────────────────────────────────────
    {
        'nome':     'Servidor 1',
        'tipo':     'xtream',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP011001752687394517',
        'password': '6574ccdc4d9d',
        'icon':     ''
    },
    {
        'nome':     'Servidor 2',
        'tipo':     'xtream',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP0111169657470300',
        'password': '087c139ad1ce',
        'icon':     ''
    },
    {
        'nome':     'Servidor 3',
        'tipo':     'xtream',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP0111170060852234',
        'password': '11704637543783',
        'icon':     ''
    },

    # ── MAC / Stalker Portal ──────────────────────────────────────────
    {
        'nome': 'Servidor 4',
        'tipo': 'stalker',
        'host': 'http://line.tvdsz.cc/c/',
        'mac':  '00:1A:79:B6:29:A3',
        'icon': ''
    },
    {
        'nome': 'Servidor 5',
        'tipo': 'stalker',
        'host': 'http://line.godofiptv.com/c/',
        'mac':  '00:1A:79:B5:AC:61',
        'icon': ''
    },
    {
        'nome': 'Servidor 6',
        'tipo': 'stalker',
        'host': 'http://mag.trexlive.me/c/',
        'mac':  '00:1A:79:B5:9A:31',
        'icon': ''
    },

]
