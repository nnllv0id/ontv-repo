# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════╗
# ║         OnTV — Configuração dos Servidores           ║
# ║  Formato Xtream Codes: host, username, password      ║
# ╚══════════════════════════════════════════════════════╝

SERVIDORES = [
    {
        'nome':     'Servidor 1',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP011001752687394517',
        'password': '6574ccdc4d9d',
        'icon':     ''
    },
    {
        'nome':     'Servidor 2',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP0111169657470300',
        'password': '087c139ad1ce',
        'icon':     ''
    },
    {
        'nome':     'Servidor 3',
        'host':     'http://vipfdedgevv.top:8080',
        'username': 'VIP0111170060852234',
        'password': '11704637543783',
        'icon':     ''
    },
]
