# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background
Monitoriza o player e reinicia streams .ts quando fecham por erro.
"""
import xbmc
import xbmcgui
import json
import os
import tempfile
import time

STREAM_FILE = os.path.join(tempfile.gettempdir(), 'ontv_stream.json')
STOP_FILE   = os.path.join(tempfile.gettempdir(), 'ontv_user_stop.flag')


def log(msg):
    xbmc.log('[OnTV Service] ' + str(msg), xbmc.LOGINFO)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def foi_utilizador():
    return os.path.exists(STOP_FILE)


def limpar_stop():
    try:
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)
    except Exception:
        pass


def eh_ts_live(url):
    if not url:
        return False
    return url.lower().split('?')[0].endswith('.ts') and url.startswith('http')


def _fazer_listitem(url, nome, logo):
    li = xbmcgui.ListItem(nome, path=url)
    li.setProperty('IsPlayable', 'true')
    li.setProperty('inputstream',                              'inputstream.ffmpegdirect')
    li.setProperty('inputstream.ffmpegdirect.stream_mode',    'ffmpegdirect')
    li.setProperty('inputstream.ffmpegdirect.open_mode',      'curl')
    li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
    li.setProperty('mimetype', 'video/mp2t')
    if logo:
        li.setArt({'thumb': logo, 'icon': logo})
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})
    return li


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._tempo_inicio   = 0
        self._reinicializacoes = 0  # contador de reinícios na janela inicial

    def onPlayBackStarted(self):
        limpar_stop()
        agora = time.time()
        # Se reiniciou após fecho inicial (< 10s), não resetar o tempo de início
        # para manter o contador de reinícios inicial
        if agora - self._tempo_inicio > 10:
            self._tempo_inicio     = agora
            self._reinicializacoes = 0
        log('Stream iniciado (reinícios iniciais: {})'.format(self._reinicializacoes))

    def onPlayBackStopped(self):
        xbmc.sleep(800)

        if foi_utilizador():
            log('Parado pelo utilizador — não reiniciar')
            limpar_stream()
            limpar_stop()
            self._reinicializacoes = 0
            return

        self._tratar_fecho()

    def onPlayBackEnded(self):
        xbmc.sleep(800)
        if foi_utilizador():
            return
        self._tratar_fecho()

    def _tratar_fecho(self):
        info = ler_stream()
        if not info:
            return

        url = info.get('url', '')
        if not eh_ts_live(url):
            return

        duracao = time.time() - self._tempo_inicio

        # Janela inicial (primeiros 10s): permitir apenas 1 reinício
        # Evita loop no Servidor 1 (descontinuidade de timestamps inicial)
        if duracao < 10:
            if self._reinicializacoes >= 1:
                log('Fecho em {}s — limite de reinícios iniciais atingido'.format(int(duracao)))
                return
            self._reinicializacoes += 1
            log('Fecho em {}s — reinício inicial {}/1'.format(int(duracao), self._reinicializacoes))
        else:
            log('Fecho em {}s — a reiniciar'.format(int(duracao)))

        xbmc.sleep(1500)

        if foi_utilizador():
            return

        nome = info.get('nome', '')
        logo = info.get('logo', '')
        xbmc.Player().play(url, _fazer_listitem(url, nome, logo))


def run():
    log('Serviço iniciado')
    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(10)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
