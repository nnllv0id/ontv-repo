# -*- coding: utf-8 -*-
"""
OnTV — Serviço de background
Monitoriza o player e reinicia streams .ts quando fecham por EOF inesperado.
"""
import xbmc
import xbmcgui
import json
import os
import tempfile

STREAM_FILE = os.path.join(tempfile.gettempdir(), 'ontv_stream.json')


def log(msg):
    xbmc.log('[OnTV Service] ' + str(msg), xbmc.LOGINFO)


def ler_stream():
    try:
        if os.path.exists(STREAM_FILE):
            with open(STREAM_FILE, 'r') as f:
                return json.load(f)
    except Exception:
        pass
    return None


def limpar_stream():
    try:
        if os.path.exists(STREAM_FILE):
            os.remove(STREAM_FILE)
    except Exception:
        pass


def eh_ts_live(url):
    if not url:
        return False
    return url.lower().split('?')[0].endswith('.ts') and url.startswith('http')


class OnTVPlayer(xbmc.Player):
    def __init__(self):
        super().__init__()
        self._parado    = False
        self._iniciado  = False

    def onPlayBackStarted(self):
        self._parado   = False
        self._iniciado = True
        log('Stream iniciado')

    def onPlayBackStopped(self):
        # Utilizador parou — não reiniciar
        log('Stream parado pelo utilizador')
        self._parado   = True
        self._iniciado = False
        limpar_stream()

    def onPlayBackEnded(self):
        # EOF — só reiniciar se não foi o utilizador a parar
        if self._parado or not self._iniciado:
            return

        info = ler_stream()
        if not info:
            return

        url = info.get('url', '')
        if not eh_ts_live(url):
            return

        log('EOF detectado — a reiniciar stream: ' + url[:80])
        xbmc.sleep(1500)

        # Verificar novamente se o utilizador não parou entretanto
        if self._parado:
            return

        nome = info.get('nome', '')
        logo = info.get('logo', '')
        li = xbmcgui.ListItem(nome, path=url)
        li.setProperty('IsPlayable', 'true')
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.stream_mode', 'ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'curl')
        li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
        li.setProperty('mimetype', 'video/mp2t')
        if logo:
            li.setArt({'thumb': logo, 'icon': logo})
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})
        self.play(url, li)


def run():
    log('Serviço iniciado')
    monitor = xbmc.Monitor()
    player  = OnTVPlayer()

    while not monitor.abortRequested():
        monitor.waitForAbort(10)

    log('Serviço terminado')


if __name__ == '__main__':
    run()
