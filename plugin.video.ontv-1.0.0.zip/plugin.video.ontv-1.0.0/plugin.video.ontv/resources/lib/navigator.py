# -*- coding: utf-8 -*-
"""
OnTV — Navigator v4
  - Servidores configurados pelo dono (servers.py)
  - Navegação por Grupos/Categorias da lista M3U
  - Reprodução via F4mTester ou player nativo
"""

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# ── Compatibilidade Python 2/3 ────────────────────────────────────────────
try:
    from urllib.request import urlopen, Request
    from urllib.parse   import urlencode, parse_qsl
    PY3 = True
except ImportError:
    from urllib2  import urlopen, Request
    from urllib   import urlencode
    from urlparse import parse_qsl
    PY3 = False

# ── Constantes ────────────────────────────────────────────────────────────
ADDON       = xbmcaddon.Addon()
ADDON_ID    = ADDON.getAddonInfo('id')
ADDON_NAME  = ADDON.getAddonInfo('name')
ADDON_PATH  = ADDON.getAddonInfo('path')
HANDLE      = int(sys.argv[1])
BASE_URL    = sys.argv[0]
ICON        = os.path.join(ADDON_PATH, 'icon.png')
FANART      = os.path.join(ADDON_PATH, 'fanart.jpg')

# ── F4mTester ─────────────────────────────────────────────────────────────
F4M_ADDON_ID = 'plugin.video.f4mtester'

# ── User-Agent ────────────────────────────────────────────────────────────
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0'

# ── Cache por sessão ──────────────────────────────────────────────────────
_CACHE = {}


# ════════════════════════════════════════════════════════════════════════════
#  UTILITÁRIOS
# ════════════════════════════════════════════════════════════════════════════

def log(msg):
    xbmc.log('[OnTV] {0}'.format(msg), xbmc.LOGDEBUG)


def cor(texto, c):
    return '[COLOR {0}]{1}[/COLOR]'.format(c, texto)


def url_para(params):
    return BASE_URL + '?' + urlencode(params)


def notificar(msg, tipo=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, tipo, ms)


def f4m_disponivel():
    """Verifica se o F4mTester está instalado."""
    try:
        import xbmcaddon as xa
        xa.Addon(F4M_ADDON_ID)
        return True
    except Exception:
        return False


# ════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD E PARSE M3U
# ════════════════════════════════════════════════════════════════════════════

def descarregar_m3u(url):
    """Descarrega lista M3U com cache por sessão."""
    if url in _CACHE:
        return _CACHE[url]
    try:
        req  = Request(url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=15)
        txt  = resp.read().decode('utf-8', errors='replace')
        _CACHE[url] = txt
        return txt
    except Exception as e:
        log('ERRO download: ' + str(e))
        return None


def parse_m3u(conteudo):
    """
    Parseia lista M3U.
    Devolve lista de dicts: {nome, url, grupo, logo}
    """
    canais = []
    linhas = conteudo.splitlines()
    i = 0
    while i < len(linhas):
        linha = linhas[i].strip()
        if linha.startswith('#EXTINF'):
            ch = {'nome': 'Canal', 'url': '', 'grupo': 'Sem Grupo', 'logo': ''}

            def atr(padrao):
                m = re.search(padrao, linha, re.IGNORECASE)
                return m.group(1).strip() if m else ''

            tvg_nome     = atr(r'tvg-name="([^"]*)"')
            ch['logo']   = atr(r'tvg-logo="([^"]*)"')
            grupo_raw    = atr(r'group-title="([^"]*)"')
            ch['grupo']  = grupo_raw.strip() if grupo_raw.strip() else 'Sem Grupo'

            virgula = linha.rfind(',')
            if virgula != -1:
                ch['nome'] = linha[virgula + 1:].strip()
            elif tvg_nome:
                ch['nome'] = tvg_nome

            # Próxima linha com URL
            i += 1
            while i < len(linhas):
                prox = linhas[i].strip()
                if prox and not prox.startswith('#'):
                    ch['url'] = prox
                    break
                i += 1

            if ch['url']:
                canais.append(ch)
        i += 1
    return canais


def extrair_grupos(canais):
    """Extrai grupos únicos mantendo ordem de aparição."""
    vistos = {}
    ordem  = []
    for ch in canais:
        g = ch['grupo']
        if g not in vistos:
            vistos[g] = []
            ordem.append(g)
        vistos[g].append(ch)
    return [{'nome': g, 'canais': vistos[g]} for g in ordem]


# ════════════════════════════════════════════════════════════════════════════
#  ADICIONAR ITEM
# ════════════════════════════════════════════════════════════════════════════

def add_item(titulo, url_acao, thumb=None, fanart=None, pasta=True, info=None):
    li = xbmcgui.ListItem(titulo)
    li.setArt({
        'thumb':  thumb  or ICON,
        'icon':   thumb  or ICON,
        'fanart': fanart or FANART,
    })
    if not pasta:
        li.setProperty('IsPlayable', 'true')
    if info:
        li.setInfo('video', info)
    xbmcplugin.addDirectoryItem(HANDLE, url_acao, li, pasta)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 1 — MENU PRINCIPAL (Servidores)
# ════════════════════════════════════════════════════════════════════════════

def mostrar_principal():
    from servers import SERVIDORES

    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')

    if not SERVIDORES:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Nenhum servidor configurado.')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for srv in SERVIDORES:
        titulo = cor('📡  ' + srv['nome'], 'gold')
        thumb  = srv.get('icon') or ICON
        acao   = url_para({
            'acao':     'grupos',
            'srv_url':  srv['url'],
            'srv_nome': srv['nome']
        })
        add_item(titulo, acao, thumb=thumb, pasta=True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 2 — GRUPOS / CATEGORIAS
# ════════════════════════════════════════════════════════════════════════════

def mostrar_grupos(srv_url, srv_nome):
    xbmcplugin.setPluginCategory(HANDLE, srv_nome)

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, 'A carregar ' + srv_nome + '...')
    dp.update(10)

    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        dp.close()
        notificar('Erro ao carregar a lista!', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp.update(50, 'A processar canais...')
    canais = parse_m3u(conteudo)

    if not canais:
        dp.close()
        notificar('Nenhum canal encontrado.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp.update(80, 'A organizar grupos...')
    grupos = extrair_grupos(canais)
    dp.update(100)
    dp.close()

    log('{0} canais | {1} grupos'.format(len(canais), len(grupos)))

    # ── "Ver Todos" no topo ──────────────────────────────────────────────
    li_all = xbmcgui.ListItem(cor('📋  Ver Todos os Canais  ({0})'.format(len(canais)), 'orange'))
    li_all.setArt({'thumb': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        url_para({'acao': 'canais', 'srv_url': srv_url, 'srv_nome': srv_nome, 'grupo': '__ALL__'}),
        li_all, True
    )

    # ── Grupos ───────────────────────────────────────────────────────────
    for g in grupos:
        n       = len(g['canais'])
        titulo  = cor('📂  ' + g['nome'], 'deepskyblue') + cor('  ({0})'.format(n), 'grey')
        thumb   = g['canais'][0].get('logo') or ICON
        acao    = url_para({
            'acao':     'canais',
            'srv_url':  srv_url,
            'srv_nome': srv_nome,
            'grupo':    g['nome']
        })
        add_item(titulo, acao, thumb=thumb, pasta=True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 3 — CANAIS
# ════════════════════════════════════════════════════════════════════════════

def mostrar_canais(srv_url, srv_nome, grupo):
    label = srv_nome + (' — ' + grupo if grupo != '__ALL__' else ' — Todos os Canais')
    xbmcplugin.setPluginCategory(HANDLE, label)

    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        notificar('Erro ao carregar a lista!', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    canais = parse_m3u(conteudo)
    if grupo != '__ALL__':
        canais = [ch for ch in canais if ch['grupo'] == grupo]

    if not canais:
        notificar('Sem canais neste grupo.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for ch in canais:
        titulo = cor(ch['nome'], 'white')
        thumb  = ch.get('logo') or ICON
        acao   = url_para({
            'acao': 'play',
            'url':  ch['url'],
            'nome': ch['nome'],
            'logo': thumb
        })
        li = xbmcgui.ListItem(titulo)
        li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': ch['nome'], 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(HANDLE, acao, li, False)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 4 — REPRODUÇÃO via F4mTester
# ════════════════════════════════════════════════════════════════════════════

def reproduzir(stream_url, nome='', logo=''):
    log('A reproduzir: ' + stream_url)

    if f4m_disponivel():
        # ── Abrir com F4mTester ──────────────────────────────────────────
        log('A usar F4mTester')
        params = {
            'url':   stream_url,
            'name':  nome,
            'thumb': logo or ICON,
        }
        f4m_url = 'plugin://{0}/?{1}'.format(F4M_ADDON_ID, urlencode(params))
        xbmc.executebuiltin('RunAddon({0},{1})'.format(
            F4M_ADDON_ID,
            urlencode(params)
        ))
    else:
        # ── Fallback: player nativo do Kodi ─────────────────────────────
        log('F4mTester não encontrado, a usar player nativo')
        notificar('F4mTester não instalado — a usar player nativo', ms=3000)
        li = xbmcgui.ListItem(nome, path=stream_url)
        li.setArt({'thumb': logo or ICON})
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})
        li.setMimeType('video/x-mpegts')
        li.setContentLookup(False)
        li.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=' + UA)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ════════════════════════════════════════════════════════════════════════════
#  ROTEADOR
# ════════════════════════════════════════════════════════════════════════════

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    acao   = params.get('acao', 'main')
    log('Acao={0}'.format(acao))

    if acao == 'main':
        mostrar_principal()

    elif acao == 'grupos':
        mostrar_grupos(
            srv_url  = params.get('srv_url', ''),
            srv_nome = params.get('srv_nome', '')
        )

    elif acao == 'canais':
        mostrar_canais(
            srv_url  = params.get('srv_url', ''),
            srv_nome = params.get('srv_nome', ''),
            grupo    = params.get('grupo', '__ALL__')
        )

    elif acao == 'play':
        reproduzir(
            stream_url = params.get('url', ''),
            nome       = params.get('nome', ''),
            logo       = params.get('logo', '')
        )

    else:
        mostrar_principal()
