# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════╗
# ║         OnTV — Configuração dos Servidores           ║
# ║                                                      ║
# ║  Edita este ficheiro para gerir as tuas listas M3U.  ║
# ║  O utilizador NÃO tem acesso a estas configurações.  ║
# ║                                                      ║
# ║  Para atualizar uma lista:                           ║
# ║    1. Altera o 'url' do servidor pretendido          ║
# ║    2. Guarda o ficheiro                              ║
# ║    3. Recria o ZIP e faz upload no GitHub            ║
# ║    4. Bump a versão no addon.xml (ex: 1.0.1)         ║
# ║    5. O Kodi atualiza automaticamente                ║
# ╚══════════════════════════════════════════════════════╝

SERVIDORES = [

    {
        'nome': 'Servidor 1',
        'url':  'http://fastream.xyz:8080/get.php?username=968224180tv&password=a5gbmtw&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 2',
        'url':  'http://xxip25.top:8080/get.php?username=nbbBC6&password=364068&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 3',
        'url':  'http://xxip25.top:8080/get.php?username=markelljoiner39@yahoo.com&password=E9ekXswnXg&type=m3u',
        'icon': ''
    },

    # Para adicionar mais servidores, copia o bloco acima e cola aqui
    # {
    #     'nome': 'Servidor 4',
    #     'url':  'https://URL_DA_TUA_LISTA_4.m3u',
    #     'icon': ''
    # },

]
