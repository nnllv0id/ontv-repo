# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║              OnTV — Configuração dos Servidores              ║
║                                                              ║
║  Edita este ficheiro para gerir as tuas listas M3U.          ║
║  O utilizador NÃO tem acesso a estas configurações.          ║
║                                                              ║
║  Formato de cada servidor:                                   ║
║  {                                                           ║
║    'nome': 'Nome visível no menu',                           ║
║    'url':  'https://url-da-lista.m3u',                       ║
║    'icon': 'https://url-do-icone.png' (opcional)             ║
║  }                                                           ║
║                                                              ║
║  Para desativar um servidor temporariamente,                 ║
║  basta comentar a linha com #                                ║
╚══════════════════════════════════════════════════════════════╝
"""

SERVIDORES = [

    {
        'nome': 'Servidor 1',
        'url':  'http://cord-cutter.net:8080/get.php?username=gsands&password=G2423942879S&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 2',
        'url':  'http://xxip25.top:8080/get.php?username=wp7QUk&password=075714&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 3',
        'url':  'http://fastream.xyz:8080/get.php?username=galymercy&password=mercy1313&type=m3u',
        'icon': ''
    },

    # Adiciona mais servidores aqui seguindo o mesmo formato...
    {
        'nome': 'Servidor 4',
        'url':  'http://xxip25.top:8080/get.php?username=z1tT4E&password=112872&type=m3u',
        'icon': ''
    },

]
