# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════╗
║              OnTV — Configuração dos Servidores              ║
║                                                              ║
║  Edita este ficheiro para gerir as tuas listas M3U.          ║
║  O utilizador NÃO tem acesso a estas configurações.          ║
║                                                              ║
║  Formato de cada servidor:                                   ║
║  {                                                           ║
║    'nome': 'Nome visível no menu',                           ║
║    'url':  'https://url-da-lista.m3u',                       ║
║    'icon': 'https://url-do-icone.png' (opcional)             ║
║  }                                                           ║
║                                                              ║
║  Para desativar um servidor temporariamente,                 ║
║  basta comentar a linha com #                                ║
╚══════════════════════════════════════════════════════════════╝
"""

SERVIDORES = [

    {
        'nome': 'Servidor 1',
        'url':  'http://fortv.cc:8080/get.php?username=cliff.kutney@rogers.com&password=Qr42PWjQPb&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 2',
        'url':  'http://xxip25.top:8080/get.php?username=Jrutanga&password=Jujujacobrutanga&type=m3u',
        'icon': ''
    },

    {
        'nome': 'Servidor 3',
        'url':  'http://fastream.xyz:8080/get.php?username=968224180tv&password=a5gbmtw&type=m3u',
        'icon': ''
    },

    # Adiciona mais servidores aqui seguindo o mesmo formato...
    # {
    #     'nome': 'Servidor 4',
    #     'url':  'https://URL_DA_TUA_LISTA_4.m3u',
    #     'icon': ''
    # },

]
