# -*- coding: utf-8 -*-
# OnTV - default.py

import sys
import os
import xbmcaddon

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
LIB_PATH   = os.path.join(ADDON_PATH, 'resources', 'lib')
sys.path.insert(0, LIB_PATH)

from navigator import run

if __name__ == '__main__':
    run()
