# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════╗
# ║         OnTV — Configuração dos Servidores           ║
# ║  Formato Xtream Codes: host, username, password      ║
# ╚══════════════════════════════════════════════════════╝

SERVIDORES = [
    {
        'nome':     'Servidor 1',
        'host':     'http://xxip25.top:8080',
        'username': 'markelljoiner39@yahoo.com',
        'password': 'E9ekXswnXg',
        'icon':     ''
    },
    {
        'nome':     'Servidor 2',
        'host':     'http://fastream.xyz:8080',
        'username': '968224180tv',
        'password': 'a5gbmtw',
        'icon':     ''
    },
    {
        'nome':     'Servidor 3',
        'host':     'http://xxip25.top:8080',
        'username': 'nbbBC6',
        'password': '364068',
        'icon':     ''
    },
]
