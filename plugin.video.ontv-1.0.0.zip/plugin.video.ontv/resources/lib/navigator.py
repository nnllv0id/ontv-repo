# -*- coding: utf-8 -*-
import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.parse   import urlencode, parse_qsl
except ImportError:
    from urllib2  import urlopen, Request
    from urllib   import urlencode
    from urlparse import parse_qsl

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.jpg')
UA         = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/21.0'
F4M_ID     = 'plugin.video.f4mTester'
_CACHE     = {}


def log(msg):
    xbmc.log('[OnTV] ' + str(msg), xbmc.LOGDEBUG)

def url_para(params):
    return BASE_URL + '?' + urlencode(params)

def notificar(msg, tipo=xbmcgui.NOTIFICATION_ERROR):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, tipo, 4000)


def descarregar_m3u(url):
    if url in _CACHE:
        return _CACHE[url]
    try:
        req  = Request(url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=15)
        txt  = resp.read().decode('utf-8', errors='replace')
        _CACHE[url] = txt
        return txt
    except Exception as e:
        log('ERRO download: ' + str(e))
        return None


def parse_m3u(conteudo):
    canais = []
    linhas = conteudo.splitlines()
    i = 0
    while i < len(linhas):
        linha = linhas[i].strip()
        if linha.startswith('#EXTINF'):
            ch = {'nome': 'Canal', 'url': '', 'grupo': 'Sem Grupo', 'logo': ''}

            def atr(padrao, src=linha):
                m = re.search(padrao, src, re.IGNORECASE)
                return m.group(1).strip() if m else ''

            ch['logo']  = atr(r'tvg-logo="([^"]*)"')
            grupo_raw   = atr(r'group-title="([^"]*)"')
            ch['grupo'] = grupo_raw.strip() if grupo_raw.strip() else 'Sem Grupo'
            virgula     = linha.rfind(',')
            ch['nome']  = linha[virgula + 1:].strip() if virgula != -1 else 'Canal'

            i += 1
            while i < len(linhas):
                prox = linhas[i].strip()
                if prox and not prox.startswith('#'):
                    ch['url'] = prox
                    break
                i += 1

            if ch['url']:
                canais.append(ch)
        i += 1
    return canais


def extrair_grupos(canais):
    vistos = {}
    ordem  = []
    for ch in canais:
        g = ch['grupo']
        if g not in vistos:
            vistos[g] = []
            ordem.append(g)
        vistos[g].append(ch)
    return [{'nome': g, 'canais': vistos[g]} for g in ordem]


# Ecrã 1 — Servidores
def mostrar_principal():
    from servers import SERVIDORES
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')

    for srv in SERVIDORES:
        li = xbmcgui.ListItem(srv['nome'])
        li.setArt({'thumb': srv.get('icon') or ICON, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'grupos', 'srv_url': srv['url'], 'srv_nome': srv['nome']}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# Ecrã 2 — Grupos/Categorias
def mostrar_grupos(srv_url, srv_nome):
    xbmcplugin.setPluginCategory(HANDLE, srv_nome)

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, 'A carregar ' + srv_nome + '...')
    dp.update(10)
    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        dp.close()
        notificar('Erro ao carregar a lista!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp.update(60, 'A processar...')
    canais = parse_m3u(conteudo)
    grupos = extrair_grupos(canais)
    dp.update(100)
    dp.close()

    for g in grupos:
        thumb = g['canais'][0].get('logo') or ICON
        li = xbmcgui.ListItem(g['nome'])
        li.setArt({'thumb': thumb, 'fanart': FANART})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'canais', 'srv_url': srv_url, 'srv_nome': srv_nome, 'grupo': g['nome']}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# Ecrã 3 — Canais
def mostrar_canais(srv_url, srv_nome, grupo):
    xbmcplugin.setPluginCategory(HANDLE, grupo)

    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        notificar('Erro ao carregar a lista!')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    canais = parse_m3u(conteudo)
    canais = [ch for ch in canais if ch['grupo'] == grupo]

    for ch in canais:
        thumb = ch.get('logo') or ICON
        li = xbmcgui.ListItem(ch['nome'])
        li.setArt({'thumb': thumb, 'fanart': FANART})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': ch['nome'], 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'play', 'url': ch['url'], 'nome': ch['nome'], 'logo': thumb}),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# Ecrã 4 — Reprodução via F4mTester
def reproduzir(stream_url, nome='', logo=''):
    log('F4mTester: ' + stream_url)
    params = urlencode({'url': stream_url, 'name': nome, 'iconImage': logo or ICON, 'streamtype': 'HLS'})
    f4m_url = 'plugin://{0}/?{1}'.format(F4M_ID, params)
    li = xbmcgui.ListItem(nome, path=f4m_url)
    li.setArt({'thumb': logo or ICON})
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# Roteador
def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    acao   = params.get('acao', 'main')

    if   acao == 'main':    mostrar_principal()
    elif acao == 'grupos':  mostrar_grupos(params.get('srv_url', ''), params.get('srv_nome', ''))
    elif acao == 'canais':  mostrar_canais(params.get('srv_url', ''), params.get('srv_nome', ''), params.get('grupo', ''))
    elif acao == 'play':    reproduzir(params.get('url', ''), params.get('nome', ''), params.get('logo', ''))
    else:                   mostrar_principal()
