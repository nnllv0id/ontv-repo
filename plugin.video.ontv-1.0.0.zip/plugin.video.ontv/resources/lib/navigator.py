# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════╗
║                    OnTV — Navigator                      ║
║         O Seu Portal IPTV ao estilo KodiLoucos           ║
╚══════════════════════════════════════════════════════════╝

Fluxo de navegação:
  main()        → Menu Principal  (lista de Servidores ativos)
  grupos()      → Grupos/Cats     (extraídos automaticamente da M3U)
  canais()      → Canais          (filtrados por grupo)
  reproduzir()  → Playback        (stream direto)
"""

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# ── Compatibilidade Python 2/3 ───────────────────────────────────────────────
try:
    from urllib.request import urlopen, Request
    from urllib.parse   import urlencode, parse_qsl, quote_plus
    PY3 = True
except ImportError:
    from urllib2  import urlopen, Request
    from urllib   import urlencode, quote_plus
    from urlparse import parse_qsl
    PY3 = False

# ── Constantes globais ───────────────────────────────────────────────────────
ADDON         = xbmcaddon.Addon()
ADDON_ID      = ADDON.getAddonInfo('id')
ADDON_NAME    = ADDON.getAddonInfo('name')
ADDON_PATH    = ADDON.getAddonInfo('path')
HANDLE        = int(sys.argv[1])
BASE_URL      = sys.argv[0]
ICON          = os.path.join(ADDON_PATH, 'icon.png')
FANART        = os.path.join(ADDON_PATH, 'fanart.jpg')
MAX_SERV      = 10

# ── Definições do utilizador ─────────────────────────────────────────────────
def _s(key, fallback=''):
    try:
        return ADDON.getSetting(key)
    except Exception:
        return fallback

DEV_MODE       = _s('dev_mode')        == 'true'
USE_IS         = _s('use_inputstream') == 'true'
USE_CACHE      = _s('use_cache')       == 'true'
TIMEOUT        = int(_s('timeout') or 15)
UA             = _s('user_agent') or 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/20.0'
COR_SERV       = _s('cor_servidor')    or 'gold'
COR_GRUPO      = _s('cor_grupo')       or 'deepskyblue'
COR_CANAL      = _s('cor_canal')       or 'white'
MOSTRAR_COUNT  = _s('mostrar_contagem') == 'true'
ICONE_SERV     = _s('icone_servidor')   or '📡'

# Cache em memória (por sessão)
_CACHE = {}


# ════════════════════════════════════════════════════════════════════════════
#  UTILITÁRIOS
# ════════════════════════════════════════════════════════════════════════════

def log(msg):
    if DEV_MODE:
        xbmc.log('[OnTV] {0}'.format(msg), xbmc.LOGDEBUG)


def cor(texto, c):
    return '[COLOR {0}]{1}[/COLOR]'.format(c, texto)


def url_para(params):
    return BASE_URL + '?' + urlencode(params)


def notificar(msg, tipo=xbmcgui.NOTIFICATION_INFO, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, tipo, ms)


def get_servidores():
    """Devolve lista de servidores ativos (com URL preenchida)."""
    servs = []
    for i in range(1, MAX_SERV + 1):
        nome = _s('s{0}_nome'.format(i)) or 'Servidor {0}'.format(i)
        url  = _s('s{0}_url'.format(i)).strip()
        if url:
            servs.append({'idx': i, 'nome': nome, 'url': url})
    return servs


# ════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD E PARSE DE M3U
# ════════════════════════════════════════════════════════════════════════════

def descarregar_m3u(url):
    """Descarrega conteúdo M3U com cache por sessão."""
    if USE_CACHE and url in _CACHE:
        log('Cache hit: ' + url)
        return _CACHE[url]
    try:
        log('A descarregar: ' + url)
        req  = Request(url, headers={'User-Agent': UA})
        resp = urlopen(req, timeout=TIMEOUT)
        raw  = resp.read()
        txt  = raw.decode('utf-8', errors='replace')
        if USE_CACHE:
            _CACHE[url] = txt
        return txt
    except Exception as e:
        log('ERRO download: ' + str(e))
        return None


def parse_m3u(conteudo):
    """
    Parseia lista M3U.
    Devolve lista de dicts: {nome, url, grupo, logo, tvg_id}
    """
    canais = []
    linhas = conteudo.splitlines()
    i = 0
    while i < len(linhas):
        linha = linhas[i].strip()
        if linha.startswith('#EXTINF'):
            ch = {'nome': '', 'url': '', 'grupo': 'Sem Grupo', 'logo': '', 'tvg_id': ''}

            def atr(padrao, src=linha):
                m = re.search(padrao, src, re.IGNORECASE)
                return m.group(1).strip() if m else ''

            ch['tvg_id'] = atr(r'tvg-id="([^"]*)"')
            tvg_nome     = atr(r'tvg-name="([^"]*)"')
            ch['logo']   = atr(r'tvg-logo="([^"]*)"')
            grupo_raw    = atr(r'group-title="([^"]*)"')
            ch['grupo']  = grupo_raw if grupo_raw else 'Sem Grupo'

            virgula = linha.rfind(',')
            if virgula != -1:
                ch['nome'] = linha[virgula + 1:].strip()
            elif tvg_nome:
                ch['nome'] = tvg_nome
            else:
                ch['nome'] = 'Canal Desconhecido'

            # Avançar para a linha da URL (ignorar comentários e linhas vazias)
            i += 1
            while i < len(linhas):
                prox = linhas[i].strip()
                if prox and not prox.startswith('#'):
                    ch['url'] = prox
                    break
                i += 1

            if ch['url']:
                canais.append(ch)
        i += 1
    return canais


def extrair_grupos(canais):
    """Extrai grupos únicos mantendo ordem de aparição."""
    vistos  = {}
    ordem   = []
    for ch in canais:
        g = ch['grupo']
        if g not in vistos:
            vistos[g] = []
            ordem.append(g)
        vistos[g].append(ch)
    return [{'nome': g, 'canais': vistos[g]} for g in ordem]


# ════════════════════════════════════════════════════════════════════════════
#  ADICIONAR ITEM AO KODI
# ════════════════════════════════════════════════════════════════════════════

def add_item(titulo, url_acao, thumb=None, fanart=None,
             pasta=True, stream=None, info=None):
    li = xbmcgui.ListItem(titulo)
    li.setArt({
        'thumb':  thumb  or ICON,
        'icon':   thumb  or ICON,
        'fanart': fanart or FANART,
    })
    if not pasta and stream:
        li.setProperty('IsPlayable', 'true')
        li.setPath(stream)
    if info:
        li.setInfo('video', info)
    xbmcplugin.addDirectoryItem(HANDLE, url_acao, li, pasta)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 1 — MENU PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════

def mostrar_principal():
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV')
    servs = get_servidores()

    if not servs:
        # Sem servidores → diálogo de boas-vindas
        xbmcgui.Dialog().ok(
            'Bem-vindo ao OnTV!',
            'Ainda não tem servidores configurados.\n\n'
            'Clique em  ⚙️ Configurar Servidores  e adicione\n'
            'o nome e a URL M3U de cada servidor.'
        )

    # ── Secção: Servidores ativos ────────────────────────────────────────────
    if servs:
        for s in servs:
            titulo = cor('{0}  {1}'.format(ICONE_SERV, s['nome']), COR_SERV)
            acao   = url_para({'acao': 'grupos', 'srv_url': s['url'], 'srv_nome': s['nome']})
            add_item(titulo, acao, thumb=ICON, fanart=FANART, pasta=True)

        # Separador visual: "Ver Tudo" de todos os servidores combinados
        if len(servs) > 1:
            titulo_all = cor('🌐  Todos os Servidores (combinado)', 'orange')
            acao_all   = url_para({'acao': 'todos'})
            add_item(titulo_all, acao_all, thumb=ICON, fanart=FANART, pasta=True)

    # ── Rodapé: configurações ────────────────────────────────────────────────
    li_cfg = xbmcgui.ListItem(cor('⚙️  Configurar Servidores', 'grey'))
    li_cfg.setArt({'thumb': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(HANDLE, url_para({'acao': 'config'}), li_cfg, False)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 2 — GRUPOS / CATEGORIAS
# ════════════════════════════════════════════════════════════════════════════

def mostrar_grupos(srv_url, srv_nome):
    xbmcplugin.setPluginCategory(HANDLE, srv_nome)

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, 'A carregar lista...')
    dp.update(5, srv_nome + ' — A ligar...')

    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        dp.close()
        notificar('Erro ao carregar a lista M3U!', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp.update(45, 'A processar canais...')
    canais = parse_m3u(conteudo)
    if not canais:
        dp.close()
        notificar('Nenhum canal encontrado.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp.update(80, 'A construir grupos...')
    grupos = extrair_grupos(canais)
    dp.update(100)
    dp.close()

    log('{0} canais | {1} grupos | {2}'.format(len(canais), len(grupos), srv_nome))

    # ── "Ver Todos" no topo ──────────────────────────────────────────────────
    li_all = xbmcgui.ListItem(cor('📋  Ver Todos os Canais ({0})'.format(len(canais)), 'gold'))
    li_all.setArt({'thumb': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        url_para({'acao': 'canais', 'srv_url': srv_url, 'srv_nome': srv_nome, 'grupo': '__ALL__'}),
        li_all, True
    )

    # ── Grupos ───────────────────────────────────────────────────────────────
    for g in grupos:
        n_canais  = len(g['canais'])
        count_txt = cor('  ({0})'.format(n_canais), 'grey') if MOSTRAR_COUNT else ''
        titulo    = cor('📂  ' + g['nome'], COR_GRUPO) + count_txt
        thumb     = g['canais'][0].get('logo') or ICON

        acao = url_para({
            'acao':     'canais',
            'srv_url':  srv_url,
            'srv_nome': srv_nome,
            'grupo':    g['nome'].encode('utf-8') if not PY3 else g['nome']
        })
        add_item(titulo, acao, thumb=thumb, pasta=True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 2b — TODOS OS SERVIDORES COMBINADOS
# ════════════════════════════════════════════════════════════════════════════

def mostrar_todos():
    xbmcplugin.setPluginCategory(HANDLE, 'OnTV — Todos os Servidores')
    servs = get_servidores()
    if not servs:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, 'A carregar todos os servidores...')

    todos_canais = []
    for idx, s in enumerate(servs):
        perc = int((idx / len(servs)) * 90)
        dp.update(perc, 'A carregar: ' + s['nome'])
        c = descarregar_m3u(s['url'])
        if c:
            parsed = parse_m3u(c)
            for ch in parsed:
                ch['grupo'] = '[{0}] {1}'.format(s['nome'], ch['grupo'])
            todos_canais.extend(parsed)

    dp.update(95, 'A construir grupos...')
    grupos = extrair_grupos(todos_canais)
    dp.update(100)
    dp.close()

    li_all = xbmcgui.ListItem(cor('📋  Ver Todos ({0} canais)'.format(len(todos_canais)), 'gold'))
    li_all.setArt({'thumb': ICON, 'fanart': FANART})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        url_para({'acao': 'canais_lista', 'ids': ','.join([s['url'] for s in servs]), 'grupo': '__ALL__'}),
        li_all, True
    )

    for g in grupos:
        n_canais  = len(g['canais'])
        count_txt = cor('  ({0})'.format(n_canais), 'grey') if MOSTRAR_COUNT else ''
        titulo    = cor('📂  ' + g['nome'], COR_GRUPO) + count_txt
        thumb     = g['canais'][0].get('logo') or ICON
        acao = url_para({'acao': 'canais_lista', 'ids': ','.join([s['url'] for s in servs]), 'grupo': g['nome']})
        add_item(titulo, acao, thumb=thumb, pasta=True)

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 3 — LISTA DE CANAIS
# ════════════════════════════════════════════════════════════════════════════

def mostrar_canais(srv_url, srv_nome, grupo):
    label = srv_nome + (' — ' + grupo if grupo != '__ALL__' else ' — Todos os Canais')
    xbmcplugin.setPluginCategory(HANDLE, label)

    conteudo = descarregar_m3u(srv_url)
    if not conteudo:
        notificar('Erro ao carregar a lista!', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    canais = parse_m3u(conteudo)
    if grupo != '__ALL__':
        canais = [ch for ch in canais if ch['grupo'] == grupo]

    if not canais:
        notificar('Sem canais neste grupo.', xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for ch in canais:
        titulo  = cor(ch['nome'], COR_CANAL)
        thumb   = ch.get('logo') or ICON
        play_u  = url_para({'acao': 'play', 'url': ch['url'],
                            'nome': ch['nome'], 'logo': thumb})
        add_item(
            titulo, play_u,
            thumb=thumb, pasta=False,
            stream=ch['url'],
            info={'title': ch['nome'], 'mediatype': 'video'}
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


def mostrar_canais_multi(ids_str, grupo):
    """Canais de múltiplos servidores (modo combinado)."""
    urls   = ids_str.split(',')
    label  = 'Todos os Servidores' + (' — ' + grupo if grupo != '__ALL__' else ' — Todos')
    xbmcplugin.setPluginCategory(HANDLE, label)

    canais_all = []
    for u in urls:
        c = descarregar_m3u(u)
        if c:
            canais_all.extend(parse_m3u(c))

    if grupo != '__ALL__':
        canais_all = [ch for ch in canais_all if grupo in ch['grupo']]

    for ch in canais_all:
        titulo = cor(ch['nome'], COR_CANAL)
        thumb  = ch.get('logo') or ICON
        play_u = url_para({'acao': 'play', 'url': ch['url'],
                           'nome': ch['nome'], 'logo': thumb})
        add_item(titulo, play_u, thumb=thumb, pasta=False,
                 stream=ch['url'], info={'title': ch['nome'], 'mediatype': 'video'})

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE)


# ════════════════════════════════════════════════════════════════════════════
#  ECRÃ 4 — REPRODUÇÃO
# ════════════════════════════════════════════════════════════════════════════

def reproduzir(stream_url, nome='', logo=''):
    log('A reproduzir: ' + stream_url)
    li = xbmcgui.ListItem(nome, path=stream_url)
    li.setArt({'thumb': logo or ICON, 'icon': logo or ICON, 'fanart': FANART})
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})
    li.setMimeType('video/x-mpegts')
    li.setContentLookup(False)

    url_lower = stream_url.lower()

    if USE_IS and ('.m3u8' in url_lower or '.mpd' in url_lower):
        try:
            li.setProperty('inputstream', 'inputstream.adaptive')
            manifest = 'mpd' if '.mpd' in url_lower else 'hls'
            li.setProperty('inputstream.adaptive.manifest_type', manifest)
            li.setProperty('inputstream.adaptive.stream_headers',
                           'User-Agent=' + UA)
        except Exception as e:
            log('InputStream error: ' + str(e))
    else:
        # Stream direto (TS, RTMP, etc.)
        li.setProperty('inputstream.adaptive.stream_headers',
                       'User-Agent=' + UA)

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ════════════════════════════════════════════════════════════════════════════
#  ROTEADOR PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    acao   = params.get('acao', 'main')
    log('Ação={0} | Params={1}'.format(acao, params))

    if acao == 'main':
        mostrar_principal()

    elif acao == 'grupos':
        mostrar_grupos(
            srv_url  = params.get('srv_url', ''),
            srv_nome = params.get('srv_nome', 'Servidor')
        )

    elif acao == 'todos':
        mostrar_todos()

    elif acao == 'canais':
        mostrar_canais(
            srv_url  = params.get('srv_url', ''),
            srv_nome = params.get('srv_nome', 'Servidor'),
            grupo    = params.get('grupo', '__ALL__')
        )

    elif acao == 'canais_lista':
        mostrar_canais_multi(
            ids_str = params.get('ids', ''),
            grupo   = params.get('grupo', '__ALL__')
        )

    elif acao == 'play':
        reproduzir(
            stream_url = params.get('url', ''),
            nome       = params.get('nome', ''),
            logo       = params.get('logo', '')
        )

    elif acao == 'config':
        ADDON.openSettings()

    else:
        mostrar_principal()
