# -*- coding: utf-8 -*-
# ╔══════════════════════════════════════════════════════╗
# ║         OnTV — Configuração dos Servidores           ║
# ║  Para atualizar: edita as URLs e envia ao Claude     ║
# ║  para gerar novo ZIP                                 ║
# ╚══════════════════════════════════════════════════════╝

SERVIDORES = [
    {
        'nome': 'Servidor 1',
        'url':  'http://xxip25.top:8080/get.php?username=markelljoiner39@yahoo.com&password=E9ekXswnXg&type=m3u',
        'icon': ''
    },
    {
        'nome': 'Servidor 2',
        'url':  'http://fastream.xyz:8080/get.php?username=968224180tv&password=a5gbmtw&type=m3u',
        'icon': ''
    },
    {
        'nome': 'Servidor 3',
        'url':  'http://xxip25.top:8080/get.php?username=nbbBC6&password=364068&type=m3u',
        'icon': ''
    },
]
