# -*- coding: utf-8 -*-
"""
DaddyLive — Resolver de Streams
Obtém os links de stream a partir das páginas de player do DaddyLive.
Suporta os vários tipos de player usados pelo site.
"""

import re
import json
import base64
import xbmc

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, urlparse, quote, quote_plus, unquote
    from urllib.error import HTTPError, URLError
    import http.cookiejar as cookielib
except ImportError:
    from urllib2 import urlopen, Request, HTTPError, URLError
    from urllib import urlencode, quote, quote_plus, unquote
    from urlparse import urlparse
    import cookielib

BASE_URL    = 'https://dlstreams.top'
STREAM_BASE = 'https://dlstreams.top/stream/stream-{}.php'
ALT_FOLDERS = ['stream', 'cast', 'watch', 'plus', 'casting', 'player']

UA_WIN = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
UA_MOB = 'Mozilla/5.0 (iPad; CPU OS 15_6_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Mobile/15E148 Safari/604.1'


def log(msg):
    xbmc.log('[DaddyLive] ' + str(msg), xbmc.LOGDEBUG)


def _http_get(url, headers=None, referer=None, timeout=20):
    """HTTP GET simples com suporte a headers e SSL permissivo."""
    try:
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    except Exception:
        ctx = None

    hdrs = {'User-Agent': UA_WIN}
    if referer:
        hdrs['Referer'] = referer
    if headers:
        hdrs.update(headers)

    try:
        req = Request(url, headers=hdrs)
        if ctx:
            resp = urlopen(req, timeout=timeout, context=ctx)
        else:
            resp = urlopen(req, timeout=timeout)
        return resp.read().decode('utf-8', errors='replace')
    except Exception as e:
        log('HTTP GET falhou: {} | {}'.format(url, e))
        return ''


def _xbmc_url(url, extra_headers):
    """Constrói URL com headers para o player do Kodi (pipe encoding)."""
    return '{}|{}'.format(url, urlencode(extra_headers))


# ─────────────────────────────────────────────────────────────────────────────
#  Obter lista de players para um canal
# ─────────────────────────────────────────────────────────────────────────────

def get_players(channel_id):
    """
    Devolve lista de (label, player_url) para um dado channel_id.
    Tenta as várias pastas de stream do DaddyLive.
    """
    players = []
    for i, folder in enumerate(ALT_FOLDERS, start=1):
        url = '{}/{}/stream-{}.php'.format(BASE_URL, folder, channel_id)
        label = 'Player {}'.format(i)
        players.append((label, url))
    return players


# ─────────────────────────────────────────────────────────────────────────────
#  Resolver principal
# ─────────────────────────────────────────────────────────────────────────────

def resolve_stream(player_url, channel_id):
    """
    Tenta extrair o URL de stream .m3u8 / .ts a partir da página do player.
    Devolve (stream_url, headers_dict) ou (None, None) em caso de falha.
    """
    log('A resolver: ' + player_url)
    referer = BASE_URL + '/'
    data = _http_get(player_url, referer=referer)

    if not data:
        log('Página vazia: ' + player_url)
        return None, None

    # ── Método 1: iframe direto com src ──────────────────────────────────────
    iframes = re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', data, re.IGNORECASE)
    for iframe_src in iframes:
        if 'javascript' in iframe_src.lower():
            continue
        if not iframe_src.startswith('http'):
            iframe_src = BASE_URL + '/' + iframe_src.lstrip('/')
        result = _resolve_embed(iframe_src, referer=player_url)
        if result:
            return result
    
    # ── Método 2: src em javascript ──────────────────────────────────────────
    js_iframes = re.findall(r'''(?:iframe\.src|src)\s*=\s*['"](https?://[^'"]+)''', data)
    for iframe_src in js_iframes:
        result = _resolve_embed(iframe_src, referer=player_url)
        if result:
            return result

    # ── Método 3: m3u8 direto na página ──────────────────────────────────────
    m3u8 = _find_m3u8(data)
    if m3u8:
        headers = {'Referer': player_url, 'User-Agent': UA_WIN, 'Origin': BASE_URL}
        log('m3u8 direto encontrado: ' + m3u8)
        return _xbmc_url(m3u8, headers), headers

    log('Não foi possível resolver: ' + player_url)
    return None, None


def _resolve_embed(embed_url, referer=''):
    """
    Resolve um URL de embed (iframe) para um stream .m3u8 ou .ts.
    Suporta vários tipos de players conhecidos.
    """
    log('A resolver embed: ' + embed_url)
    netloc = urlparse(embed_url).netloc

    # ── Padrão newkso / Clappr ───────────────────────────────────────────────
    if 'newkso' in embed_url or 'newkso' in netloc:
        headers = {'Referer': referer or embed_url, 'User-Agent': UA_WIN,
                   'Origin': '{}://{}'.format(urlparse(embed_url).scheme, netloc)}
        return _xbmc_url(embed_url, headers), headers

    data = _http_get(embed_url, referer=referer)
    if not data:
        return None

    # ── Método: eval(function(p,a,c,k,e,...)) — packed JS ────────────────────
    if 'eval(function(p,a,c,k,e,' in data:
        try:
            from jsunpack import unpack
            data = unpack(data)
        except Exception as e:
            log('jsunpack erro: ' + str(e))

    # ── Método: CHANNEL_KEY + BUNDLE (Clappr newkso) ─────────────────────────
    if 'CHANNEL_KEY' in data and 'BUNDLE' in data:
        result = _resolve_clappr_newkso(data, embed_url, referer)
        if result:
            return result

    # ── Método: hlsUrl direto ─────────────────────────────────────────────────
    if 'hlsUrl' in data or 'hlsjsConfig' in data:
        result = _resolve_hlsurl(data, embed_url)
        if result:
            return result

    # ── Método: new Player(...) ───────────────────────────────────────────────
    if 'new Player(' in data:
        result = _resolve_new_player(data, embed_url)
        if result:
            return result

    # ── Método: player.src({src: ...}) ───────────────────────────────────────
    m = re.search(r'''player\.src\(\{src:\s*['"](.+?)['"]\,''', data)
    if m:
        url = m.group(1)
        headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
        log('player.src encontrado: ' + url)
        return _xbmc_url(url, headers), headers

    # ── Método: new Clappr ────────────────────────────────────────────────────
    if 'new Clappr' in data:
        result = _resolve_clappr(data, embed_url, referer)
        if result:
            return result

    # ── Método: fid= ─────────────────────────────────────────────────────────
    if 'fid=' in data:
        result = _resolve_fid(data, embed_url)
        if result:
            return result

    # ── Método: return([...].join) ────────────────────────────────────────────
    m = re.search(r'''return\((\[.+?\])\.join''', data, re.DOTALL)
    if m:
        try:
            parts = json.loads(m.group(1))
            url = ''.join(parts).replace('//', '//')
            headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
            log('return join encontrado: ' + url)
            return _xbmc_url(url, headers), headers
        except Exception:
            pass

    # ── Método: m3u8 direto ───────────────────────────────────────────────────
    m3u8 = _find_m3u8(data)
    if m3u8:
        headers = {'Referer': embed_url, 'User-Agent': UA_WIN,
                   'Origin': '{}://{}'.format(urlparse(embed_url).scheme, netloc)}
        log('m3u8 encontrado: ' + m3u8)
        return _xbmc_url(m3u8, headers), headers

    # ── Método: source em JS ──────────────────────────────────────────────────
    m = re.search(r'''source:\s*['"](.+?)['"]''', data)
    if m:
        url = m.group(1)
        headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
        return _xbmc_url(url, headers), headers

    return None


def _find_m3u8(data):
    """Extrai primeiro URL .m3u8 de um bloco de texto."""
    m = re.search(r'(https?://[^\s\'"<>]+\.m3u8[^\s\'"<>]*)', data)
    return m.group(1) if m else None


def _resolve_clappr_newkso(data, embed_url, referer):
    """Resolve players Clappr com CHANNEL_KEY + BUNDLE (padrão newkso.ru)."""
    try:
        m = re.search(r'''const\s+CHANNEL_KEY\s*=\s*['"]([\w-]+)['"]''', data)
        if not m:
            return None
        channel_key = m.group(1)

        m = re.search(r'''const\s+BUNDLE\s*=\s*['"]([A-Za-z0-9+/=]+)['"]''', data)
        if not m:
            return None
        bundle_b64 = m.group(1)

        parts_raw = base64.b64decode(bundle_b64)
        parts = json.loads(parts_raw.decode('utf-8'))
        for k in list(parts.keys()):
            try:
                parts[k] = base64.b64decode(parts[k]).decode('utf-8')
            except Exception:
                pass

        # Autenticar
        auth_url = (
            parts.get('b_host', '') +
            parts.get('b_script', '') +
            '?channel_id=' + quote_plus(channel_key) +
            '&ts='  + quote_plus(parts.get('b_ts', '')) +
            '&rnd=' + quote_plus(parts.get('b_rnd', '')) +
            '&sig=' + quote_plus(parts.get('b_sig', ''))
        )
        pu = urlparse(embed_url)
        origin = '{}://{}'.format(pu.scheme or 'https', pu.netloc)
        try:
            _http_get(auth_url, referer=embed_url)
        except Exception:
            pass

        # Server lookup
        lookup_url = '{}/server_lookup.php?channel_id={}'.format(origin, quote_plus(channel_key))
        body = _http_get(lookup_url, referer=embed_url)
        server_key = ''
        try:
            resp = json.loads(body)
            server_key = str(resp.get('server_key', '')).strip()
        except Exception:
            m2 = re.search(r'"server_key"\s*:\s*"([^"]+)"', body)
            if m2:
                server_key = m2.group(1).strip()

        if not server_key:
            return None

        sk_slug = server_key.strip('/')
        if sk_slug == 'top1/cdn':
            candidates = [
                'https://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key),
                'http://top1.newkso.ru/top1/cdn/{}/mono.m3u8'.format(channel_key),
            ]
        else:
            host_prefix = sk_slug.replace('/', '.')
            candidates = [
                'https://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(host_prefix, sk_slug, channel_key),
                'https://new.newkso.ru/{}/{}/mono.m3u8'.format(sk_slug, channel_key),
                'http://{}.new.newkso.ru/{}/{}/mono.m3u8'.format(host_prefix, sk_slug, channel_key),
                'http://new.newkso.ru/{}/{}/mono.m3u8'.format(sk_slug, channel_key),
            ]

        # Normalizar double slashes
        candidates = [re.sub(r'(?<!:)/{2,}', '/', u) for u in candidates]

        # Testar qual funciona
        working = None
        for u in candidates:
            try:
                chunk = _http_get(u, referer=embed_url)
                if chunk and (chunk.startswith('#EXTM3U') or len(chunk) > 0):
                    working = u
                    break
            except Exception:
                continue

        flink = working or candidates[0]
        stream_headers = {
            'Referer': embed_url,
            'Origin': origin,
            'User-Agent': UA_WIN,
        }
        log('Clappr/newkso resolvido: ' + flink)
        return _xbmc_url(flink, stream_headers), stream_headers

    except Exception as e:
        log('_resolve_clappr_newkso erro: ' + str(e))
        return None


def _resolve_clappr(data, embed_url, referer):
    """Resolve players Clappr genéricos."""
    try:
        m = re.search(r'''source\s*:\s*['"']?(.+?)['"']?\,''', data, re.DOTALL)
        if m:
            flink = m.group(1).strip().strip('"\'')
            if flink in ('m3u8Url', 'm3u8', 'src'):
                return None  # precisa do método newkso
            headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
            return _xbmc_url(flink, headers), headers
    except Exception as e:
        log('_resolve_clappr erro: ' + str(e))
    return None


def _resolve_hlsurl(data, embed_url):
    """Resolve players com hlsUrl ou hlsjsConfig."""
    try:
        # data-page com JSON
        if 'data-page=' in data:
            m = re.search(r'data-page=["\']([^"\']+)', data)
            if m:
                dp = m.group(1).replace('\\/', '/')
                try:
                    dp_json = json.loads(dp)
                    flink = dp_json['props']['streamData']['streamurl']
                    headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
                    return _xbmc_url(flink, headers), headers
                except Exception:
                    m2 = re.search(r'(https?://[^\s]+\.m3u8)', dp)
                    if m2:
                        headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
                        return _xbmc_url(m2.group(1), headers), headers

        # hlsUrl direto
        m = re.search(r'hlsUrl\s*=\s*["\'](.+?)["\']', data)
        if m:
            flink = m.group(1)
            headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
            return _xbmc_url(flink, headers), headers
    except Exception as e:
        log('_resolve_hlsurl erro: ' + str(e))
    return None


def _resolve_new_player(data, embed_url):
    """Resolve players new Player(...)."""
    try:
        import ast
        import random
        m = re.search(r'''new Player(\(.+?\))''', data, re.DOTALL)
        if m:
            player = ast.literal_eval(m.group(1))
            p1 = player[3]
            p2 = random.choice(list(player[4].keys()))
            flink = 'https://{}/hls/{}/live.m3u8'.format(p2, p1)
            headers = {'Referer': embed_url, 'User-Agent': UA_WIN}
            log('new Player resolvido: ' + flink)
            return _xbmc_url(flink, headers), headers
    except Exception as e:
        log('_resolve_new_player erro: ' + str(e))
    return None


def _resolve_fid(data, embed_url):
    """Resolve players com fid= (padrão antigo)."""
    try:
        regex = r'''<script>fid=['"'](.+?)['"'].+?text/javascript.*?src=['"'](.+?)['"']></script>'''
        m = re.search(regex, data, re.DOTALL)
        if not m:
            return None
        vid, getembed = m.group(1), m.group(2)
        getembed = 'https:' + getembed if getembed.startswith('//') else getembed
        embed_data = _http_get(getembed, referer=embed_url)
        embed_host = re.search(r'''document.write.+?src=['"'](.+?player)=''', embed_data, re.DOTALL)
        if not embed_host:
            return None
        host = '{}=desktop&live={}'.format(embed_host.group(1), vid)
        host_data = _http_get(host, referer=embed_url)
        try:
            link = re.search(r'''return\((\[.+?\])\.join''', host_data, re.DOTALL).group(1)
        except Exception:
            link = re.search(r'''file:.*['"](.+?)['"],''', host_data, re.DOTALL).group(1)
        flink = link.replace('[', '').replace(']', '').replace('"', '').replace(',', '').replace('\\/', '/')
        referer_base = embed_url.split('embed')[0] if 'embed' in embed_url else embed_url
        headers = {'Referer': referer_base, 'User-Agent': UA_WIN}
        return _xbmc_url(flink, headers), headers
    except Exception as e:
        log('_resolve_fid erro: ' + str(e))
    return None
