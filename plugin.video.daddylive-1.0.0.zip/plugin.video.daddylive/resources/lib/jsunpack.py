# -*- coding: utf-8 -*-
"""
Unpacker for Dean Edward's p.a.c.k.e.r.
Adapted from jsbeautifier.
"""
import re

PRIORITY = 1


def detect(source):
    return source.replace(' ', '').startswith('eval(function(p,a,c,k,e,')


def unpack(source):
    payload, symtab, radix, count = _filterargs(source)
    if count != len(symtab):
        raise UnpackingError('Malformed p.a.c.k.e.r. symtab.')
    try:
        unbase = Unbaser(radix)
    except TypeError:
        raise UnpackingError('Unknown p.a.c.k.e.r. encoding.')

    def lookup(match):
        word = match.group(0)
        word2 = symtab[int(word)] if radix == 1 else symtab[unbase(word)]
        return word2 or word

    source = re.sub(r'\b\w+\b', lookup, payload)
    return _replacestrings(source)


def _filterargs(source):
    juicers = [
        (r"}\\('(.*)', *(\\d+|\\[\\]), *(\\d+), *'(.*)'\\·split\\('\\|'\\), *(\\d+), *(.*)\\)\\)"),
        (r"}\\('(.*)', *(\\d+|\\[\\]), *(\\d+), *'(.*)'\\·split\\('\\|'\\)"),
    ]
    juicers = [
        (r"\}\('(.*)', *(\d+|\[\]), *(\d+), *'(.*)'\·split\('\|'\), *(\d+), *(.*)\)\)"),
        (r"\}\('(.*)', *(\d+|\[\]), *(\d+), *'(.*)'\·split\('\|'\)"),
    ]
    # simpler approach
    args = re.search(
        r"\}\('(.*)',\s*(\d+|\[\]),\s*(\d+),\s*'(.*)'\s*\.split\('\|'\)",
        source, re.DOTALL
    )
    if args:
        a = args.groups()
        radix = a[1]
        if radix == '[]':
            radix = 62
        else:
            radix = int(radix)
        try:
            return a[0], a[3].split('|'), radix, int(a[2])
        except ValueError:
            raise UnpackingError('Corrupted p.a.c.k.e.r. data.')
    raise UnpackingError('Could not make sense of p.a.c.k.e.r data.')


def _replacestrings(source):
    match = re.search(r'var *(_\w+)=\["(.*?)"\];', source, re.DOTALL)
    if match:
        varname, strings = match.groups()
        startpoint = len(match.group(0))
        lookup = strings.split('","')
        variable = '%s[%%d]' % varname
        for index, value in enumerate(lookup):
            source = source.replace(variable % index, '"%s"' % value)
        return source[startpoint:]
    return source


class Unbaser(object):
    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: (' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
             '[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~')
    }

    def __init__(self, base):
        self.base = base
        if 36 < base < 62:
            if base not in self.ALPHABET:
                self.ALPHABET[base] = self.ALPHABET[62][:base]
        if 2 <= base <= 36:
            self.unbase = lambda s: int(s, base)
        else:
            try:
                self.dictionary = dict(
                    (cipher, index) for index, cipher in enumerate(self.ALPHABET[base]))
            except KeyError:
                raise TypeError('Unsupported base encoding.')
            self.unbase = self._dictunbaser

    def __call__(self, string):
        return self.unbase(string)

    def _dictunbaser(self, string):
        ret = 0
        for index, cipher in enumerate(string[::-1]):
            ret += (self.base ** index) * self.dictionary[cipher]
        return ret


class UnpackingError(Exception):
    pass
