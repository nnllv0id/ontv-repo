# -*- coding: utf-8 -*-
"""
DaddyLive — Navigator
Ecrãs:
  1. Categorias
  2. Canais por categoria
  3. Players disponíveis para um canal
  4. Reprodução
"""

import sys
import os
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

try:
    from urllib.parse import urlencode, parse_qsl, quote, unquote
except ImportError:
    from urllib import urlencode, quote, unquote
    from urlparse import parse_qsl

ADDON      = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
HANDLE     = int(sys.argv[1])
BASE_URL   = sys.argv[0]
ICON       = os.path.join(ADDON_PATH, 'icon.png')
FANART     = os.path.join(ADDON_PATH, 'fanart.png')

LOGO_BASE  = 'https://dlstreams.top/assets/logos/'


def log(msg):
    xbmc.log('[DaddyLive Nav] ' + str(msg), xbmc.LOGDEBUG)


def url_para(params):
    return BASE_URL + '?' + urlencode(params)


def notificar(msg, tipo=xbmcgui.NOTIFICATION_ERROR):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, ICON, 4000)


# ─────────────────────────────────────────────────────────────────────────────
#  ECRÃ 1 — Categorias
# ─────────────────────────────────────────────────────────────────────────────

def mostrar_categorias():
    from channels import get_categorias, CANAIS

    xbmcplugin.setPluginCategory(HANDLE, 'DaddyLive')

    # Ícones por categoria (mapeamento parcial)
    CAT_ICONS = {
        'Sky Sports UK':           'sky_sports_football_uk',
        'TNT Sports UK':           'tnt_sports_1_uk',
        'Sport TV Portugal':       'sport_tv1_portugal',
        'Eleven Sports Portugal':  'eleven_sports_1_portugal',
        'Portugal TV':             'rtp_1_portugal',
        'ESPN USA':                'espn',
        'Fox Sports USA':          'fox_sports_1_usa',
        'US Networks':             'nbc_usa',
        'beIN Sports':             'bein_sports_mena_english_1',
        'Canal+':                  'canal_france',
        'DAZN':                    'dazn_1_uk',
        'Eurosport':               'eurosport_1_greece',
        'Movistar Spain':          'movistar_laliga',
        'France TV':               'rmc_sport_1_france',
        'Sky Sport DE':            'sky_sports_1_de',
        'Sky Sport Italy':         'sky_sport_max_italy',
        'SuperSport':              'supersport_grandstand',
        'Canada TV':               'tsn1',
        'Brasil TV':               'sportv_brasil',
        'Nova Sports Greece':      'nova_sports_1_greece',
        'Cosmote Sport Greece':    'cosmote_sport_1_hd',
        'UK TV':                   'itv_1_uk',
        'Spain TV':                'laliga_tv_uk',
        'Italy TV':                'rai_1_italy',
        'Poland TV':               'polsat_sport_poland',
        'Russia TV':               'match_football_1_russia',
        'Romania TV':              'digi_sport_1_romania',
        'Croatia TV':              'sport_klub_1_croatia',
        'Bulgaria TV':             'max_sport_1_bulgaria',
        'Denmark TV':              'tv2_sport_denmark',
        'Sweden TV':               'tv4_sport_live_1',
        'Middle East TV':          'abu_dhabi_sports_1_uae',
        'Asia TV':                 'astro_supersport_1',
        'Argentina TV':            'espn_premium_argentina',
        'Czech/Slovakia TV':       'nova_sport_1_cz',
        'Outros Desporto':         'pdc_tv',
        'Noticias':                'cnn_usa',
    }

    cats = get_categorias()

    for cat in cats:
        n_canais = len([c for c in CANAIS if c[2] == cat])
        icon_slug = CAT_ICONS.get(cat, '').lower().replace(' ', '_').replace('/', '_')
        thumb = (LOGO_BASE + icon_slug + '.png') if icon_slug else ICON

        li = xbmcgui.ListItem('{} [COLOR grey]({} canais)[/COLOR]'.format(cat, n_canais))
        li.setArt({'thumb': thumb, 'fanart': FANART, 'icon': thumb})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'canais', 'categoria': quote(cat)}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ─────────────────────────────────────────────────────────────────────────────
#  ECRÃ 2 — Canais por Categoria
# ─────────────────────────────────────────────────────────────────────────────

def mostrar_canais(categoria):
    from channels import get_canais_por_categoria

    xbmcplugin.setPluginCategory(HANDLE, categoria)

    canais = get_canais_por_categoria(categoria)
    if not canais:
        notificar('Sem canais nesta categoria.')
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for nome, cid in canais:
        # Logo do canal via DaddyLive
        slug = nome.lower().replace(' ', '_').replace('/', '_').replace('(', '').replace(')', '').replace('+', '').replace("'", '').replace('#', '').replace('!', '').replace(',', '').replace('.', '')
        thumb = LOGO_BASE + slug + '.png'

        li = xbmcgui.ListItem(nome)
        li.setArt({'thumb': thumb, 'fanart': FANART, 'icon': thumb})
        li.setInfo('video', {'title': nome, 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'players', 'nome': quote(nome), 'cid': str(cid)}),
            li, True
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    xbmcplugin.endOfDirectory(HANDLE)


# ─────────────────────────────────────────────────────────────────────────────
#  ECRÃ 3 — Players disponíveis para um canal
# ─────────────────────────────────────────────────────────────────────────────

def mostrar_players(nome, channel_id):
    from resolver import get_players, BASE_URL as DL_BASE

    xbmcplugin.setPluginCategory(HANDLE, nome)

    players = get_players(channel_id)

    for label, player_url in players:
        li = xbmcgui.ListItem('[COLOR gold]{}[/COLOR] — {}'.format(label, nome))
        li.setArt({'thumb': ICON, 'fanart': FANART})
        li.setInfo('video', {'title': '{} — {}'.format(label, nome), 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            HANDLE,
            url_para({'acao': 'play', 'nome': quote(nome), 'purl': quote(player_url), 'cid': str(channel_id)}),
            li, False
        )

    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# ─────────────────────────────────────────────────────────────────────────────
#  ECRÃ 4 — Reprodução
# ─────────────────────────────────────────────────────────────────────────────

def reproduzir(nome, player_url, channel_id):
    from resolver import resolve_stream

    dp = xbmcgui.DialogProgress()
    dp.create(ADDON_NAME, 'A resolver stream...\n{}'.format(nome))
    dp.update(30)

    stream_url, headers = resolve_stream(player_url, channel_id)

    dp.update(90)
    dp.close()

    if not stream_url:
        notificar('[COLOR red]Não foi possível resolver o stream.[/COLOR]\nTenta outro player.')
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    log('Stream final: ' + stream_url)

    li = xbmcgui.ListItem(nome, path=stream_url)
    li.setArt({'thumb': ICON, 'fanart': FANART, 'icon': ICON})
    li.setProperty('IsPlayable', 'true')
    li.setInfo('video', {'title': nome, 'mediatype': 'video'})

    url_lower = stream_url.lower().split('?')[0].split('|')[0]

    if '.m3u8' in url_lower:
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('mimetype', 'application/x-mpegURL')
        log('Player: adaptive HLS')
    elif url_lower.endswith('.mp4'):
        li.setProperty('mimetype', 'video/mp4')
        log('Player: nativo MP4')
    else:
        li.setProperty('mimetype', 'video/mp2t')
        log('Player: nativo TS')

    xbmcplugin.setResolvedUrl(HANDLE, True, li)


# ─────────────────────────────────────────────────────────────────────────────
#  ROTEADOR
# ─────────────────────────────────────────────────────────────────────────────

def run():
    params = dict(parse_qsl(sys.argv[2][1:]))
    acao   = params.get('acao', 'main')
    log('Acao=' + acao + ' params=' + str(params))

    if acao == 'main':
        mostrar_categorias()

    elif acao == 'canais':
        cat = unquote(params.get('categoria', ''))
        mostrar_canais(cat)

    elif acao == 'players':
        nome = unquote(params.get('nome', ''))
        cid  = int(params.get('cid', 0))
        mostrar_players(nome, cid)

    elif acao == 'play':
        nome       = unquote(params.get('nome', ''))
        player_url = unquote(params.get('purl', ''))
        cid        = int(params.get('cid', 0))
        reproduzir(nome, player_url, cid)

    else:
        mostrar_categorias()
