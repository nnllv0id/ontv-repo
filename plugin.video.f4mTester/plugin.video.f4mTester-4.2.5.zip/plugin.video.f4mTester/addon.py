# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import os
from urllib.parse import urlparse, parse_qs, parse_qsl, quote, unquote, quote_plus, unquote_plus, urlencode
from app import PORT

URL_HLSRETRY     = "http://127.0.0.1:{}/hlsretry?url=".format(PORT)
URL_TS_DOWNLOADER = "http://127.0.0.1:{}/tsdownloader?url=".format(PORT)

addon     = xbmcaddon.Addon()
addonName = addon.getAddonInfo('name')
dialog_   = xbmcgui.Dialog()
translate = xbmcvfs.translatePath
homeDir   = addon.getAddonInfo('path')
addonIcon = translate(os.path.join(homeDir, 'icon.png'))

kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])

def dialog(msg):
    xbmcgui.Dialog().ok(addonName, msg)

def infoDialog(message, iconimage='', time=3000, sound=False):
    heading = addonName
    if iconimage == '':
        iconimage = addonIcon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog_.notification(heading, message, iconimage, time, sound=sound)

def select(name, items):
    return dialog_.select(name, items)

def basename(p):
    i = p.rfind('/') + 1
    return p[i:]

def convert_to_m3u8(url):
    """Converte URL .ts para .m3u8 sem duplicar /live/"""
    if '|' in url:
        url = url.split('|')[0]
    elif '%7C' in url:
        url = url.split('%7C')[0]

    # Já é m3u8 ou HLS — não alterar
    if '.m3u8' in url or '/hl' in url:
        return url

    # Não tem segmentos suficientes para converter
    if url.count("/") <= 4:
        return url

    # Já não é mp4/avi
    if '.mp4' in url or '.avi' in url:
        return url

    parsed_url = urlparse(url)
    try:
        host_part1 = '{}://{}'.format(parsed_url.scheme, parsed_url.netloc)
        host_part2 = url.split(host_part1)[1]

        # Só adicionar /live se o caminho ainda não tiver /live/
        if '/live/' not in host_part2:
            url = host_part1 + '/live' + host_part2

        file = basename(url)
        if '.ts' in file:
            url = url.replace(file, file.replace('.ts', '.m3u8'))
        elif '.' not in file:
            url = url + '.m3u8'
    except:
        pass

    return url

def m3u8_to_ts(url):
    if '.m3u8' in url and '/live/' in url and url.count("/") > 5:
        url = url.replace('/live', '').replace('.m3u8', '')
    return url

def player_hlsretry(name, url, iconimage, description):
    name = 'F4MTESTER - HLSRETRY - ' + name if name else 'F4MTESTER - HLSRETRY'
    url  = unquote_plus(url)
    url  = url.split('%7C')[0] if '%7C' in url else url
    url  = url.split('|')[0]   if '|'   in url else url
    url  = convert_to_m3u8(url)
    url  = URL_HLSRETRY + quote(url)

    li = xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)

def player_tsdownloader(name, url, iconimage, description):
    name = 'F4MTESTER - TSDOWNLOADER - ' + name if name else 'F4MTESTER - TSDOWNLOADER'
    url  = unquote_plus(url)
    url  = url.split('%7C')[0] if '%7C' in url else url
    url  = url.split('|')[0]   if '|'   in url else url
    # Para tsdownloader usar o URL .ts diretamente sem converter para m3u8
    url  = url.replace('.m3u8', '.ts').replace('/live/', '/')
    if url.endswith('/'):
        url = url.rstrip('/')
    url  = URL_TS_DOWNLOADER + quote(url)

    li = xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)


#### run addon ####
def run(params):
    stream_type = params.get('streamtype', None)
    iconimage   = params.get('iconImage', params.get('thumbnailImage', addonIcon))
    name        = params.get('name', 'F4mTester')
    url         = params.get('url', '')
    description = params.get('description', '')

    if not stream_type:
        dialog('F4MTESTER PLAYER')
    elif url:
        op = select('SELECT PLAYER', ['PROXY - HLSRETRY', 'PROXY - TSDOWNLOADER'])
        if op == 0:
            player_hlsretry(name, url, iconimage, description)
        elif op == 1:
            player_tsdownloader(name, url, iconimage, description)
